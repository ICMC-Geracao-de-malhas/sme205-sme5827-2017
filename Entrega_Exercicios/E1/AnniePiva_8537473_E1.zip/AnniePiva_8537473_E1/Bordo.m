close all
clear all
clc

fileID = fopen('naca012.txt','r');
[A, count] = fscanf(fileID,'%f %f',[2 Inf]);
fclose(fileID);

n = count/2;
A(1,n+1) = 1; 
A(2,n+1) = 0;

a = -0.5;
b = 1.5;
c = -0.6;
d = 0.6;
nX = n+1;
nY = 40;

%Top
xAC = A(1,:);
yAC = A(2,:);
AC = [xAC; yAC];

%Left
xCD = linspace(b,1, nY);
yCD = zeros(1,nY);
CD = [xCD; yCD];

% Right
xAB = xCD;
yAB = yCD;
AB = [xAB; yAB];

%Botton
per = 2*((b-a)+(d-c));
dx = per/(nX-1);

num_DE = round((0-c)/dx)+1;
yDE = linspace(c, 0, num_DE);
xDE = b*ones(1,num_DE);
DE = [xDE; yDE];

num_HB = round(d/dx)+1;
yHB = linspace(0, d, num_HB);
xHB = b*ones(1,num_HB);
HB = [xHB; yHB];

num_EF = round((b-a)/dx)+1;
xEF = linspace(a, b, num_EF);
yEF = c*ones(1, num_EF);
EF = [xEF; yEF];

num_FG = round((d-c)/dx)+1;
yFG = linspace(d,c, num_FG);
xFG = a*ones(1, num_FG);
FG = [xFG; yFG];

num_GH1 = round((b-a)/dx)+1;
erro = num_HB + num_GH1 + num_FG + num_EF + num_DE - 4 - nX;
num_GH = num_GH1 - erro;
xGH = linspace(b, a, num_GH);
yGH = d*ones(1, num_GH);
GH = [xGH; yGH];

DB = [HB(:,1:num_HB-1), GH(:,1:num_GH-1), FG(:,1:num_FG-1), EF(:,1:num_EF-1), DE];

%Escrever arquivo
arq = fopen('Bordo2.txt','w');
fprintf(arq, '%d\n', nX);
fprintf(arq,'%4.2f %4.2f\n', AC); %top
fprintf(arq, '%d\n', nX);
fprintf(arq,'%4.2f %4.2f\n', DB);%botton
fprintf(arq, '%d\n', nY);
fprintf(arq,'%4.2f %4.2f\n', AB);%left
fprintf(arq, '%d\n', nY);
fprintf(arq,'%4.2f %4.2f\n', CD);%right
fclose(arq)

%plot
plot(AC(1,:), AC(2,:), 'o-g', 'MarkerSize',5,'MarkerFaceColor','g')
hold on
plot(CD(1,:), CD(2,:), 'o-b', 'MarkerSize',5,'MarkerFaceColor','b')
plot(DB(1,:), DB(2,:), 'o-k', 'MarkerSize',5,'MarkerFaceColor','k')
plot(AB(1,:), AB(2,:), 'o-r', 'MarkerSize',3,'MarkerFaceColor','r')
axis([-0.6, 1.6, -0.7, 0.7])
