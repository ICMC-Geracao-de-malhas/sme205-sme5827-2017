close all
clear all
clc

%%Leitura das bordas
f = fopen('Bordo2.txt','r');
nx = fscanf(f,'%d', [1 1]);
rt = fscanf(f,'%f %f', [2 nx]);
nX2 = fscanf(f,'%d', [1 1]);
rb = fscanf(f,'%f %f', [2 nX2]);
ny = fscanf(f,'%d', [1 1]);
rl = fscanf(f,'%f %f', [2 ny]);
nY2 = fscanf(f,'%d', [1 1]);
rr = fscanf(f,'%f %f', [2 nY2]);
fclose(f);

%%Formacao do grid
gridx = zeros(ny,nx);
gridy = zeros(ny,nx);

gridx(1,:) = rb(1,:);
gridx(ny,:) = rt(1,:);
gridx(:, 1) = rl(1,:);
gridx(:, nx) = rr(1,:);
gridy(1,:) = rb(2,:);
gridy(ny,:) = rt(2,:);
gridy(:, 1) = rl(2,:);
gridy(:, nx) = rr(2,:);

%Chute inicial = metodo transfinito
dx = 1/(nx-1);
dy = 1/(ny-1);

for j = 2:ny-1
    for i = 2:nx-1
        idx = (i-1)*dx;
        jdy = (j-1)*dy;
        gridx(j,i) = (1 - idx)*rl(1,j) + idx*rr(1,j) + (1 - jdy)*rb(1,i) + ...
            jdy*rt(1,i) - (1 -idx)*(1 - jdy)*rb(1,1) - (1 - idx)*jdy*rt(1,1) - ...
            idx*(1 - jdy)*rb(1,nx) - idx*jdy*rt(1,nx);
        gridy(j,i) = (1 - idx)*rl(2,j) + idx*rr(2,j) + (1 - jdy)*rb(2,i) + ...
            jdy*rt(2,i) - (1 -idx)*(1 - jdy)*rb(2,1) - (1 - idx)*jdy*rt(2,1) -...
            idx*(1 - jdy)*rb(2,nx) - idx*jdy*rt(2,nx);
    end
end

%Metodo eliptico
dxi = 1.0/nx;
deta = 1.0/ny;
N = 100;
for k = 1:N
    for j = 2:ny-1
        for i = 2:nx-1
            dxdxi = (gridx(j,i+1) - gridx(j,i-1))/(2*dxi);
            dydxi = (gridy(j,i+1) - gridy(j,i-1))/(2*dxi);
            dxdeta = (gridx(j+1,i) - gridx(j-1,i))/(2*deta);
            dydeta = (gridy(j+1,i)-gridy(j-1,i))/(2*deta);
            g11 = dxdxi^2 + dydxi^2;
            g22 = dxdeta^2 + dydeta^2;
            g12 = dxdxi*dxdeta + dydxi*dydeta;
            a = 4*(deta^2)*g22;
            b = 4*dxi*deta*g12;
            c = 4*(dxi^2)*g11;
            gridx(j,i) = (1/(2*(a+c)))*(a*(gridx(j,i+1)+gridx(j,i-1))+c*(gridx(j+1,i)+gridx(j-1,i)))-0.5*(b*(gridx(j+1,i+1)+gridx(j-1,i-1)-gridx(j+1,i-1)-gridx(j-1,i+1)));
            gridy(j,i) = (1/(2*(a+c)))*(a*(gridy(j,i+1)+gridy(j,i-1))+c*(gridy(j+1,i)+gridy(j-1,i)))-0.5*(b*(gridy(j+1,i+1)+gridy(j-1,i-1)-gridy(j+1,i-1)-gridy(j-1,i+1)));
        end
    end
end


%%Plot
for i = 1:nx
    plot(gridx(:,i),gridy(:,i),'k')
    hold on
end
for i = 1:ny
    plot(gridx(i,:),gridy(i,:),'k')
end

plot(rb(1,:), rb(2,:),'k', 'linewidth', 1.5)
plot(rt(1,:), rt(2,:),'g', 'linewidth', 1.5)
plot(rr(1,:), rr(2,:),'b', 'linewidth', 1.5)
plot(rl(1,:), rl(2,:),'r', 'linewidth', 1.5)
axis([-0.6, 1.6, -0.7, 0.7])