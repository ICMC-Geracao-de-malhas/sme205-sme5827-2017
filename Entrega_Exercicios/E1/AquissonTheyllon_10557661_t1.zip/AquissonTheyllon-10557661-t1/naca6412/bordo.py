import sys
import numpy as np

f = open('bordo.txt','wt')

## Refinamento do eixo inferior (rb).

t = np.linspace(0,1,62) 

t1 = np.linspace(0.001240,1,7)   		#BH
t2 = np.linspace(1.35267857,-0.85714286,17)     #HG
t3 = np.linspace(1,-1,14)	   		#GF
t4 = np.linspace(-0.85714286,1.35267857,17)	#FE
t5 = np.linspace(-1,0.000000,7) 		#ED

n = t.shape[0]

#eixo inferior (rb)
f.write(str(n)) 
f.write('\n')
for i in range(7):
    f.write("{:.8f}".format(1.5))
    f.write(' ')
    f.write("{:.8f}".format(t1[i]))
    f.write('\n')

for i in range(17):
    f.write("{:.8f}".format(t2[i]))
    f.write(' ')
    f.write("{:.8f}".format(1.0))
    f.write('\n')

for i in range(14):
    f.write("{:.8f}".format(-1.0))
    f.write(' ')
    f.write("{:.8f}".format(t3[i]))
    f.write('\n')

for i in range(17):
    f.write("{:.8f}".format(t4[i]))
    f.write(' ')
    f.write("{:.8f}".format(-1.0))
    f.write('\n')

for i in range(7):
    f.write("{:.8f}".format(1.5))
    f.write(' ')
    f.write("{:.8f}".format(t5[i]))
    f.write('\n')
#############################################

## eixos laterais

#############################################
s = np.linspace(1.5,1.000250,50) 

n = s.shape[0]

#eixo esquerdo (rl)
f.write(str(n))
f.write('\n')
for i in range(n):
    f.write("{:.8f}".format(s[i]))
    f.write(' ')
    f.write("{:.8f}".format(0.001240))
    f.write('\n')
############################################

s1 = np.linspace(1.5, 1.000000,50) # 

n = s1.shape[0]

#eixo direito (rr)
f.write(str(n))
f.write('\n')
for i in range(n):
    f.write("{:.8f}".format(s1[i]))
    f.write(' ')
    f.write("{:.8f}".format(0.000000))
    f.write('\n')

f.close()

