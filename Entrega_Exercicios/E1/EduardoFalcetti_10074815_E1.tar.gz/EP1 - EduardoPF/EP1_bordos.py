# coding: utf-8
import sys
import numpy as np
from matplotlib import pyplot as pt

def distan(P1,P2):
    return ((P1[0] - P2[0])**2 + (P1[1] - P2[1])**2)**0.5

n_top_bottom = 70
n_left_right = 70

if len(sys.argv) == 1:
    nameFile = 'malhaNacaEPF.txt'
else:
    nameFile = sys.argv[1]
    

f = open(nameFile,'wt')


A = np.loadtxt("naca012.txt")
x_naca = A[:,0]
y_naca = A[:,1]

#interpolacao do naca
n = x_naca.shape[0]
d = [] 
acu = 0

for i in range(n - 1):
    dx = x_naca[i + 1] - x_naca[i] 
    dy = y_naca[i + 1] - y_naca[i]
    acu += (dx**2 + dy**2)**0.5
    d.append(acu)
d_total = d[-1]
d = np.array(d)


ds = d_total/(n_top_bottom - 1)

f.write(str(n_top_bottom))
f.write('\n')
x,y = [],[]
x.append(x_naca[0])
y.append(y_naca[0])
dist = 0

for i in range(n_top_bottom-2):
    j = 0
    dist += ds
    while (dist > d[j]):
        j += 1
    if j== 0:
        d_l = dist
    else:
        d_l = dist - d[j-1]
        
    dx = x_naca[j+1] - x_naca[j]
    dy = y_naca[j+1] - y_naca[j]
    dlocal = (dx**2 + dy**2)**0.5
    x.append(x_naca[j] + dx*d_l/dlocal)
    y.append(y_naca[j] + dy*d_l/dlocal)

x.append(x_naca[-1])
y.append(y_naca[-1])

for i in range(n_top_bottom):
    f.write("{:.4f}".format(x[i]))
    f.write(' ')
    f.write("{:.4f}".format(y[i]))
    f.write('\n')

Lx = 1
Ly = 1

A = np.array([x_naca[0],y_naca[0]])
C = np.array([x_naca[-1],y_naca[-1]])

B = np.array([A[0] + Lx,A[1]])
D = np.array([C[0] + Lx,C[1]])

H = np.array([B[0],B[1] + Ly])
E = np.array([D[0],D[1] - Ly])


G = np.array([min(x_naca) - Lx, H[1]])
F = np.array([min(x_naca) -Lx,  E[1]])

d_topTotal = 2*distan(H,B) + 2*distan(H,G) + distan(G,F) 
nHB = nDE = int(round(distan(H,B)*n_top_bottom/d_topTotal))
nGH = nFE = int(round(distan(G,H)*n_top_bottom/d_topTotal))
nGF = int(round(distan(G,F)*n_top_bottom/d_topTotal))
nGF += n_top_bottom - (nHB+nDE+nGH+nFE+nGF)

nGH += 1
nGF += 2
nFE += 1




x = [B[0]]
y = [B[1]]
dy = distan(H,B)/(nHB-1)
for i in range(nHB-2):
    x.append(x[-1])
    y.append(y[-1] + dy)

x.append(H[0])
y.append(H[1])
dx = distan(H,G)/(nGH-1)
for i in range(nGH-2):
    x.append(x[-1] - dx)
    y.append(y[-1])
    
x.append(G[0])
y.append(G[1])
dy = distan(G,F)/(nGF-1)
for i in range(nGF-2):
    x.append(x[-1])
    y.append(y[-1]-dy)
    
    
x.append(F[0])
y.append(F[1])
dx = distan(F,E)/(nFE-1)
for i in range(nFE-2):
    x.append(x[-1] + dx)
    y.append(y[-1])
    
x.append(E[0])
y.append(E[1])
dy = distan(E,D)/(nDE-1)
for i in range(nDE-2):
    x.append(x[-1])
    y.append(y[-1] + dy)

x.append(D[0])
y.append(D[1])


f.write(str(n_top_bottom))
f.write('\n')
for i in range(n_top_bottom):
    f.write("{:.4f}".format(x[i]))
    f.write(' ')
    f.write("{:.4f}".format(y[i]))
    f.write('\n')

#lado left
x = [B[0]]
y = [B[1]]
dx = distan(A,B)/(n_left_right-1)
for i in range(n_left_right-2):
    x.append(x[-1] - dx)
    y.append(y[-1])
    
x.append(A[0])
y.append(A[1])

f.write(str(n_left_right))
f.write('\n')
for i in range(n_left_right):
    f.write("{:.4f}".format(x[i]))
    f.write(' ')
    f.write("{:.4f}".format(y[i]))
    f.write('\n')

#lado right
x = [D[0]]
y = [D[1]]
dx = distan(C,D)/(n_left_right-1)
for i in range(n_left_right-2):
    x.append(x[-1] - dx)
    y.append(y[-1])
x.append(C[0])
y.append(C[1])

f.write(str(n_left_right))
f.write('\n')
for i in range(n_left_right):
    f.write("{:.4f}".format(x[i]))
    f.write(' ')
    f.write("{:.4f}".format(y[i]))
    f.write('\n')

f.close()


# In[ ]:



