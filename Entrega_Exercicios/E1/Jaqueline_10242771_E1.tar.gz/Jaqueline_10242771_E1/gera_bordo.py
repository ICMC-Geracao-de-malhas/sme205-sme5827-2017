#Jaqueline Alvarenga Silveira - 10242771

import sys
import numpy as np
import re

filename = sys.argv[1]

#Conta quantos dados tem o arquivo
nt = sum(1 for line in open(filename))

f2 = open(sys.argv[2],'wt')

#Escreve no arquivo TOP
f2.write(str(nt))
f2.write('\n')

for line in (open(filename).readlines()):
    f2.write(line)

f2.write(str(nt))
f2.write('\n')

#Discretiza os valores BH
tBH = np.linspace(0.00126,0.6,13)
nBH = tBH.shape[0]

for i in range(nBH):
    f2.write("{:.5f}".format(1.5))
    f2.write(' ')
    f2.write("{:.5f}".format(tBH[i]))
    f2.write('\n')

#Discretiza os valores de EF e HG
tEF_HG = np.linspace(1.4,-1,12)
nEF_HG = tEF_HG.shape[0]

#valores de GH
for i in range(nEF_HG):
    f2.write("{:.5f}".format(tEF_HG[i]))
    f2.write(' ')
    f2.write("{:.5f}".format(0.6))
    f2.write('\n')

#Discretiza os valores de FG
tGF = np.linspace(0.5,-0.5,12)
nGF = tGF.shape[0]

for i in range(nGF):
    f2.write("{:.5f}".format(-1.0))
    f2.write(' ')
    f2.write("{:.5f}".format(tGF[i]))
    f2.write('\n')

#Valores de EF
for i in range(nEF_HG-1,-1,-1):
    f2.write("{:.5f}".format(tEF_HG[i]))
    f2.write(' ')
    f2.write("{:.5f}".format(-0.6))
    f2.write('\n')

#Discretiza os valores DE
tDE = np.linspace(-0.6,-0.00126,14)
nDE = tDE.shape[0]

for i in range(nDE):
    f2.write("{:.5f}".format(1.5))
    f2.write(' ')
    f2.write("{:.5f}".format(tDE[i]))
    f2.write('\n')

#Discretiza os valores AB CD
t = np.linspace(1,1.5,30)
n = t.shape[0]

#Escreve no arquivo LEFT
f2.write(str(n))
f2.write('\n')
for i in range(n-1,-1,-1):
    f2.write("{:.5f}".format(t[i]))
    f2.write(' ')
    f2.write("{:.5f}".format(0.0))
    f2.write('\n')

#Escreve no arquivo RIGHT
f2.write(str(n))
f2.write('\n')
for i in range(n-1,-1,-1):
    f2.write("{:.5f}".format(t[i]))
    f2.write(' ')
    f2.write("{:.5f}".format(0.0))
    f2.write('\n')

f2.close()












