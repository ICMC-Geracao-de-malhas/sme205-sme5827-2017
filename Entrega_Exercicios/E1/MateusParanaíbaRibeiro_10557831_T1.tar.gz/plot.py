import sys
import numpy as np
import matplotlib.pyplot as plt

#lendo o bordo gerado pelo programa em fortran:
f = open('bordo.txt','rt')
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#bordo de cima aerofolio
nah=int(f.readline())
rt = np.zeros((nah,2))
for i in range(nah):
    l=f.readline()
    rt[i,0]=l.split(' ')[0]
    rt[i,1]=l.split(' ')[1]

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#bordo da direita

nab=int(f.readline())
rr = np.zeros((nab,2))
for i in range(nab):
    l=f.readline()
    rr[i,0]=l.split(' ')[0]
    rr[i,1]=l.split(' ')[1]

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#vetores que compoem o bordo de baixo
nbc=int(f.readline())
gf = np.zeros((nbc,2))
for i in range(nbc):
    l=f.readline()
    gf[i,0]=l.split(' ')[0]
    gf[i,1]=l.split(' ')[1]


ncd=int(f.readline())
ef = np.zeros((ncd,2))
for i in range(ncd):
    l=f.readline()
    ef[i,0]=l.split(' ')[0]
    ef[i,1]=l.split(' ')[1]



nde=int(f.readline())
de = np.zeros((nde,2))
for i in range(nde):
    l=f.readline()
    de[i,0]=l.split(' ')[0]
    de[i,1]=l.split(' ')[1]


ncd=int(f.readline())
cd = np.zeros((ncd,2))
for i in range(ncd):
    l=f.readline()
    cd[i,0]=l.split(' ')[0]
    cd[i,1]=l.split(' ')[1]



nbc=int(f.readline())
bc = np.zeros((nbc,2))
for i in range(nbc):
    l=f.readline()
    bc[i,0]=l.split(' ')[0]
    bc[i,1]=l.split(' ')[1]
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#bordo da esquerda

nab=int(f.readline())
rl = np.zeros((nab,2))
for i in range(nab):
    l=f.readline()
    rl[i,0]=l.split(' ')[0]
    rl[i,1]=l.split(' ')[1]
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#juncao dos vetores que compoe o bordo de baixo

rb = np.zeros((63,2))

for i in range(nbc):
  rb[i,0]=gf[i,0]
  rb[i,1]=gf[i,1]

for i in range(1,ncd):
  rb[(i+nbc-1),0]=ef[i,0]
  rb[(i+nbc-1),1]=ef[i,1]

for i in range(1,nde):
  rb[(i+nbc+ncd-2),0]=de[i,0]
  rb[(i+nbc+ncd-2),1]=de[i,1]

for i in range(1,ncd):
  rb[(i+nbc+ncd+nde-3),0]=cd[i,0]
  rb[(i+nbc+ncd+nde-3),1]=cd[i,1]

for i in range(1,nbc):
  rb[(i+nbc+ncd+nde+ncd-4),0]=bc[i,0]
  rb[(i+nbc+ncd+nde+ncd-4),1]=bc[i,1]


#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
gridx = np.zeros((nab,63))
gridy = np.zeros((nab,63))

gridx[0,:]=rb[:,0]
gridx[nab-1,:]=rt[:,0]
gridx[:,0]=rl[:,0]
gridx[:,63-1]=rr[:,0]

gridy[0,:]=rb[:,1]
gridy[nab-1,:]=rt[:,1]
gridy[:,0]=rl[:,1]
gridy[:,63-1]=rr[:,1]

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

nx=63        #numero de pontos horizontais, como o aerofolio dado tem 63 pontos e ele representa o bordo de cima, claro que o bordo de baixo tambem deve ter 63 pontos
ny=nab       #numero de pontos verticais, pode ser alterado no programa que gera o bordo ep1.f90
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#metodo transfinita
dx = 1.0/nx
dy = 1.0/ny
for j in range(1,ny-1):
    for i in range(1,nx-1):
        idx = i*dx
        jdy = j*dy
        gridx[j,i] = (1.0-idx)*rl[j,0] + idx*rr[j,0] + (1.0 - jdy)*rb[i,0] + jdy*rt[i,0] - (1.0-idx)*(1.0-jdy)*rb[0,0] - (1.0 - idx)*jdy*rt[0,0] - idx*(1.0-jdy)*rb[nx-1,0] - idx*jdy*rt[nx-1,0]
        gridy[j,i] = (1.0-idx)*rl[j,1] + idx*rr[j,1] + (1.0 - jdy)*rb[i,1] + jdy*rt[i,1] - (1.0-idx)*(1.0-jdy)*rb[0,1] - (1.0 - idx)*jdy*rt[0,1] - idx*(1.0-jdy)*rb[nx-1,1] - idx*jdy*rt[nx-1,1]
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#metodo winslow
dxi = 1.0/nx
deta = 1.0/ny
N = 100
for k in range(N):
    for j in range(1,ny-1):
        for i in range(1,nx-1):
            dxdxi = (gridx[j,i+1]-gridx[j,i-1])/(2.0*dxi)
            dydxi = (gridy[j,i+1]-gridy[j,i-1])/(2.0*dxi)
            dxdeta = (gridx[j+1,i]-gridx[j-1,i])/(2.0*deta)
            dydeta = (gridy[j+1,i]-gridy[j-1,i])/(2.0*deta)       
            g11 = dxdxi**2 + dydxi**2
            g22 = dxdeta**2 + dydeta**2
            g12 = dxdxi*dxdeta + dydxi*dydeta
            a = 4.0*(deta**2)*g22
            b = 4.0*dxi*deta*g12
            c = 4.0*(dxi**2)*g11
            gridx[j,i] = (1.0/(2*(a+c)))*(a*(gridx[j,i+1]+gridx[j,i-1])+c*(gridx[j+1,i]+gridx[j-1,i]))-0.5*(b*(gridx[j+1,i+1]+gridx[j-1,i-1]-gridx[j+1,i-1]-gridx[j-1,i+1]))
            gridy[j,i] = (1.0/(2*(a+c)))*(a*(gridy[j,i+1]+gridy[j,i-1])+c*(gridy[j+1,i]+gridy[j-1,i]))-0.5*(b*(gridy[j+1,i+1]+gridy[j-1,i-1]-gridy[j+1,i-1]-gridy[j-1,i+1]))
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#gera arquivo vtk 

def grid2vtk(gx, gy ,nab):
  n, m = gx.shape
  f = open( str(nab) + 'naca.vtk', 'wt')

  f.write('# vtk DataFile Version 2.0\n')
  f.write('file generated by grid2vtk\n')
  f.write('ASCII\n')
  f.write('DATASET UNSTRUCTURED_GRID\n')
  f.write('POINTS ' + str(n * m) + ' float\n')
  for i in range(n):
      for j in range(m):
          f.write("{:.4f}".format(gx[i, j]) + ' ' + "{:.4f}".format(gy[i, j]) + ' 0.0\n')

  f.write('\n')
  nc = (n - 1) * (m - 1)
  f.write('CELLS ' + str(nc) + ' ' + str(nc * 5) + '\n')
  for i in range(n - 1):
      for j in range(m - 1):
          f.write('4 ' + str(i * m + j) + ' ' + str(i * m + j + 1) + ' ' + str((i + 1) * m + j + 1) + ' ' + str(
              (i + 1) * m + j) + '\n')

  f.write('\n')
  f.write('CELL_TYPES ' + str(nc) + '\n')
  f.write(nc * '7 ')
  f.write('\n')

  f.close()

grid2vtk(gridx, gridy , nab)
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#COMANDOS PARA PLOTAR A MALHA
for i in range(ny):
    plt.plot(gridx[i,:],gridy[i,:],color='gray')
for i in range(nx):
    plt.plot(gridx[:,i],gridy[:,i],color='gray')

plt.plot(rt[:,0],rt[:,1])
plt.plot(rb[:,0],rb[:,1])
plt.plot(rl[:,0],rl[:,1])
plt.plot(rr[:,0],rr[:,1])
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# COMANDOS PARA PLOTAR O BORDO
#plt.plot(rt[:,0],rt[:,1],color='gray')
#plt.plot(rr[:,0],rr[:,1],color='yellow')
#plt.plot(gf[:,0],gf[:,1],color='blue')
#plt.plot(ef[:,0],ef[:,1],color='green')
#plt.plot(de[:,0],de[:,1],color='red')
#plt.plot(cd[:,0],cd[:,1],color='pink')
#plt.plot(bc[:,0],bc[:,1],color='brown')
#plt.plot(rl[:,0],rl[:,1],color='orange')


#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
plt.show()
f.close()






