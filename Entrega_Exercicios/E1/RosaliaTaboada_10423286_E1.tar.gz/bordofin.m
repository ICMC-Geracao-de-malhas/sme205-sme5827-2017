% A, B, C, D, E, F, G, H sao pontos do quadrado UNITARIO
% A2, B2, C2, D2, E2, F2, G2, H2 sao pontos do quadrado FISICO
% para dominio fechado
% Usa naca012.txt
% gera pontosrtl.txt
clc
A=[0 1.0];  A2=[1 0]; % Depois de redefine A2
B=[0 0];   B2=[1.5 0];  % Depois de redefine B2
C=[0.1 0]; C2=[1.5 1.0];
D=[0.4 0]; D2=[-1.0 1.0];
E=[0.6 0]; E2=[-1.0 -1.0];
F=[0.9 0]; F2=[1.5 -1.0];
G=[1.0 0];  G2=B2;  % Depois de redefine G2
H=[1.0 1.0];  H2=A2; % Depois de redefine H2
 
% Lendo pontos de AH - buraco
bur=fopen('naca012.txt');
[Bu, count] = fscanf(bur,'%f');
%for i=1:k
%    F(i) = Bu(2*i-1); % Primeira coluna do naca012.txt
%    G(i) = Bu(2*i);   % Segunda coluna do naca012.txt
%end
k=count/2;  % K TEM QUE SER IMPAR
%A2 = [Bu(1) Bu(2)];    % re-definindo A2
%B2 = [1.5 Bu(2)];     % re-definindo B2
%H2 = [Bu(2*k - 1) Bu(2*k)];  % re-definindo H2
%G2 = [1.5 Bu(2*k)];   % re-definindo G2

w= round(k/7); % numero de pontos de BC e FG
n=100;
z= (k-7-4*w)/2;  % PARA ESTA PARTE É IMPORTANTE k IMPAR % numero de pontos de CD e EF

% cont=0; % contador

fid=fopen('pontosrtl.txt','w');

% --- 1 ---- pedaco del cuadrado: AH
    f1 = zeros(k,1);
    f1y = zeros(k,1);
    fprintf(fid,'%i\n',k);
    for i=1:k
        f1(i)=Bu(2*i-1);
        f1y(i)= Bu(2*i);
        fprintf(fid,'%f\t %f\n',Bu(2*i-1),Bu(2*i));
    end
    
 % --- 2---- pedaco del cuadrado: BG
    fprintf(fid,'%i\n',k);
    % -- pedaco BC --- w pontos interiores
        f2 = zeros(w+1,1);
        %f2y = zeros(w+1,1);
        dw = (C(1)-B(1))/(w+1);  % Vai gerar w+2 pontos
        for i=1:w+2   % Só vai registrar w+1 pontos desde B+dw até C
            xi = B(1)+(i-1)*dw; %% modifiquei
            zi= xi/C(1);
            u1 = zi*C2(2) + (1-zi)*B2(2);
            %u1 = (1-zi)*C2(2) + zi*B2(2);
            f2(i)=u1;
            fprintf(fid,'%f\t %f\n',B2(1),u1);
          %  cont =  cont + 1;
        end    
        f2y=B2(1)*ones(w+2,1);
        
    % -- pedaco CD ---- z pontos interiores
        f4 = zeros(z+1,1);
        dz = (D(1)-C(1))/(z+1);  % Vai gerar z+2 pontos
        for i=2:z+2
            xi = C(1)+(i-1)*dz;
            u1 = (D2(1) - C2(1))*(xi - C(1))/(D(1) - C(1))  + C2(1);
            %u1 = (D2(1) - C2(1))*(D(1)-xi)/(D(1) - C(1))  + C2(1);
            f4(i-1) = u1;
            fprintf(fid,'%f\t %f\n',u1,D2(2));
  %          cont =  cont + 1;
        end
        f4y = D2(2)*ones(z+1,1);
     
    % -- pedaco DE ---- 2w+1 pontos interiores
        l=2*w+1;
        f5 = zeros(l+1,1);
        dl = (E(1)-D(1))/(l+1);  % Vai gerar 2w+1+2 pontos
        for i=2:l+2
            xi = D(1)+(i-1)*dl;
            u1 = (E2(2) - D2(2))*(xi - D(1))/(E(1) - D(1))  + D2(2);
            %u1 = (E2(2) - D2(2))*(E(1)-xi)/(E(1) - D(1))  + D2(2);
            f5(i-1) = u1;
            fprintf(fid,'%f\t %f\n',D2(1),u1);
   %         cont =  cont + 1;
        end
        f5y = D2(1)*ones(l+1,1);
      
   % -- pedaco EF ---- z pontos interiores
       dz = (F(1)-E(1))/(z+1);  % Vai gerar z+2 pontos
       f6 = zeros(z+1,1);
        for i=2:z+2
            xi = E(1)+(i-1)*dz;
            u1 = (F2(1) - D2(1))*(xi - E(1))/(F(1) - E(1))  + E2(1);
            %u1 = (F2(1) - D2(1))*(F(1)-xi)/(F(1) - E(1))  + E2(1);
            f6(i-1)=u1;
            fprintf(fid,'%f\t %f\n',u1,E2(2));
    %        cont =  cont + 1;
        end
        f6y= E2(2)*ones(z+1,1);
        
  % -- pedaco FG ---- w pontos interiores
        f7 = zeros (w+1,1);
        dw = (G(1)-F(1))/(w+1);  % Vai gerar w+2 pontos
        for i=2:w+2
            xi = F(1)+(i-1)*dw;
            u1 = (G2(2) - F2(2))*(xi - G(1))/(G(1) - F(1))  + G2(2);
            %u1 = (G2(2) - F2(2))*(F(1)-xi)/(G(1) - F(1))  + G2(2);
            f7(i-1)=u1;
            fprintf(fid,'%f\t %f\n',F2(1),u1);
     %       cont =  cont + 1;
        end
        f7y = F2(1)*ones(w+1,1);
%         
%          
    
% pedaco del cuadrado: AB ---- n-2 pontos interiores
    f3 = zeros(n,1);
    dy = (B(2)-A(2))/(n-1);  %---- n pontos 
    fprintf(fid,'%i\n',n);
    for i=1 : n
        yi = A(2) + (i-1)*dy;
        % u1 = (1-yi)*B2(1) + yi*A2(1);
        u1 = yi*B2(1) + (1-yi)*A2(1);
        f3(i)=u1;
        fprintf(fid,'%f\t %f\n',u1,A2(2));
    end    
    f3y=A2(2)*ones(n,1);
    
% pedaco del cuadrado: GH ---- n-2 pontos interiores
       f8 = zeros(n,1);
       dy = (H(2)-G(2))/(n-1); %---- n pontos 
       fprintf(fid,'%i\n',n);
        for i=1:n
            yi = G(2) + (i-1)*dy;
            u1 = (H2(1) - G2(1))*yi + G2(1);
            %u1 = H2(1)*(1-yi) + G2(1)*yi;
            f8(i)=u1;
            % (1-yi)*B2(1) + yi*A2(1);
            fprintf(fid,'%f\t %f\n',u1,H2(2));
        end    
        f8y = H2(2)*ones(n,1);
fclose('all');

    plot(f1,f1y,'b*-') % padaco AH
    hold on
    plot(f3,f3y,'r*-')  % pedaco AB
    plot(f2y,f2,'b*-')  % pedaco BC
    plot(f4,f4y,'c*-')  % pedaco CD
    plot(f5y,f5,'m*-')  % pedaco DE
    plot(f6,f6y,'r*-')  % pedaco EF
    plot(f7y,f7,'m*-')  % pedaco FG
    plot(f8,f8y,'g*-')  % pedaco GH
    hold off