% Usa o arquivo pontosrtl.txt
% Gera malhasversfin.vtk

doc =fopen('pontosrtl.txt');

%Top
numtop = fscanf(doc,'%d',[1]);
Btop = zeros(2,numtop);
Btop = fscanf(doc,'%f',[2, numtop]); %pontos do ladp TOp --- Btop(1,:)= xi & Btop(2,:)= yj

%Bottom
numbot = fscanf(doc,'%d',[1]);
Bbot= zeros(2,numbot);
Bbot = fscanf(doc,'%f',[2, numbot]); %pontos do ladp BOTTOM --- Bbot(1,:)= xi & Bbot(2,:)= yj

%Left
numlef = fscanf(doc,'%d',[1]);
Blef= zeros(2,numlef);
Blef = fscanf(doc,'%f',[2, numlef]); %pontos do ladp LEFT --- Blef(1,:)= xi & Blef(2,:)= yj

%Right
numrig = fscanf(doc,'%d',[1]);
Brig= zeros(2,numrig);
Brig = fscanf(doc,'%f',[2, numrig]); %pontos do lado RIGHT --- Brig(1,:)= xi & Brig(2,:)= yj

fclose('all');
% 
Gridx = zeros(numtop, numrig);
Gridy = zeros(numtop, numrig);

Gridx(:,1)=Bbot(1,:)';  % primeira componente da funcao Bbut
Gridx(:,numrig)=Btop(1,:);  % primeira componente da funcao Btop
Gridx(1,:)=Blef(1,:);  % primeira componente da funcao Bleft
Gridx(numtop,:)=Brig(1,:); % primeira componente da funcao Bright

Gridy(:,1)=Bbot(2,:);  % segunda componente da funcao Bbut
Gridy(:,numrig)=Btop(2,:);  % segunda componente da funcao Btop
Gridy(1,:)=Blef(2,:);  % segunda componente da funcao Bleft
Gridy(numtop,:)=Brig(2,:); % segunda componente da funcao Bright

% Transfinita
dx = 1.0/(numtop-1);
dy = 1.0/(numrig-1);

 for i= 2 : numtop-1
     for j= 2 : numrig-1
          idx = (i-1)*dx;
          %ipdx(i-1) = (i-1)*dx;
          jdy = (j-1)*dy;
         % gridx[j,i] = (1.0-idx)*rl[j,0] + idx*rr[j,0] + (1.0 - jdy)*rb[i,0] + jdy*rt[i,0] - (1.0-idx)*(1.0-jdy)*rb[0,0] - (1.0 - idx)*jdy*rt[0,0] - idx*(1.0-jdy)*rb[nT-1,0] - idx*jdy*rt[nT-1,0]
         Gridx(i,j) = (1.0-idx)*Blef(1,j) + idx*Brig(1,j)+ (1.0 - jdy)*Bbot(1,i)+ jdy*Btop(1,i)-(1.0-idx)*(1.0-jdy)*Brig(1,1)- (1.0 - idx)*jdy*Btop(1,1)- idx*(1.0-jdy)*Bbot(1,numtop)- idx*jdy*Brig(1,numrig);
         % gridy[j,i] = (1.0-idx)*rl[j,1] + idx*rr[j,1] + (1.0 - jdy)*rb[i,1] + jdy*rt[i,1] - (1.0-idx)*(1.0-jdy)*rb[0,1] - (1.0 - idx)*jdy*rt[0,1] - idx*(1.0-jdy)*rb[nT-1,1] - idx*jdy*rt[nT-1,1]
         Gridy(i,j) = (1.0-idx)*Blef(2,j) + idx*Brig(2,j)+ (1.0 - jdy)*Bbot(2,i)+ jdy*Btop(2,i)-(1.0-idx)*(1.0-jdy)*Brig(2,1)- (1.0 - idx)*jdy*Btop(2,1)- idx*(1.0-jdy)*Bbot(2,numtop)- idx*jdy*Brig(2,numrig);
     end
 end
 
 % Winslow

deta = 1.0/(numtop-1);
dxi = 1.0/(numrig-1);
% 
N = 100;
for k = 1:N
    for i= 2 : numtop-1
       for j= 2 : numrig-1

            dxdxi = (Gridx(i + 1,j) - Gridx(i - 1,j)) / (2 * dxi);
            dydxi = (Gridy(i + 1,j) - Gridy(i - 1,j)) / (2 * dxi);

            dxdeta = (Gridx(i,j + 1) - Gridx(i,j - 1)) / (2 * deta);
            dydeta = (Gridy(i,j + 1) - Gridy(i,j - 1)) / (2 * deta);
% 
            g11 = dxdxi^2 + dydxi^2;
            g22 = dxdeta^2 + dydeta^2;
            g12 = dxdxi*dxdeta + dydxi*dydeta;

            a = 4.0 * (deta^2)*g22;
            b = 4.0 * dxi*deta*g12;
            c = 4.0 * (dxi^2)*g11;
% 
%             gridx[j, i] = (1.0 / (2 * (a + c))) * (a*(gridx[j, i + 1] + gridx[j, i - 1]) + c*(gridx[j + 1, i] + gridx[j - 1, i]) - 0.5 *b*(gridx[j + 1,i + 1] + gridx[j - 1,i - 1] - gridx[j + 1,i - 1] - gridx[j - 1,i + 1]))
            Gridx(i,j) = (1.0 / (2*(a + c))) * (a*(Gridx(i+1,j) + Gridx(i-1,j)) + c*(Gridx(i,j+1) + Gridx(i,j-1)) - 0.5 *b*(Gridx(i+1,j+1) + Gridx(i-1,j-1) - Gridx(i-1,j+1) - Gridx(i+1,j-1)));
%             gridy[j, i] = (1.0 / (2 * (a + c))) * (a*(gridy[j, i + 1] + gridy[j, i - 1]) + c*(gridy[j + 1, i] + gridy[j - 1, i]) - 0.5 *b*(gridy[j + 1,i + 1] + gridy[j - 1,i - 1] - gridy[j + 1,i - 1] - gridy[j - 1,i + 1]))
            Gridy(i,j) = (1.0 / (2*(a + c))) * (a*(Gridy(i+1,j) + Gridy(i-1,j)) + c*(Gridy(i,j+1) + Gridy(i,j-1)) - 0.5 *b*(Gridy(i+1,j+1) + Gridy(i-1,j-1) - Gridy(i-1,j+1) - Gridy(i+1,j-1)));
       end
    end
end
% 
fid = fopen('malhaversfin.vtk', 'wt');
fprintf(fid,'# vtk DataFile Version 3.0\n');
fprintf(fid,'Comment goes here\n');
fprintf(fid, 'ASCII\n');
fprintf(fid,'DATASET STRUCTURED_GRID\n');
fprintf(fid, 'DIMENSIONS %d %d %d\n', numtop, numrig, 1);
% 
fprintf(fid, 'POINTS %d float\n', numrig*numtop);
for j = 1:numrig
    for i = 1:numtop
        fprintf(fid, '%5.5f %5.5f %d\n', Gridx(i,j),Gridy(i,j),0);
    end
end
% 
Cells = (numtop-1)*(numrig-1);
% 
fprintf(fid, 'POINT_DATA %d \n', numrig*numtop);
% 
 plot(Gridx(1,:),Gridy(1,:));
 hold on
 for i=2:numtop
     plot(Gridx(i,:),Gridy(i,:), 'm')
 end
 for i=1:numrig
     plot(Gridx(:,i),Gridy(:,i), 'b')
 end
plot(Btop(1,:),Btop(2,:), 'g')
plot(Bbot(1,:),Bbot(2,:), 'g')
plot(Blef(1,:),Blef(2,:), 'g')
plot(Brig(1,:),Brig(2,:), 'g')
hold off