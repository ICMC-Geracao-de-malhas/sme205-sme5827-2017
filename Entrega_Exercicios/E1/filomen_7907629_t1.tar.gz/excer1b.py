import sys
import numpy as np
import matplotlib.pyplot as plt


print len(sys.argv)
if ( len(sys.argv) <  4):
  sys.exit("Wrong parameters!")

f = open(sys.argv[1],'rt')
#for y in f.read().split('\n'):


ny=int(sys.argv[3])

ah_x=[] #{}, for dictionary
ah_y=[] #{}
counter=0
for l in f.readlines():
  numbers_float = map(float, l.split())
  ah_x.append(numbers_float[0])
  ah_y.append(numbers_float[1])
  counter=counter+1

ah_size=counter
#consider grid from bottom to top  ^
#                                  |
#                                  0 --> 


Lx=-1.0
Rx= 2.0

Ty= 1.0
By=-1.0


#AH
rt = np.zeros((ah_size,2))
for i in range(ah_size): 
  rt[i,0]=ah_x[i]
  rt[i,1]=ah_y[i]

#AB & HG


deltaAB=(Rx - ah_x[0] )/ny # ==deltaHG

rl = np.zeros((ny,2))
rr = np.zeros((ny,2))

for i in range(ny): 
  rl[i,0]=Rx - i*deltaAB #ah_x[0]+i*deltaAB
  rl[i,1]=ah_y[0]

  rr[i,0]=Rx - i*deltaAB #ah_x[ah_size-1]+i*deltaAB
  rr[i,1]=ah_y[ah_size-1]


rb = np.zeros((ah_size,2))

a=int(ah_size/8)
b=2*a+(ah_size%8)
 
#print "a =",a #a=7
deltaBC= (Ty-By) / (2*a)
deltaCD= (Rx-Lx) / (2*a)
deltaDE= (Ty-By) / (b)
deltaEF= (Rx-Lx) / (2*a)
deltaFG= (Ty-By) / (2*a)


z=0
  #BC
for i in range(a):   
  rb[z,0]=Rx 
  rb[z,1]=ah_y[0] + i*(deltaBC)
  z=z+1
  #CD
for i in range(2*(a)):   
  rb[z,0]=Rx-i*(deltaCD)
  rb[z,1]=Ty
  z=z+1

  #DE
for i in range(b):   
  rb[z,0]=Lx
  rb[z,1]=Ty - i*(deltaDE)
  z=z+1

  #EF
for i in range(2*(a)):   
  rb[z,0]=Lx+i*(deltaEF) 
  rb[z,1]=By
  z=z+1

  #FG
for i in range(a):   
  rb[z,0]=Rx 
  rb[z,1]=By + i*(deltaFG)
  z=z+1 


#print "z", z


f = open(sys.argv[2],'wt')
f.write(str(ah_size))
f.write('\n')
for i in range(ah_size):
    f.write("{:.4f}".format(rt[i,0]))
    f.write(' ')
    f.write("{:.4f}".format(rt[i,1]))
    f.write('\n')
f.write(str(ah_size))
f.write('\n')
for i in range(ah_size):
    f.write("{:.4f}".format(rb[i,0]))
    f.write(' ')
    f.write("{:.4f}".format(rb[i,1]))
    f.write('\n')

f.write(str(ny))
f.write('\n')
for i in range(ny):
    f.write("{:.4f}".format(rl[i,0]))
    f.write(' ')
    f.write("{:.4f}".format(rl[i,1]))
    f.write('\n')

f.write(str(ny))
f.write('\n')
for i in range(ny):
    f.write("{:.4f}".format(rr[i,0]))
    f.write(' ')
    f.write("{:.4f}".format(rr[i,1]))
    f.write('\n')

f.close()


