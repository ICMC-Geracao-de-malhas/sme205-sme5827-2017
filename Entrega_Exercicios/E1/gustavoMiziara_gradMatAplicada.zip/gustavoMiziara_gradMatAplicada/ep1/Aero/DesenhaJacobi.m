function[]=DesenhaJacobi()
	
	global mcsi; % m-pontos na horizontal 
	global neta; % n-pontos na vertical
	global dcsi; % incremento na horizontal
	global deta; % incremento na vertical
	
		
	global qualReta; % unimos os pontos dos aerofolios por retas e ao percorre-lo indicamos sobre qual reta estamos
	global qualRetaExt; 
	global dados; % conjunto de informacoes dos pontos do aerofolio (ja ordenados no sentido anti-horario) juntamente com o comprimento das retas que unem dois pontos consecutivos 
	global dadosExt; 
	global s_0; % parametrizamos as retas que formam o bordo do aerofolio pelo comprimento do arco,sendo s=0 inicio do trajeto,s=1 fim do trajeto,s_0 auxilia ao identificar o comprimento percorrido com a reta atual do percurso
	global s_0Ext;
	
	% pontos abaixo estao no desenho
	global A;
	global C;
	global B;
	global D;
		
	XX=load("XX.txt");
	YY=load("YY.txt");
	hold on;
	plot(XX(:,1),YY(:,1),"m");
	
	plot(XX(1,:),YY(1,:),"k");
	plot(XX,YY,"m","linewidth",1,"marker","o");
	plot(XX',YY',"k","linewidth",1);
	hleg=legend(sprintf('\\xi_{const}'),sprintf('\\eta_{const}'));
	set(hleg,'fontsize',12);
	
	mcsi=size(XX,1);
	neta=size(XX,2);
	dcsi=1/(mcsi-1);
	deta=1/(neta-1);
	
	
	
	
	coor=load('naca012.txt');
	coor=translada(coor,10,2);
	A=coor(1,:);
	C=coor(max(size(coor)),:);
	
	B=[A(1)+10,A(2)];
	D=[C(1)+10,C(2)];
	H=[B(1),B(2)+2];
	G=[0,H(2)];
	F=[0,0];
	E=[D(1),0];
		
	dadosExt=zeros(6,2);
	dadosExt(1,:)=B;
	dadosExt(2,:)=H;
	dadosExt(3,:)=G;
	dadosExt(4,:)=F;
	dadosExt(5,:)=E;
	dadosExt(6,:)=D;
	
	
	qualReta=1;
	qualRetaExt=1;
	[dados]=organizaDados(coor);
	
	[dadosExt]=organizaDados(dadosExt);
	
	s_0=0;
	s_0Ext=0;

	global resu;
	
	s=0:0.001:1;
	ns=max(size(s));
	
	renew();
	boundT=zeros(ns,2);
	boundB=zeros(ns,2);
	boundL=zeros(ns,2);
	boundR=zeros(ns,2);
	
	% desenhar o bordo do dominio
	for i=1:ns
		boundT(i,:)=rT(s(i));
		boundB(i,:)=rB(s(i));
		boundR(i,:)=rR(s(i));
		boundL(i,:)=rL(s(i));
		
		
	end
	
	renew();
	resu=copia(ns,boundT,boundB,boundL,boundR);
	
	plot(boundT(:,1),boundT(:,2),"linestyle","--")%,"linewidth",2);
	
	plot(boundB(:,1),boundB(:,2),"linestyle","--")%,"linewidth",2);
	%plot(boundL(:,1),boundL(:,2),"linewidth",2);
	%plot(boundR(:,1),boundR(:,2),"linewidth",2);
	
	[bT,bB,bL,bR]=verificaBound(resu);
	
	plot(bT(:,1),bT(:,2),"marker","s","markersize",10);
	%hold on;
	plot(bB(:,1),bB(:,2),"marker","s","markersize",10);
	%plot(bL(:,1),bL(:,2),"marker","s","markersize",10)
	%plot(bR(:,1),bR(:,2),"marker","s","markersize",2);
	
	%plot(bbT(:,1),bbT(:,2),"marker","o","color","m");
	%hold on;
	%plot(bbB(:,1),bbB(:,2),"marker","o","color","m");
	%plot(bbL(:,1),bbL(:,2),"marker","o","color","m");
	%plot(bbR(:,1),bbR(:,2),"marker","o","color","m");

	
	text(A(1),A(2)+0.1,"A","FontSize",14,"FontWeight","bold");
	text(B(1),B(2)+0.1,"B","FontSize",14,"FontWeight","bold");
	text(C(1),C(2)-0.1,"C","FontSize",14,"FontWeight","bold");
	text(D(1),D(2)-0.1,"D","FontSize",14,"FontWeight","bold");
	
	
	text(E(1),E(2)-0.1,"E","FontSize",14,"FontWeight","bold");
	text(F(1),F(2)-0.1,"F","FontSize",14,"FontWeight","bold");
	text(G(1),G(2)+0.1,"G","FontSize",14,"FontWeight","bold");
	text(H(1),H(2)+0.1,"H","FontSize",14,"FontWeight","bold");
	
	neta
	mcsi
	title(sprintf('EliticaJacobi Naca012 N_\\xi= %d N_\\eta =%d',mcsi,neta),"FontSize",18);

	
	
end
 function[K]=mij(i,j)
	global mcsi;
	
	K=i+mcsi*(j-1);
	
end


%N>n
function[indices]=interpola(N,n)
	
	indices=zeros(1,n);
	indices(1)=1;
	indices(n)=N;
	
	for i=2:n-1
		indices(i)=ceil((i*(N-1))/(n-1)+(n-N)/(n-1));
	
	end
end

function[resu]=copia(N,boundT,boundB,boundL,boundR)
	
	global mcsi;
	global neta;
	M=mcsi*neta;
	indices_csi=interpola(N,mcsi);
	indices_eta=interpola(N,neta);
	
	%botto;
	j=1;
	hold on
	resu=zeros(2*mcsi*neta,1);
	for i=1:mcsi
		K=mij(i,j);
		kk=indices_csi(i);
		
		resu(K)=boundB(kk,1);
		resu(K+M)=boundB(kk,2);
		
	end
	
	%top
	j=neta;
	for i=1:mcsi
		K=mij(i,j);
		kk=indices_csi(i);
		
		resu(K)=boundT(kk,1);
		resu(K+M)=boundT(kk,2);
		
	end
	
	%left
	i=1;
	
	for j=1:neta
		K=mij(i,j);
		kk=indices_eta(j);
		
		resu(K)=boundL(kk,1);
		resu(K+M)=boundL(kk,2);
		
	end
	
	
	%right
	i=mcsi;
	
	for j=1:neta
		K=mij(i,j);
		kk=indices_eta(j);
		
		resu(K)=boundR(kk,1);
		resu(K+M)=boundR(kk,2);
		
	end

	
	
end


function[bT,bB,bL,bR]=verificaBound(Y)
	
	global mcsi;
	global neta;
	global dcsi;
	global deta;
	
	bT=zeros(mcsi,2);
	bB=zeros(mcsi,2);
	
	bL=zeros(neta,2);
	bR=zeros(neta,2);
	
	M=neta*mcsi;
	%bottom
	j=1;
	
	for i=1:mcsi
		K=mij(i,j);
		bB(i,:)=[Y(K),Y(K+M)];
		
		
	end
	
	%top
	j=neta;
	for i=1:mcsi
		K=mij(i,j);
		bT(i,:)=[Y(K),Y(K+M)];
	end
	
	%left
	i=1;
	
	for j=1:neta
		K=mij(i,j);
		bL(j,:)=[Y(K),Y(K+M)];
	end
	
	
	%right
	i=mcsi;
	
	for j=1:neta
		K=mij(i,j);
		bR(j,:)=[Y(K),Y(K+M)];
	end
	

	
	
	
	
end

function[rb]=rB(s)
	global qualRetaExt;
	global dadosExt;
	global s_0Ext;
	
	if(s>sum(dadosExt(1:qualRetaExt,5))+eps)
		s_0Ext=sum(dadosExt(1:qualRetaExt,5));
		qualRetaExt=qualRetaExt+1;
	end
	
	rb=dadosExt(qualRetaExt,1:2)+(s-s_0Ext)*(dadosExt(qualRetaExt,3:4)-dadosExt(qualRetaExt,1:2))/dadosExt(qualRetaExt,5);
	
end


function[rt]=rT(s)
	
	global qualReta;
	global dados;
	global s_0;
	
	if(s>sum(dados(1:qualReta,5))+eps)
		s_0=sum(dados(1:qualReta,5));
		qualReta=qualReta+1;
	end
	
	rt=dados(qualReta,1:2)+(s-s_0)*(dados(qualReta,3:4)-dados(qualReta,1:2))/dados(qualReta,5);
	
	
end


function[rl]=rL(s)
	global A;
	global B;
	
	rl=B+s*(A-B);
	
	
end

function[rr]=rR(s)
	global C;
	global D;
	
	rr=D+(C-D)*s;
	
end

function[coor_new]=translada(coor,dx,dy)
	
	coor_new=coor;
	d=ones(max(size(coor)),1);
	coor_new(:,1)=coor(:,1)+dx*d;
	coor_new(:,2)=coor(:,2)+dy*d;
	
	
end


function[dados]=organizaDados(coor)
	
	mLinhas=max(size(coor))-1;
	dados=zeros(mLinhas,5);
	
	dados(:,1:2)=coor(1:mLinhas,:);
	dados(:,3:4)=coor(2:mLinhas+1,:);
	comp=zeros(mLinhas,2);
	comp(:,1)=dados(:,1)-dados(:,3);
	comp(:,2)=dados(:,2)-dados(:,4);
	for i=1:mLinhas
		
		dados(i,5)=norm(comp(i,:));
		
	end
	compArco=sum(dados(:,5));
	dados(:,5)=dados(:,5)/compArco;
	
end

function[]=renew()
	
	global s_0;
	global s_0Ext;
	global qualReta;
	global qualRetaExt;
	
	s_0=0;
	s_0Ext=0;
	qualReta=1;
	qualRetaExt=1;

end


