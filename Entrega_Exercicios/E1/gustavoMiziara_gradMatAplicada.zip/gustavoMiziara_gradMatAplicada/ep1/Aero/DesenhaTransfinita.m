function[]=DesenhaTransfinita()
	
	s=0:0.001:1;
	ns=max(size(s));
	
	global qualReta;
	global qualRetaExt;
	global dados;
	global dadosExt;
	global s_0;
	global s_0Ext;
	global A;
	global C;
	global B;
	global D;
	
	
	
	XX=load("NacaTransfXXmcsi_21neta_17.txt");
	YY=load("NacaTransfYYmcsi_21neta_17.txt");
	hold on;
	plot(XX(:,1),YY(:,1),"m");
	
	plot(XX(1,:),YY(1,:),"k");
	plot(XX,YY,"m","linewidth",1,"marker","o");
	plot(XX',YY',"k","linewidth",1);
	hleg=legend(sprintf('\\xi_{const}'),sprintf('\\eta_{const}'));
	set(hleg,'fontsize',12);
	
	mcsi=size(XX,1);
	neta=size(XX,2);
	
	title(sprintf('Transfinita Naca012 N_\\xi= %d N_\\eta =%d',mcsi,neta),"FontSize",18);
	
	
	
	
	
	
	
	
	
	coor=load('naca012.txt');
	
	coor=translada(coor,10,2);
	A=coor(1,:);
	C=coor(max(size(coor)),:);

	
	B=[A(1)+10,A(2)];
	D=[C(1)+10,C(2)];
	H=[B(1),B(2)+2];
	G=[0,H(2)];
	F=[0,0];
	E=[D(1),0];
	
	
	
	dadosExt=zeros(6,2);
	dadosExt(1,:)=B;
	dadosExt(2,:)=H;
	dadosExt(3,:)=G;
	dadosExt(4,:)=F;
	dadosExt(5,:)=E;
	dadosExt(6,:)=D;
	
	
	qualReta=1;
	qualRetaExt=1;
	[dados]=organizaDados(coor);
	
	[dadosExt]=organizaDados(dadosExt);
	
	s_0=0;
	s_0Ext=0;
	
	
	
	boundT=zeros(ns,2);
	boundB=zeros(ns,2);
	boundL=zeros(ns,2);
	boundR=zeros(ns,2);
	
	for i=1:ns
		
		boundT(i,:)=rT(s(i));
		boundB(i,:)=rB(s(i));
		boundR(i,:)=rR(s(i));
		boundL(i,:)=rL(s(i));
		
		
	end
	
	plot(boundT(:,1),boundT(:,2),"linestyle","--");
	%return;
	
	plot(boundL(:,1),boundL(:,2),"linestyle","--");
	plot(boundR(:,1),boundR(:,2),"linestyle","--");
	plot(boundB(:,1),boundB(:,2),"linestyle","--");
	
	
	text(A(1),A(2)+0.1,"A","FontSize",14,"FontWeight","bold");
	text(B(1),B(2)+0.1,"B","FontSize",14,"FontWeight","bold");
	text(C(1),C(2)-0.1,"C","FontSize",14,"FontWeight","bold");
	text(D(1),D(2)-0.1,"D","FontSize",14,"FontWeight","bold");
	
	
	text(E(1),E(2)-0.1,"E","FontSize",14,"FontWeight","bold");
	text(F(1),F(2)-0.1,"F","FontSize",14,"FontWeight","bold");
	text(G(1),G(2)+0.1,"G","FontSize",14,"FontWeight","bold");
	text(H(1),H(2)+0.1,"H","FontSize",14,"FontWeight","bold");
	
	
	
	
	
	
	
	
end

function[dados]=organizaDados(coor)
	
	mLinhas=max(size(coor))-1;
	dados=zeros(mLinhas,5);
	
	dados(:,1:2)=coor(1:mLinhas,:);
	dados(:,3:4)=coor(2:mLinhas+1,:);
	comp=zeros(mLinhas,2);
	comp(:,1)=dados(:,1)-dados(:,3);
	comp(:,2)=dados(:,2)-dados(:,4);
	for i=1:mLinhas
		
		dados(i,5)=norm(comp(i,:));
		
	end
	compArco=sum(dados(:,5));
	dados(:,5)=dados(:,5)/compArco;
	
end



function[rb]=rB(s)
	global qualRetaExt;
	global dadosExt;
	global s_0Ext;
	
	if(s>sum(dadosExt(1:qualRetaExt,5))+eps)
		s_0Ext=sum(dadosExt(1:qualRetaExt,5));
		qualRetaExt=qualRetaExt+1;
	end
	
	rb=dadosExt(qualRetaExt,1:2)+(s-s_0Ext)*(dadosExt(qualRetaExt,3:4)-dadosExt(qualRetaExt,1:2))/dadosExt(qualRetaExt,5);
	
end

function[rt]=rT(s)
	
	global qualReta;
	global dados;
	global s_0;
	
	if(s>sum(dados(1:qualReta,5))+eps)
		s_0=sum(dados(1:qualReta,5));
		qualReta=qualReta+1;
	end
	
	rt=dados(qualReta,1:2)+(s-s_0)*(dados(qualReta,3:4)-dados(qualReta,1:2))/dados(qualReta,5);
	
	
end


function[rl]=rL(s)
	global A;
	global B;
	
	rl=B+s*(A-B);
	
	
end

function[rr]=rR(s)
	global C;
	global D;
	
	rr=D+(C-D)*s;
	
end

function[coor_new]=translada(coor,dx,dy)
	
	coor_new=coor;
	d=ones(max(size(coor)),1);
	coor_new(:,1)=coor(:,1)+dx*d;
	coor_new(:,2)=coor(:,2)+dy*d;
	
	
end

