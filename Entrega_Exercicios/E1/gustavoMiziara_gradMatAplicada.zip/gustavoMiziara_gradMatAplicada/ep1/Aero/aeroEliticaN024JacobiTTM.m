function[]=aeroEliticaN024JacobiTTM()
	
	global mcsi; % m-pontos na horizontal 
	global neta; % n-pontos na vertical
	global dcsi; % incremento na horizontal
	global deta; % incremento na vertical
	
	mcsi=60;
	neta=17;
	dcsi=1/(mcsi-1);
	deta=1/(neta-1);
	
	global qualReta; % unimos os pontos dos aerofolios por retas e ao percorre-lo indicamos sobre qual reta estamos
	global qualRetaExt; 
	global dados; % conjunto de informacoes dos pontos do aerofolio (ja ordenados no sentido anti-horario) juntamente com o comprimento das retas que unem dois pontos consecutivos 
	global dadosExt; 
	global s_0; % parametrizamos as retas que formam o bordo do aerofolio pelo comprimento do arco,sendo s=0 inicio do trajeto,s=1 fim do trajeto,s_0 auxilia ao identificar o comprimento percorrido com a reta atual do percurso
	global s_0Ext;
	
	% pontos abaixo estao no desenho
	global A;
	global C;
	global B;
	global D;
		
	
	coor=load('naca012.txt');
	coor=translada(coor,10,2);
	A=coor(1,:);
	C=coor(max(size(coor)),:);
	
	B=[A(1)+10,A(2)];
	D=[C(1)+10,C(2)];
	H=[B(1),B(2)+2];
	G=[0,H(2)];
	F=[0,0];
	E=[D(1),0];
		
	dadosExt=zeros(6,2);
	dadosExt(1,:)=B;
	dadosExt(2,:)=H;
	dadosExt(3,:)=G;
	dadosExt(4,:)=F;
	dadosExt(5,:)=E;
	dadosExt(6,:)=D;
	
	
	qualReta=1;
	qualRetaExt=1;
	[dados]=organizaDados(coor);
	
	[dadosExt]=organizaDados(dadosExt);
	
	s_0=0;
	s_0Ext=0;
	
	
	
	% chute inicial usando a tecnica transfinita
	global Y0;
	global resu;
	
	global vec_a=1;
	global vec_b=0;
	global vec_c=1;
	global vec_d=0;
	
	global vec_csi=1;
	global vec_eta=1;
	
	global coor_CsiEta=[1 1];
	
	
	
	s=0:0.001:1;
	ns=max(size(s));
	
	renew();
	boundT=zeros(ns,2);
	boundB=zeros(ns,2);
	boundL=zeros(ns,2);
	boundR=zeros(ns,2);
	
	% desenhar o bordo do dominio
	for i=1:ns
		boundT(i,:)=rT(s(i));
		boundB(i,:)=rB(s(i));
		boundR(i,:)=rR(s(i));
		boundL(i,:)=rL(s(i));
		
		
	end
	
	renew();
	resu=copia(ns,boundT,boundB,boundL,boundR);
	
	Y0=inicia();
	
	tic
	
	%o.TolFun=1e-4;
	%o.TolX=1e-4;
	Y=fsolveJacobi(Y0);
	%[Y,Yres,info]=fsolve(@ff,Y0,o);
	
	toc;
	
	
	plot(boundT(:,1),boundT(:,2),"linestyle","--")%,"linewidth",2);
	hold on;
	plot(boundB(:,1),boundB(:,2),"linestyle","--")%,"linewidth",2);
	%plot(boundL(:,1),boundL(:,2),"linewidth",2);
	%plot(boundR(:,1),boundR(:,2),"linewidth",2);
	
	[bT,bB,bL,bR]=verificaBound(resu);
	
	%[bbT,bbB,bbL,bbR]=verificaBound(Y0);

	
	plot(bT(:,1),bT(:,2),"marker","s","markersize",10);
	%hold on;
	plot(bB(:,1),bB(:,2),"marker","s","markersize",10);
	%plot(bL(:,1),bL(:,2),"marker","s","markersize",10)
	%plot(bR(:,1),bR(:,2),"marker","s","markersize",2);
	
	%plot(bbT(:,1),bbT(:,2),"marker","o","color","m");
	%hold on;
	%plot(bbB(:,1),bbB(:,2),"marker","o","color","m");
	%plot(bbL(:,1),bbL(:,2),"marker","o","color","m");
	%plot(bbR(:,1),bbR(:,2),"marker","o","color","m");

	
	
	
	
	
	
	text(A(1),A(2)+0.1,"A","FontSize",14,"FontWeight","bold");
	text(B(1),B(2)+0.1,"B","FontSize",14,"FontWeight","bold");
	text(C(1),C(2)-0.1,"C","FontSize",14,"FontWeight","bold");
	text(D(1),D(2)-0.1,"D","FontSize",14,"FontWeight","bold");
	
	
	text(E(1),E(2)-0.1,"E","FontSize",14,"FontWeight","bold");
	text(F(1),F(2)-0.1,"F","FontSize",14,"FontWeight","bold");
	text(G(1),G(2)+0.1,"G","FontSize",14,"FontWeight","bold");
	text(H(1),H(2)+0.1,"H","FontSize",14,"FontWeight","bold");
	
	title("Elitica","FontSize",14);
	
	XX=zeros(mcsi,neta);
	YY=zeros(mcsi,neta);
	M=mcsi*neta;
	
	% desenhar a solucao
	
	for i=1:mcsi
		for j=1:neta
			K=mij(i,j);
			XX(i,j)=Y(K);
			YY(i,j)=Y(M+K);
		end
	end
	
	plot(XX,YY);
	plot(XX',YY');
	
	save XX.txt XX
	save YY.txt YY
	
end
% mapear da matriz para o vetor 
function[K]=mij(i,j)
	global mcsi;
	
	K=i+mcsi*(j-1);
	
end

%N1>N2
function[indices]=interpola(N,n)
	
	indices=zeros(1,n);
	indices(1)=1;
	indices(n)=N;
	
	for i=2:n-1
		indices(i)=ceil((i*(N-1))/(n-1)+(n-N)/(n-1));
	
	end
end

function[indices]=interpola2(N,n)

	indices=zeros(1,n);
	indices(1)=1;
	indices(n)=N;
	
	for i=2:n-1
		indices(i)=1+ceil((i-1)*(N-1)/(n-1));
	end


end

function[resu]=copia(N,boundT,boundB,boundL,boundR)
	
	global mcsi;
	global neta;
	M=mcsi*neta;
	indices_csi=interpola(N,mcsi)
	indices_eta=interpola(N,neta)
	
	%botto;
	j=1;
	hold on
	resu=zeros(2*mcsi*neta,1);
	for i=1:mcsi
		K=mij(i,j);
		kk=indices_csi(i);
		
		resu(K)=boundB(kk,1);
		resu(K+M)=boundB(kk,2);
		
	end
	
	%top
	j=neta;
	for i=1:mcsi
		K=mij(i,j);
		kk=indices_csi(i);
		
		resu(K)=boundT(kk,1);
		resu(K+M)=boundT(kk,2);
		
	end
	
	%left
	i=1;
	
	for j=1:neta
		K=mij(i,j);
		kk=indices_eta(j);
		
		resu(K)=boundL(kk,1);
		resu(K+M)=boundL(kk,2);
		
	end
	
	
	%right
	i=mcsi;
	
	for j=1:neta
		K=mij(i,j);
		kk=indices_eta(j);
		
		resu(K)=boundR(kk,1);
		resu(K+M)=boundR(kk,2);
		
	end

	
	
end

function[F]=f(Y)
	global mcsi;
	global neta;
	global dcsi;
	global deta;
	
	renew();

	
	mF=max(size(Y));
	F=zeros(mF,1);
	
	
	M=neta*mcsi;
	%bottom
	j=1;
	for i=1:mcsi
		K=mij(i,j);
		csi=(i-1)*dcsi;
		p=rB(csi);
		F(K)=Y(K)-p(1);
		F(K+M)=Y(K+M)-p(2);
		
	end
	
	%top
	j=neta;
	for i=1:mcsi
		K=mij(i,j);
		csi=(i-1)*dcsi;
		p=rT(csi);
		F(K)=Y(K)-p(1);
		F(K+M)=Y(K+M)-p(2);
	end
	
	%left
	i=1;
	
	for j=1:neta
		K=mij(i,j);
		eta=(j-1)*deta;
		p=rL(eta);
		F(K)=Y(K)-p(1);
		F(K+M)=Y(K+M)-p(2);
	end
	
	
	%right
	i=mcsi;
	
	
	for j=1:neta
		K=mij(i,j);
		eta=(j-1)*deta;
		p=rR(eta);
		F(K)=Y(K)-p(1);
		F(K+M)=Y(K+M)-p(2);
	end
	
	%agora os pontos internos
	for i=2:mcsi-1
		for j=2:neta-1
			
			ij=mij(i,j);
			
			iij=mij(i+1,j);
			i_1j=mij(i-1,j);
			
			ijj=mij(i,j+1);
			ij_1=mij(i,j-1);
			
			iijj=mij(i+1,j+1);
			i_1j_1=mij(i-1,j-1);
			i_1jj=mij(i-1,j+1);
			iij_1=mij(i+1,j-1);
			
			
			
			
			
			
			g_11=g11(Y(iij),Y(i_1j),Y(M+iij),Y(M+i_1j),dcsi);
			
			g_22=g22(Y(ijj),Y(ij_1),Y(M+ijj),Y(M+ij_1),deta);
			
			g_12=g12(Y(iij),Y(i_1j),  Y(ijj),Y(ij_1),  Y(M+iij),Y(M+i_1j),  Y(M+ijj),Y(M+ij_1),  deta,dcsi);
			
			
			xcc=fcc(Y(ij),Y(iij),Y(i_1j),dcsi);
			xuu=fuu(Y(ij),Y(ijj),Y(ij_1),deta);
			xuc=fuc(Y(iijj),Y(i_1j_1),Y(i_1jj),Y(iij_1),dcsi,deta);
			
			
			ycc=fcc(Y(M+ij),Y(M+iij),Y(M+i_1j),dcsi);
			yuu=fuu(Y(M+ij),Y(M+ijj),Y(M+ij_1),deta);
			yuc=fuc(Y(M+iijj),Y(M+i_1j_1),Y(M+i_1jj),Y(M+iij_1),dcsi,deta);
			
			F(ij)=g_22*xcc-2*g_12*xuc+g_11*xuu;
			F(M+ij)=g_22*ycc-2*g_12*yuc+g_11*yuu;
			
			
			
		end
	
	end
	
	
	
	
	


end

function[F]=ff(Y)
	global mcsi;
	global neta;
	global dcsi;
	global deta;
	global Y0;
	global resu;
	%renew();

	
	mF=max(size(Y));
	F=zeros(mF,1);
	
	
	M=neta*mcsi;
	F=Y-resu;
	
	%agora os pontos internos
	for i=2:mcsi-1
		for j=2:neta-1
			
			ij=mij(i,j);
			
			iij=mij(i+1,j);
			i_1j=mij(i-1,j);
			
			ijj=mij(i,j+1);
			ij_1=mij(i,j-1);
			
			iijj=mij(i+1,j+1);
			i_1j_1=mij(i-1,j-1);
			i_1jj=mij(i-1,j+1);
			iij_1=mij(i+1,j-1);
			
			
			
			
			
			
			g_11=g11(Y(iij),Y(i_1j),Y(M+iij),Y(M+i_1j),dcsi);
			
			g_22=g22(Y(ijj),Y(ij_1),Y(M+ijj),Y(M+ij_1),deta);
			
			g_12=g12(Y(iij),Y(i_1j),  Y(ijj),Y(ij_1),  Y(M+iij),Y(M+i_1j),  Y(M+ijj),Y(M+ij_1),  deta,dcsi);
			
			
			xcc=fcc(Y(ij),Y(iij),Y(i_1j),dcsi);
			xuu=fuu(Y(ij),Y(ijj),Y(ij_1),deta);
			xuc=fuc(Y(iijj),Y(i_1j_1),Y(i_1jj),Y(iij_1),dcsi,deta);
			
			
			ycc=fcc(Y(M+ij),Y(M+iij),Y(M+i_1j),dcsi);
			yuu=fuu(Y(M+ij),Y(M+ijj),Y(M+ij_1),deta);
			yuc=fuc(Y(M+iijj),Y(M+i_1j_1),Y(M+i_1jj),Y(M+iij_1),dcsi,deta);
			
			F(ij)=g_22*xcc-2*g_12*xuc+g_11*xuu;
			F(M+ij)=g_22*ycc-2*g_12*yuc+g_11*yuu;
			
			
			
		end
	
	end
	
	
	
	
	


end
function[Y]=fsolveJacobi(Y0)
	
	Y_old=Y0;
	for k=1:50
	Y_new=fJacobi(Y_old);
	Y_old=Y_new;
	end
	Y=Y_new;
	
end

function[F]=fJacobi(Y)
	global mcsi;
	global neta;
	global dcsi;
	global deta;
	%global Y0;
	global resu;
	mF=max(size(Y));
	F=zeros(mF,1);
	M=mcsi*neta;
	F=resu;
	
	%now the inner points
	for i=2:mcsi-1
		for j=2:neta-1
			
			ij=mij(i,j);
			
			iij=mij(i+1,j);
			i_1j=mij(i-1,j);
			
			ijj=mij(i,j+1);
			ij_1=mij(i,j-1);
			
			iijj=mij(i+1,j+1);
			i_1j_1=mij(i-1,j-1);
			i_1jj=mij(i-1,j+1);
			iij_1=mij(i+1,j-1);
			
			
			
			
			
			
			g_11=g11(Y(iij),Y(i_1j),Y(M+iij),Y(M+i_1j),dcsi);
			
			g_22=g22(Y(ijj),Y(ij_1),Y(M+ijj),Y(M+ij_1),deta);
			
			g_12=g12(Y(iij),Y(i_1j),  Y(ijj),Y(ij_1),  Y(M+iij),Y(M+i_1j),  Y(M+ijj),Y(M+ij_1),  deta,dcsi);
			
			
			%xcc=fcc(Y(ij),Y(iij),Y(i_1j),dcsi);
			%xuu=fuu(Y(ij),Y(ijj),Y(ij_1),deta);
			xuc=fuc(Y(iijj),Y(i_1j_1),Y(i_1jj),Y(iij_1),dcsi,deta);
			
			
			%ycc=fcc(Y(M+ij),Y(M+iij),Y(M+i_1j),dcsi);
			%yuu=fuu(Y(M+ij),Y(M+ijj),Y(M+ij_1),deta);
			yuc=fuc(Y(M+iijj),Y(M+i_1j_1),Y(M+i_1jj),Y(M+iij_1),dcsi,deta);
			
			%F(ij)=g_22*xcc-2*g_12*xuc+g_11*xuu;
			F(ij)=fof(Y(iij),Y(i_1j),dcsi,Y(ijj),Y(ij_1),deta,g_11,g_12,g_22,xuc);
			
			
			%F(M+ij)=g_22*ycc-2*g_12*yuc+g_11*yuu;
			F(M+ij)=fof(Y(iij+M),Y(i_1j+M),dcsi,Y(ijj+M),Y(ij_1+M),deta,g_11,g_12,g_22,yuc);
			
			
		end
	
	end
	
	
	
	
	


end

function[F]=fJacobiTTM(Y)
	global mcsi;
	global neta;
	global dcsi;
	global deta;
	
	global resu;
	mF=max(size(Y));
	F=zeros(mF,1);
	M=mcsi*neta;
	F=resu;
	
	%now the inner points
	for i=2:mcsi-1
		for j=2:neta-1
			
			ij=mij(i,j);
			
			iij=mij(i+1,j);
			i_1j=mij(i-1,j);
			
			ijj=mij(i,j+1);
			ij_1=mij(i,j-1);
			
			iijj=mij(i+1,j+1);
			i_1j_1=mij(i-1,j-1);
			i_1jj=mij(i-1,j+1);
			iij_1=mij(i+1,j-1);
			
			
			
			
			
			
			g_11=g11(Y(iij),Y(i_1j),Y(M+iij),Y(M+i_1j),dcsi);
			
			g_22=g22(Y(ijj),Y(ij_1),Y(M+ijj),Y(M+ij_1),deta);
			
			g_12=g12(Y(iij),Y(i_1j),  Y(ijj),Y(ij_1),  Y(M+iij),Y(M+i_1j),  Y(M+ijj),Y(M+ij_1),  deta,dcsi);
			
			
			xuc=fuc(Y(iijj),Y(i_1j_1),Y(i_1jj),Y(iij_1),dcsi,deta);
			yuc=fuc(Y(M+iijj),Y(M+i_1j_1),Y(M+i_1jj),Y(M+iij_1),dcsi,deta);
			
			
			F(ij)=fof(Y(iij),Y(i_1j),dcsi,Y(ijj),Y(ij_1),deta,g_11,g_12,g_22,xuc);
			F(M+ij)=fof(Y(iij+M),Y(i_1j+M),dcsi,Y(ijj+M),Y(ij_1+M),deta,g_11,g_12,g_22,yuc);
			
			
		end
	
	end
	
	
	
	
	


end










function[bT,bB,bL,bR]=verificaBound(Y)
	
	global mcsi;
	global neta;
	global dcsi;
	global deta;
	
	bT=zeros(mcsi,2);
	bB=zeros(mcsi,2);
	
	bL=zeros(neta,2);
	bR=zeros(neta,2);
	
	M=neta*mcsi;
	%bottom
	j=1;
	
	for i=1:mcsi
		K=mij(i,j);
		bB(i,:)=[Y(K),Y(K+M)];
		
		
	end
	
	%top
	j=neta;
	for i=1:mcsi
		K=mij(i,j);
		bT(i,:)=[Y(K),Y(K+M)];
	end
	
	%left
	i=1;
	
	for j=1:neta
		K=mij(i,j);
		bL(j,:)=[Y(K),Y(K+M)];
	end
	
	
	%right
	i=mcsi;
	
	for j=1:neta
		K=mij(i,j);
		bR(j,:)=[Y(K),Y(K+M)];
	end
	

	
	
	
	
end






function[d]=fc(fiij,fi_1j,dcsi)
	
	d=(fiij-fi_1j)/(2*dcsi);
	
end

function[d]=fu(fijj,fij_1,deta)
	
	d=(fijj-fij_1)/(2*deta);
	
end


function[d]=fcc(fij,fiij,fi_1j,dcsi)
	
	d=(fiij-2*fij+fi_1j)/(dcsi^2);
	
	
end

function[d]=fcc_ij(fiij,fi_1j,dcsi)
	
	d=(fiij+fi_1j)/(dcsi^2);
	
	
end


function[d]=fuu_ij(fijj,fij_1,deta)
	
	d=(fijj+fij_1)/(deta^2);
	
	
end




function[fij]=fof(fiij,fi_1j,dcsi,fijj,fij_1,deta,g_11,g_12,g_22,f_uc)
	
	aij=2*g_22/(dcsi^2);
	bij=2*g_11/(deta^2);
	
	
	fij=(g_22*fcc_ij(fiij,fi_1j,dcsi)-2*g_12*f_uc+g_11*fuu_ij(fijj,fij_1,deta))/(aij+bij);
	
end

function[p]=P(csi,vec_a,vec_csi,vec_c,vec_b,vec_d,coor_CsiEta)
	
	M=max(size(vec_a)); 
	N=max(size(vec_b)); 

	sumM=0;
	sumN=0;
	 
	for i=1:M
		
		sumM=sumM+vec_a(i)*sign(csi-vec_csi(i))*exp(-vec_c(i)*abs(csi-vec_csi(i)));
		
	end
	
	for j=1:N
		
		sumN=sumN+vec_b(j)*sign(csi-coor_CsiEta(j,1))*exp(-vec_d(j)*sqrt((csi-coor_CsiEta(j,1))^2+(eta-coor_CsiEta(j,2))^2));
	end
	
	p=sumM+sumN;

end

function[q]=Q(eta,vec_a,vec_eta,vec_c,vec_b,vec_d,coor_CsiEta)
	
	
	M=max(size(vec_a)); 
	N=max(size(vec_b)); 

	sumM=0;
	sumN=0;
	 
	for i=1:M
		
		sumM=sumM+vec_a(i)*sign(eta-vec_eta(i))*exp(-vec_c(i)*abs(eta-vec_eta(i)));
		
	end
	
	for j=1:N
		
		sumN=sumN+vec_b(j)*sign(eta-coor_CsiEta(j,2))*exp(-vec_d(j)*sqrt((csi-coorCsi_Eta(j,1))^2+(eta-coor_CsiEta(j,2))^2));
	end
	
	p=sumM+sumN;

	
	
	
	
end




function[fij]=fofExt(fiij,fi_1j,dcsi,fijj,fij_1,deta,g_11,g_12,g_22,f_uc,p,q)
	
	aij=2*g_22/(dcsi^2);
	bij=2*g_11/(deta^2);
	
	g=g_11*g_12-(g_12)^2;
	
	fext=g*(p*fc(fiij,fi_1j,dcsi)+q*fu(fijj,fij_1,deta));
	
	fij=(g_22*fcc_ij(fiij,fi_1j,dcsi)-2*g_12*f_uc+g_11*fuu_ij(fijj,fij_1,deta)-fext)/(aij+bij);
	
	
	
	

end










function[d]=fuu(fij,fijj,fij_1,deta)
	
	d=(fijj-2*fij+fij_1)/(deta^2);
	
	
end

function[d]=fuc(fiijj,fi_1j_1,fi_1jj,fiij_1,dcsi,deta)
	
	d=(fiijj+fi_1j_1-fi_1jj-fiij_1)/(4*dcsi*deta);
	
end

function[g]=g11(xiij,xi_1j,yiij,yi_1j,dcsi)
	
	g=(fc(xiij,xi_1j,dcsi))^2 +(fc(yiij,yi_1j,dcsi))^2;
	
end
function[g]=g22(xijj,xij_1,yijj,yij_1,deta)
	
	g=(fu(xijj,xij_1,deta))^2+(fu(yijj,yij_1,deta))^2;
	
end
function[g]=g12(xiij,xi_1j,  xijj,xij_1,  yiij,yi_1j,  yijj,yij_1,  deta,dcsi)
	
	g=fc(xiij,xi_1j,dcsi)*fu(xijj,xij_1,deta)+fc(yiij,yi_1j,dcsi)*fu(yijj,yij_1,deta);
	
	
	
end

function[Y0]=inicia()
	global mcsi;
	global neta;
	global resu;
	renew();
	
	
	M=neta*mcsi;
	
	Y0=zeros(mcsi*neta*2,1);
	Y0=resu;
	
	for i=2:mcsi-1
		for j=2:neta-1
			
			
			csi=(i-1)/(mcsi-1);
			eta=(j-1)/(neta-1);
			Pt=somaBool(csi,eta);
			K=mij(i,j);
			
			
			Y0(K)=Pt(1);
			Y0(K+M)=Pt(2);
		end
	end
	
	
	
	
end

function[Pt]=somaBool(csi,eta)
	global A;
	global B;
	global C;
	global D;
	
	Pt=(1-csi)*rL(eta)+csi*rR(eta)+(1-eta)*rB(csi)+eta*rT(csi)-(1-csi)*(1-eta)*D-(1-csi)*eta*A-csi*(1-eta)*B-csi*eta*C;
	
end

function[rb]=rB(s)
	global qualRetaExt;
	global dadosExt;
	global s_0Ext;
	
	if(s>sum(dadosExt(1:qualRetaExt,5))+eps)
		s_0Ext=sum(dadosExt(1:qualRetaExt,5));
		qualRetaExt=qualRetaExt+1;
	end
	
	rb=dadosExt(qualRetaExt,1:2)+(s-s_0Ext)*(dadosExt(qualRetaExt,3:4)-dadosExt(qualRetaExt,1:2))/dadosExt(qualRetaExt,5);
	
end


function[rt]=rT(s)
	
	global qualReta;
	global dados;
	global s_0;
	
	if(s>sum(dados(1:qualReta,5))+eps)
		s_0=sum(dados(1:qualReta,5));
		qualReta=qualReta+1;
	end
	
	rt=dados(qualReta,1:2)+(s-s_0)*(dados(qualReta,3:4)-dados(qualReta,1:2))/dados(qualReta,5);
	
	
end


function[rl]=rL(s)
	global A;
	global B;
	
	rl=B+s*(A-B);
	
	
end

function[rr]=rR(s)
	global C;
	global D;
	
	rr=D+(C-D)*s;
	
end

function[coor_new]=translada(coor,dx,dy)
	
	coor_new=coor;
	d=ones(max(size(coor)),1);
	coor_new(:,1)=coor(:,1)+dx*d;
	coor_new(:,2)=coor(:,2)+dy*d;
	
	
end


function[dados]=organizaDados(coor)
	
	mLinhas=max(size(coor))-1;
	dados=zeros(mLinhas,5);
	
	dados(:,1:2)=coor(1:mLinhas,:);
	dados(:,3:4)=coor(2:mLinhas+1,:);
	comp=zeros(mLinhas,2);
	comp(:,1)=dados(:,1)-dados(:,3);
	comp(:,2)=dados(:,2)-dados(:,4);
	for i=1:mLinhas
		
		dados(i,5)=norm(comp(i,:));
		
	end
	compArco=sum(dados(:,5));
	dados(:,5)=dados(:,5)/compArco;
	
end

function[]=renew()
	
	global s_0;
	global s_0Ext;
	global qualReta;
	global qualRetaExt;
	
	s_0=0;
	s_0Ext=0;
	qualReta=1;
	qualRetaExt=1;

end


