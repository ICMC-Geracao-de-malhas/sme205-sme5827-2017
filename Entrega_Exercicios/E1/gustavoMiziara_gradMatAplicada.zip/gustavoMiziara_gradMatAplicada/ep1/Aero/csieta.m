function[]=csieta()
	
	x1=[0 0];
	y1=[0 1];
	hold on;
	plot(x1,y1,"k");
	x2=[0 1];
	y2=[0 0];
	plot(x2,y2,"b");
	
	hleg=legend(sprintf("\\xi"),sprintf("\\eta"));
	set(hleg,'fontsize',9);
	x=0:0.1:1;
	y=zeros(1,11);
	
	quiver(x,y,0,1,"maxheadsize",0.02,"autoscale","off","color","k","linewidth",2)
	
	quiver(y,x,1,0,"maxheadsize",0.02,"autoscale","off","color","b","linewidth",2)
	
	
	

end