function[]=DesenhaSwanEliptico()
	
	s=0:0.1:1;
	ns=max(size(s));
	
	boundT=zeros(ns,2);
	boundB=zeros(ns,2);
	boundL=zeros(ns,2);
	boundR=zeros(ns,2);
	
	for i=1:ns
		boundT(i,:)=rT(s(i));
		boundB(i,:)=rB(s(i));
		boundR(i,:)=rR(s(i));
		boundL(i,:)=rL(s(i));
		
		
	end
	hold on;
	plot(boundT(:,1),boundT(:,2),"linewidth",2);
	
	plot(boundB(:,1),boundB(:,2),"linewidth",2);
	plot(boundL(:,1),boundL(:,2),"linewidth",2);
	plot(boundR(:,1),boundR(:,2),"linewidth",2);
	
	
	
	
	
	
	
	
	XX=load("SwanXX.txt");
	YY=load("SwanYY.txt");
	
	plot(XX,YY);
	plot(XX',YY');
	title("Swan Eliptico");
	
	


end



function[rb]=rB(s)
	rb=[s,0];
	
end

function[rt]=rT(s)
	
	rt=[s,1-3*s+3*(s^2)];
	
	
end


function[rl]=rL(s)
	
	rl=[0,s];
	
	
end

function[rr]=rR(s)
	
	rr=[1+2*s-2*s^2,s];
	
end