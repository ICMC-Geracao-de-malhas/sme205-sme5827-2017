function[]=swanEliptico()
	
	global mcsi;
	global neta;
	global dcsi;
	global eta;
	global deta;
	global Y0;
	mcsi=10;
	neta=10;
	dcsi=1/(mcsi-1);
	deta=1/(neta-1);
	
	Y0=inicia();
	tic
	Y=fsolve(@ff,Y0);
	toc
	s=0:0.1:1;
	ns=max(size(s));
	
	boundT=zeros(ns,2);
	boundB=zeros(ns,2);
	boundL=zeros(ns,2);
	boundR=zeros(ns,2);
	
	for i=1:ns
		boundT(i,:)=rT(s(i));
		boundB(i,:)=rB(s(i));
		boundR(i,:)=rR(s(i));
		boundL(i,:)=rL(s(i));
		
		
	end
	[bT,bB,bL,bR]=verificaBound(Y);
	plot(boundT(:,1),boundT(:,2),"linewidth",2);
	hold on;
	plot(boundB(:,1),boundB(:,2),"linewidth",2);
	plot(boundL(:,1),boundL(:,2),"linewidth",2);
	plot(boundR(:,1),boundR(:,2),"linewidth",2);
	
	%plot(bT(:,1),bT(:,2),"linewidth",2,"color","k","marker","s");
	%hold on;
	%plot(bB(:,1),bB(:,2),"linewidth",2,"color","k","marker","s");
	%plot(bL(:,1),bL(:,2),"linewidth",2,"color","k","marker","s");
	%plot(bR(:,1),bR(:,2),"linewidth",2,"color","k","marker","s");
	
	
	

	
	XX=zeros(mcsi,neta);
	YY=zeros(mcsi,neta);
	M=mcsi*neta;
	for i=1:mcsi
		for j=1:neta
		K=mij(i,j);
		XX(i,j)=Y(K);
		YY(i,j)=Y(M+K);
		
		end
	end
	%XX
	plot(XX,YY);
	plot(XX',YY');
	
	%save SwanXX.txt XX
	%save SwanYY.txt YY
	
	
end

function[K]=mij(i,j)
	global mcsi;
	
	K=i+mcsi*(j-1);
	
	


end
function[F]=f(Y)
	global mcsi;
	global neta;
	global dcsi;
	global deta;
	mF=max(size(Y));
	F=zeros(mF,1);
	
	
	M=neta*mcsi;
	%bottom
	j=1;
	for i=1:mcsi
		K=mij(i,j);
		csi=(i-1)*dcsi;
		p=rB(csi);
		F(K)=Y(K)-p(1);
		F(K+M)=Y(K+M)-p(2);
		
	end
	
	%top
	j=neta;
	for i=1:mcsi
		K=mij(i,j);
		csi=(i-1)*dcsi;
		p=rT(csi);
		F(K)=Y(K)-p(1);
		F(K+M)=Y(K+M)-p(2);
	end
	
	%left
	i=1;
	
	for j=1:neta
		K=mij(i,j);
		eta=(j-1)*deta;
		p=rL(eta);
		F(K)=Y(K)-p(1);
		F(K+M)=Y(K+M)-p(2);
	end
	
	
	%right
	i=mcsi;
	
	
	for j=1:neta
		K=mij(i,j);
		eta=(j-1)*deta;
		p=rR(eta);
		F(K)=Y(K)-p(1);
		F(K+M)=Y(K+M)-p(2);
	end
	
	%now the inner points
	for i=2:mcsi-1
		for j=2:neta-1
			
			ij=mij(i,j);
			
			iij=mij(i+1,j);
			i_1j=mij(i-1,j);
			
			ijj=mij(i,j+1);
			ij_1=mij(i,j-1);
			
			iijj=mij(i+1,j+1);
			i_1j_1=mij(i-1,j-1);
			i_1jj=mij(i-1,j+1);
			iij_1=mij(i+1,j-1);
			
			
			
			
			
			
			g_11=g11(Y(iij),Y(i_1j),Y(M+iij),Y(M+i_1j),dcsi);
			
			g_22=g22(Y(ijj),Y(ij_1),Y(M+ijj),Y(M+ij_1),deta);
			
			g_12=g12(Y(iij),Y(i_1j),  Y(ijj),Y(ij_1),  Y(M+iij),Y(M+i_1j),  Y(M+ijj),Y(M+ij_1),  deta,dcsi);
			
			
			xcc=fcc(Y(ij),Y(iij),Y(i_1j),dcsi);
			xuu=fuu(Y(ij),Y(ijj),Y(ij_1),deta);
			xuc=fuc(Y(iijj),Y(i_1j_1),Y(i_1jj),Y(iij_1),dcsi,deta);
			
			
			ycc=fcc(Y(M+ij),Y(M+iij),Y(M+i_1j),dcsi);
			yuu=fuu(Y(M+ij),Y(M+ijj),Y(M+ij_1),deta);
			yuc=fuc(Y(M+iijj),Y(M+i_1j_1),Y(M+i_1jj),Y(M+iij_1),dcsi,deta);
			
			F(ij)=g_22*xcc-2*g_12*xuc+g_11*xuu;
			F(M+ij)=g_22*ycc-2*g_12*yuc+g_11*yuu;
			
			
			
		end
	
	end
	
	
	
	
	


end


function[F]=ff(Y)
	global mcsi;
	global neta;
	global dcsi;
	global deta;
	global Y0;
	mF=max(size(Y));
	F=zeros(mF,1);
	M=mcsi*neta;
	F=Y-Y0;
	
	%now the inner points
	for i=2:mcsi-1
		for j=2:neta-1
			
			ij=mij(i,j);
			
			iij=mij(i+1,j);
			i_1j=mij(i-1,j);
			
			ijj=mij(i,j+1);
			ij_1=mij(i,j-1);
			
			iijj=mij(i+1,j+1);
			i_1j_1=mij(i-1,j-1);
			i_1jj=mij(i-1,j+1);
			iij_1=mij(i+1,j-1);
			
			
			
			
			
			
			g_11=g11(Y(iij),Y(i_1j),Y(M+iij),Y(M+i_1j),dcsi);
			
			g_22=g22(Y(ijj),Y(ij_1),Y(M+ijj),Y(M+ij_1),deta);
			
			g_12=g12(Y(iij),Y(i_1j),  Y(ijj),Y(ij_1),  Y(M+iij),Y(M+i_1j),  Y(M+ijj),Y(M+ij_1),  deta,dcsi);
			
			
			xcc=fcc(Y(ij),Y(iij),Y(i_1j),dcsi);
			xuu=fuu(Y(ij),Y(ijj),Y(ij_1),deta);
			xuc=fuc(Y(iijj),Y(i_1j_1),Y(i_1jj),Y(iij_1),dcsi,deta);
			
			
			ycc=fcc(Y(M+ij),Y(M+iij),Y(M+i_1j),dcsi);
			yuu=fuu(Y(M+ij),Y(M+ijj),Y(M+ij_1),deta);
			yuc=fuc(Y(M+iijj),Y(M+i_1j_1),Y(M+i_1jj),Y(M+iij_1),dcsi,deta);
			
			F(ij)=g_22*xcc-2*g_12*xuc+g_11*xuu;
			F(M+ij)=g_22*ycc-2*g_12*yuc+g_11*yuu;
			
			
			
		end
	
	end
	
	
	
	
	


end










function[bT,bB,bL,bR]=verificaBound(Y)
	
	global mcsi;
	global neta;
	global dcsi;
	global deta;
	bT=zeros(mcsi,2);
	bB=zeros(mcsi,2);
	
	bL=zeros(neta,2);
	bR=zeros(neta,2);
	
	M=neta*mcsi;
	%bottom
	j=1;
	
	for i=1:mcsi
		K=mij(i,j);
		bB(i,:)=[Y(K),Y(K+M)];
		
		
	end
	
	%top
	j=neta;
	for i=1:mcsi
		K=mij(i,j);
		bT(i,:)=[Y(K),Y(K+M)];
	end
	
	%left
	i=1;
	
	for j=1:neta
		K=mij(i,j);
		bL(j,:)=[Y(K),Y(K+M)];
	end
	
	
	%right
	i=mcsi;
	
	for j=1:neta
		K=mij(i,j);
		bR(j,:)=[Y(K),Y(K+M)];
	end
	

	
	
	
	
end


function[d]=fc(fiij,fi_1j,dcsi)
	
	d=(fiij-fi_1j)/(2*dcsi);
	
end

function[d]=fu(fijj,fij_1,deta)
	
	d=(fijj-fij_1)/(2*deta);
	
end


function[d]=fcc(fij,fiij,fi_1j,dcsi)
	
	d=(fiij-2*fij+fi_1j)/(dcsi^2);
	
	
end

function[d]=fuu(fij,fijj,fij_1,deta)
	
	d=(fijj-2*fij+fij_1)/(deta^2);
	
	
end

function[d]=fuc(fiijj,fi_1j_1,fi_1jj,fiij_1,dcsi,deta)
	
	d=(fiijj+fi_1j_1-fi_1jj-fiij_1)/(4*dcsi*deta);
	
end

function[g]=g11(xiij,xi_1j,yiij,yi_1j,dcsi)
	
	g=(fc(xiij,xi_1j,dcsi))^2 +(fc(yiij,yi_1j,dcsi))^2;
	
end
function[g]=g22(xijj,xij_1,yijj,yij_1,deta)
	
	g=(fu(xijj,xij_1,deta))^2+(fu(yijj,yij_1,deta))^2;
	
end
function[g]=g12(xiij,xi_1j,  xijj,xij_1,  yiij,yi_1j,  yijj,yij_1,  deta,dcsi)
	
	g=fc(xiij,xi_1j,dcsi)*fu(xijj,xij_1,deta)+fc(yiij,yi_1j,dcsi)*fu(yijj,yij_1,deta);
	
	
	
end

function[Y0]=inicia()
	global mcsi;
	global neta;
	M=neta*mcsi;
	Y0=zeros(mcsi*neta*2,1);
	
	for i=1:mcsi
		for j=1:neta
			
			csi=(i-1)/(mcsi-1);
			eta=(j-1)/(neta-1);
			Pt=somaBool(csi,eta);
			K=mij(i,j);
			Y0(K)=Pt(1);
			Y0(K+M)=Pt(2);
		end
	end
	
	
	
	
end

function[Pt]=somaBool(csi,eta)
	
	Pt=(1-csi)*rL(eta)+csi*rR(eta)+(1-eta)*rB(csi)+eta*rT(csi)-(1-csi)*(1-eta)*rB(0)-(1-csi)*eta*rT(0)-csi*(1-eta)*rB(1)-csi*eta*rT(1);
	
end

function[rb]=rB(s)
	rb=[s,0];
	
end

function[rt]=rT(s)
	
	rt=[s,1-3*s+3*(s^2)];
	
	
end


function[rl]=rL(s)
	
	rl=[0,s];
	
	
end

function[rr]=rR(s)
	
	rr=[1+2*s-2*s^2,s];
	
end