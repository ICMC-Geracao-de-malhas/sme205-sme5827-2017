function[]=swanTransfinita()
	
	s=0:0.1:1;
	ns=max(size(s));
	
	boundT=zeros(ns,2);
	boundB=zeros(ns,2);
	boundL=zeros(ns,2);
	boundR=zeros(ns,2);
	
	for i=1:ns
		boundT(i,:)=rT(s(i));
		boundB(i,:)=rB(s(i));
		boundR(i,:)=rR(s(i));
		boundL(i,:)=rL(s(i));
		
		
	end
	plot(boundT(:,1),boundT(:,2),"linewidth",2);
	hold on;
	plot(boundB(:,1),boundB(:,2),"linewidth",2);
	plot(boundL(:,1),boundL(:,2),"linewidth",2);
	plot(boundR(:,1),boundR(:,2),"linewidth",2);
	
	
	
	
	
	mcsi=10;
	neta=10;
	
	X=zeros(mcsi,neta);
	Y=zeros(mcsi,neta);
	for i=1:mcsi
		for j=1:neta
			
			csi=(i-1)/(mcsi-1);
			eta=(j-1)/(neta-1);
			Pt=somaBool(csi,eta);
			X(i,j)=Pt(1);
			Y(i,j)=Pt(2);
		end
	end
	
	plot(X,Y);
	plot(X',Y');
	
	save SwanTransXX.txt X
	save SwanTransYY.txt Y
	
	
end



function[Pt]=somaBool(csi,eta)
	
	Pt=(1-csi)*rL(eta)+csi*rR(eta)+(1-eta)*rB(csi)+eta*rT(csi)-(1-csi)*(1-eta)*rB(0)-(1-csi)*eta*rT(0)-csi*(1-eta)*rB(1)-csi*eta*rT(1);
	
	
	
	
end

function[rb]=rB(s)
	rb=[s,0];
	
end

function[rt]=rT(s)
	
	rt=[s,1-3*s+3*(s^2)];
	
	
end


function[rl]=rL(s)
	
	rl=[0,s];
	
	
end

function[rr]=rR(s)
	
	rr=[1+2*s-2*s^2,s];
	
end