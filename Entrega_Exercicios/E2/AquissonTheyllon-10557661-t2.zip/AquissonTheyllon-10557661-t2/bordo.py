import sys
import numpy as np

f = open('bordo.txt','wt')

## Refinamento do eixo inferior (RB).

t = np.linspace(0,1,63) # 63 - numero total de pontos discretizados 

t1 = np.linspace(0.00126000,1,7)   		#BH
t2 = np.linspace(1.34375000,-0.85714286,17)     #HG   
t3 = np.linspace(1,-0.85714286,15)	   	#GF
t4 = np.linspace(-1,1.34375000,17)	   	#FE
t5 = np.linspace(-1,-0.00126000,7) 		#ED


n = t.shape[0]

#eixo inferior (rb)
f.write(str(n)) 
f.write('\n')
for i in range(7):
    f.write("{:.8f}".format(1.5))
    f.write(' ')
    f.write("{:.8f}".format(t1[i]))
    f.write('\n')

for i in range(17):
    f.write("{:.8f}".format(t2[i]))
    f.write(' ')
    f.write("{:.8f}".format(1.0))
    f.write('\n')

for i in range(15):
    f.write("{:.8f}".format(-1.0))
    f.write(' ')
    f.write("{:.8f}".format(t3[i]))
    f.write('\n')

for i in range(17):
    f.write("{:.8f}".format(t4[i]))
    f.write(' ')
    f.write("{:.8f}".format(-1.0))
    f.write('\n')

for i in range(7):
    f.write("{:.8f}".format(1.5))
    f.write(' ')
    f.write("{:.8f}".format(t5[i]))
    f.write('\n')

##########################################

## eixos laterais
s = np.linspace(1.5,1,10) 

n = s.shape[0]

#eixo esquerdo (rl) 		#AB
f.write(str(n))
f.write('\n')
for i in range(n):
    f.write("{:.8f}".format(s[i]))
    f.write(' ')
    f.write("{:.8f}".format(0.00126))
    f.write('\n')

##########################################

#eixo direito (rr)	        #CD
f.write(str(n))
f.write('\n')
for i in range(n):
    f.write("{:.8f}".format(s[i]))
    f.write(' ')
    f.write("{:.8f}".format(-0.00126))
    f.write('\n')

f.close()

