# -*- coding: utf-8 -*-
import os
import numpy, sys
import matplotlib.pyplot as plt
import math
from util import Util

#                       .-'`'-.
#              ,-'`'.   '._     \     ______
#            /    .'  ___ `-._  |    \ .-'`
#           |   .' ,-' __ `'/.`.'  ___\\
#   ______  \ .' \',-' 12 '-.  '.  `-._ \
#   '`-. /   ` / / 11    7 1 `.  `.    '.\
#      //___  . '10     /    2 \  ;
#     / _.-'  | |      O      3|  |  ______
#    /.'      | |9      \      '  '  '`-. /
#      ______ '  \ 8     \   4/  /      //___
#      \ .-'`  '. `'.7  6  5.'  '      / _.-'
#    ___\\       `. _ `'''` _.'\\-.   /.'
#    `-._ \       .//`''--''   (   )
#        '.\     (   )          '-`
#                 `-'
# trim, trim trim: Oh well this was difficult, but i think it works!


CONF_FILE = "AIRFOIL3.conf"
# VTK_OUTPUT = "../VtkOutput/airfoil_eliptic.vtk"
VTK_OUTPUT = "airfoil_eliptic.vtk"

def abs(x):
    if x < 0:
        return -x
    return x

def computePQ(X, Y, i, j, a_, b_, c_, d_, lines_xi, lines_eta, points):
    # try: # too many vectors, prevent index issues, know what fuck it let it explode
    amount = len(points)
    eps = 1e-7
    size = len(lines_xi)
    #calculate P and Q
    P = 0.0
    Q = 0.0
    # line attraction part
    for idx in range(0, size):
        diff_p = X[i, j] - lines_xi[idx]
        diff_q = Y[i, j] - lines_eta[idx]
        P += (a_[idx] * diff_p / abs(diff_p + eps)) * (math.pow(math.e, -c_[idx]*abs(diff_p)))
        Q += (a_[idx] * diff_q / abs(diff_q + eps)) * (math.pow(math.e, -c_[idx]*abs(diff_q)))

    # point attraction part
    size = len(points)
    for idx in range(0, size):
        pt = points[idx]
        diff_p = X[i, j] - pt[0]
        diff_q = Y[i, j] - pt[1]
        exp_factor = math.pow(math.e, -d_[idx]*math.sqrt((diff_p)**2 + (diff_q)**2))
        P += (b_[idx] * diff_p / abs(diff_p + eps)) * exp_factor
        Q += (b_[idx] * diff_q / abs(diff_q + eps)) * exp_factor

    return [P, Q]
    # except Exception as ex:
    #     print str(ex)
    #     return [0.0, 0.0]

# this so does not look right
def writeOutputDomain(filename):
    global size, airfoilX, airfoilY
    print "Writing output domain as 8 point bounding box"
    print "The points are in lexigrophaic order"
    try:
        with open(filename, "w") as fd:
            point = [airfoilX[0], airfoilY[0]]
            fd.write(str(point[0]) + " " + str(point[1]) + "\n") # point A

            point = [airfoilX[0]+size, airfoilY[0]]
            fd.write(str(point[0]) + " " + str(point[1]) + "\n") # point B

            point = [size+airfoilX[0], airfoilY[0]+1.0]
            fd.write(str(point[0]) + " " + str(point[1]) + "\n") # point H

            point = [size+airfoilX[0] - 2.0, airfoilY[0] + 1.0]
            fd.write(str(point[0]) + " " + str(point[1]) + "\n") # point G

            point = [size+airfoilX[0]-2.0, airfoilY[0]-1.0]
            fd.write(str(point[0]) + " " + str(point[1]) + "\n") # point F

            point = [size+airfoilX[0], airfoilY[0]-1.0]
            fd.write(str(point[0]) + " " + str(point[1]) + "\n") # point E

            point = [size+airfoilX[len(airfoilX)-1], airfoilY[len(airfoilY)-1]]
            fd.write(str(point[0]) + " " + str(point[1]) + "\n") # point D

            point = [airfoilX[len(airfoilX)-1], airfoilY[len(airfoilY)-1]]
            fd.write(str(point[0]) + " " + str(point[1]) + "\n") # point C

            fd.close()
            print "Finished writing domain to ", filename
    except:
        print "Unnable to write output file: ", filename

#define parametric curves
def r1(s): #left
    global airfoilX, airfoilY, size
    return [airfoilX[0]+(1.0-s)*size, airfoilY[0]]

def r2(s): #bottom
    global size, airfoilX, airfoilY
    t = Util.mapTo(s, 0.0, 1.0, 0.0, 8.0)
    if t < 1:
        point = [size+airfoilX[0], airfoilY[0]+t]
        return point
    elif t < 3:
        point = [size+airfoilX[0] - (t-1.0), airfoilY[0] + 1.0]
        return point
    elif t < 5:
        point = [size+airfoilX[0]-2.0, airfoilY[0]+1.0-(t-3.0)]
        return point
    elif t < 7:
        point = [size+airfoilX[0]-2.0+(t-5.0), airfoilY[0]-1.0]
        return point
    else:
        point = [size+airfoilX[len(airfoilX)-1],\
                 airfoilY[len(airfoilY)-1]-1.0+(t-7.0)]
        return point

def r3(s): #right
    global airfoilX, airfoilY, size
    point = [(1.0-s)*size+airfoilX[0],\
            airfoilY[len(airfoilY)-1]]
    return point

def r4(s): #top
    global airfoilX, airfoilY
    i = int(s*(len(airfoilX)-1.0))
    return [airfoilX[i], airfoilY[i]]

def plotPoints(points):
    for i in range(0, len(points)):
        pt = points[i]
        plt.plot(pt[0], pt[1], 'ro', markersize=1.5)

# insert the current matrixes X and Y
# to the plot image
def plotGrid(sizex, sizey, X, Y):
    for i in range(0, sizex):
        plt.plot(X[i,:], Y[i, :], 'gray')

    for i in range(0, sizey):
        plt.plot(X[:, i], Y[:, i], 'gray')

args = sys.argv
if len(args) != 2:
    print "Invalid call, please use: python generate_eliptic.py <output-file>"
    quit()

filename = args[1]
size = 0.25
data = Util.parseConfFile(CONF_FILE)

if data is None:
    print "Unnable to parse ",CONF_FILE, ", check your file"
    quit()

airfoilX, airfoilY = data

gl_res = 25
resolutionx = gl_res
resolutiony = gl_res
gridx = numpy.linspace(0.0, 1.0, resolutionx)
gridy = numpy.linspace(0.0, 1.0, resolutiony)

X = numpy.zeros((resolutionx, resolutiony))
Y = numpy.zeros((resolutionx, resolutiony))

r20 = r2(0)
r40 = r4(0)
r21 = r2(1)
r41 = r4(1)

for i in range(0, len(gridx)):
    for j in range(0, len(gridy)):
        x_ = gridx[i]
        y_ = gridy[j]
        a = 1.0 - x_
        b = 1.0 - y_
        r1y = r1(y_)
        r3y = r3(y_)
        r2x = r2(x_)
        r4x = r4(x_)
        x = a*r1y[0] + x_*r3y[0] + b*r2x[0] + y_*r4x[0] - \
            a*b*r20[0] - a*y_*r40[0] - x_*b*r21[0] - x_*y_*r41[0]
        y = a*r1y[1] + x_*r3y[1] + b*r2x[1] + y_*r4x[1] - \
            a*b*r20[1] - a*y_*r40[1] - x_*b*r21[1] - x_*y_*r41[1]
        X[i, j] = x
        Y[i, j] = y

err = 9999999
tol = 1e-4
it = 0
max_it = 400 # if it doesn't converge in max_it break it so we don't fall sleep
# AIRFOIL3.conf full points = [xi, eta]
# points = [[0.2, 0.2], [0.2, -0.2], [0.5, 0.2], [0.4, -0.2], [0.8, 0.1], [0.7, -0.1], [1.0, 0.0], [0.0, 0.0]]

# AIRFOIL<3>.conf edge points = [xi, eta]
points = [[1.0, 0.0], [0.0, 0.0]]

# AIRFOIL.conf full points = [xi, eta]
# points = [[0.2, 0.17], [0.2, 0.02], [0.5, 0.22], [0.4, 0.05], [0.8, 0.12], [0.7, 0.05], [1.0, 0.0], [0.0, 0.0]]
# points = [] # points = [xi, eta]

# b_ = [-50.0, 20.0, -20.0, 20.0, -60.0, 80.0, -20.0, -20.0] # AIRFOIL3.conf full point attractions
b_ = [-80.0, -80.0] # AIRFOIL3.conf edge point attractions

# b_ = [-50.0, 60.0, -20.0, 60.0, -60.0, 80.0, -20.0, -20.0] # AIRFOIL.conf full point attractions
# b_ = [60.0, 60.0] # AIRFOIL.conf edge point attractions

d_ = [8.0] * len(points) # AIRFOIL.conf point fallof
# b_ = [0.0] * len(points) # point attractions
# d_ = [6.0] * len(points) # AIRFOIL.conf point fallof

a_ = [0.0] # line attractions
c_ = [1.0]  # line fallolf
lines_xi = [0.0] # lines x = xi
lines_eta = [0.8] # lines y = eta

print "Generating grid"
while err > tol and it < max_it:
    it = it + 1
    err = 0
    for j in range(1, resolutiony-1):
        for i in range(1, resolutionx-1):
            dxdxi = (X[i+1, j] - X[i-1, j]) # dx/dxi
            dydxi= (Y[i+1, j] - Y[i-1, j]) # dy/dxi
            dxdeta = (X[i, j+1] - X[i, j-1]) # dx/deta
            dydeta = (Y[i, j+1] - Y[i, j-1]) # dy/deta

            kx0 = X[i+1, j] + X[i-1, j] # term that follows g22 on winslow -> x
            kx1 = X[i, j+1] + X[i, j-1] # term that follows g11 on winslow -> x
            kx2 = X[i+1, j+1] - X[i-1, j+1] - X[i+1, j-1] + X[i-1, j-1] # term that follows g12 on winslow -> x

            ky0 = Y[i+1, j] + Y[i-1, j] # term that follows g22 on winslow -> y
            ky1 = Y[i, j+1] + Y[i, j-1] # term that follows g11 on winslow -> y
            ky2 = Y[i+1, j+1] - Y[i-1, j+1] - Y[i+1, j-1] + Y[i-1, j-1] # term that follows g12 on winslow -> y

            g11 = dxdxi**2 + dydxi**2 # metric tensor g11
            g22 = dxdeta**2 + dydeta**2 # metric tensor g22
            g12 = dxdxi*dxdeta + dydxi*dydeta # metric tensor g12 (known as g21)

            k = 1/(2*(g22 + g11)) # multiplying term of winslow equation

            g = g11*g22 - g12*g12 # det(gij)

            # computes P and Q from TTM method
            P, Q = computePQ(X, Y, i, j, a_, b_, c_, d_, lines_xi, lines_eta, points)

            xdif = g*(P*dxdxi + Q*dxdeta) # x factor for the poisson equation
            ydif = g*(P*dydxi + Q*dydeta) # y factor for the poisson equation

            xtemp = k*(g22*kx0 + g11*kx1 - 0.5*g12*kx2 - xdif) # winslow with poisson x
            ytemp = k*(g22*ky0 + g11*ky1 - 0.5*g12*ky2 - ydif) # winslow with poisson y

            err = err + (X[i, j] - xtemp)**2 + (Y[i, j] - ytemp)**2 # error for gauss-seidel
            X[i, j] = xtemp # update x
            Y[i, j] = ytemp # update y

    err = math.sqrt(err)

Util.dataToVTK(X, Y, VTK_OUTPUT)
writeOutputDomain(filename)
plotGrid(len(gridx), len(gridy), X, Y)
plotPoints(points)
plt.show()
