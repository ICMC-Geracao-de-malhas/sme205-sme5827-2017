function [Gridx, Gridy]=bilinear(n)

fclose('all');
A=[0.0 0.0];
B=[0.0 1.0];   
C=[1.0 0.0]; 
D=[1.0 1.0];
% 
Gridx = zeros(n, n);
Gridy = zeros(n, n);

% Bilinear
dx = 1.0/(n-1);
dy = 1.0/(n-1);

 for i= 1 : n
     for j= 1 : n
         Gridx(i,j)=(1-(i-1)*dx)*(1-(j-1)*dy)*A(1) + (1-(i-1)*dx)*((j-1)*dy)*B(1) + ((i-1)*dx)*(1-(j-1)*dy)*C(1) + ((i-1)*dx)*((j-1)*dy)*D(1);
         Gridy(i,j)=(1-(i-1)*dx)*(1-(j-1)*dy)*A(2) + (1-(i-1)*dx)*((j-1)*dy)*B(2) + ((i-1)*dx)*(1-(j-1)*dy)*C(2) + ((i-1)*dx)*((j-1)*dy)*D(2);
     end
 end
 %Gridx
plot(Gridx(1,:),Gridy(n,:));
 hold on
 for i=2:n
     plot(Gridx(i,:),Gridy(n+1-i,:), 'm')
 end
 for i=1:n
     plot(Gridx(:,i),Gridy(:,n+1-i), 'b')
 end
hold off