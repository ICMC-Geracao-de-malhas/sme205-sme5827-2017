%Usa a funcao bilinear.m

% Bilinear
%[Gridx, Gridy]= bilinquad(20);
[Gridx, Gridy]= bilinear(30);
[numtop, numrig] = size(Gridx);
deta = 1.0/(numtop-1);
dxi = 1.0/(numrig-1);
% 
N = 100;
% Winslow
xi_rf = 0.01;
eta_rf = 0.501;
a_rf=30;
b_rf=10;
c_rf=10;
d_rf=10;

for k = 1:N
    for i= 2 : numtop-1
       for j= 2 : numrig-1

            dxdxi = (Gridx(i + 1,j) - Gridx(i - 1,j)) / (2 * dxi);
            dydxi = (Gridy(i + 1,j) - Gridy(i - 1,j)) / (2 * dxi);

            dxdeta = (Gridx(i,j + 1) - Gridx(i,j - 1)) / (2 * deta);
            dydeta = (Gridy(i,j + 1) - Gridy(i,j - 1)) / (2 * deta);
% 
            g11 = dxdxi^2 + dydxi^2;
            g22 = dxdeta^2 + dydeta^2;
            g12 = dxdxi*dxdeta + dydxi*dydeta;

            a = 4.0 * (deta^2)*g22;
            b = 4.0 * dxi*deta*g12;
            c = 4.0 * (dxi^2)*g11;
g = g11*g22-g12^2;
%xixi_rf = i*dxi-xi_rf
dif_xi = (i-1)*dxi-xi_rf;
%etaeta_rf = j*deta-eta_rf
dif_ni = (j-1)*deta-eta_rf;
if dif_xi==0
    fprintf('Não se pode pois x_%d =xi',i);
    break
elseif dif_xi>0
    cal_xi = 1;
else
    cal_xi = -1;
end
   
if dif_ni==0
    fprintf('Não se pode pois n_%d =ni',j);
    break
elseif dif_ni>0
    cal_ni = 1;
else
    cal_ni = -1;
end

P = a_rf * cal_xi * exp(-c_rf*abs(dif_xi)) + b_rf* cal_xi * exp(-d_rf*sqrt(dif_xi^2 + dif_ni^2));
Q = a_rf * cal_ni * exp(-c_rf*abs(dif_ni)) + b_rf* cal_ni * exp(-d_rf*sqrt(dif_xi^2 + dif_ni^2));


Gx = 4*(dxi^2)*(deta^2)*g*(P*dxdxi+Q*dxdeta);
% ---------   Gy = g*(P*dydxi+Q*dydeta)
Gy = 4*(dxi^2)*(deta^2)*g*(P*dydxi+Q*dydeta);
 

            Gridx(i,j) = (1.0 / (2*(a + c))) * (-Gx + a*(Gridx(i+1,j) + Gridx(i-1,j)) + c*(Gridx(i,j+1) + Gridx(i,j-1)) - 0.5 *b*(Gridx(i+1,j+1) + Gridx(i-1,j-1) - Gridx(i-1,j+1) - Gridx(i+1,j-1)));
            Gridy(i,j) = (1.0 / (2*(a + c))) * (-Gy +a*(Gridy(i+1,j) + Gridy(i-1,j)) + c*(Gridy(i,j+1) + Gridy(i,j-1)) - 0.5 *b*(Gridy(i+1,j+1) + Gridy(i-1,j-1) - Gridy(i-1,j+1) - Gridy(i+1,j-1)));
            
       end
    end
end
%[x_rf,y_rf]= mud_coord(xi_rf, eta_rf);

plot(Gridx(1,:),Gridy(1,:));
 hold on
 for i=2:numtop
     plot(Gridx(i,:),Gridy(i,:), 'm')
 end
 for i=1:numrig
     plot(Gridx(:,i),Gridy(:,i), 'b')
 end
%plot(x_rf,y_rf,'*r')
plot(xi_rf,eta_rf,'*r')
hold off