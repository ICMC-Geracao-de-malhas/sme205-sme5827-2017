% Usa o arquivo pontosrtl.txt
% Gera refinamento.vtk

doc =fopen('pontosrtl.txt');

%Top
numtop = fscanf(doc,'%d',[1]);
Btop = zeros(2,numtop);
Btop = fscanf(doc,'%f',[2, numtop]); %pontos do ladp TOp --- Btop(1,:)= xi & Btop(2,:)= yj

%Bottom
numbot = fscanf(doc,'%d',[1]);
Bbot= zeros(2,numbot);
Bbot = fscanf(doc,'%f',[2, numbot]); %pontos do ladp BOTTOM --- Bbot(1,:)= xi & Bbot(2,:)= yj

%Left
numlef = fscanf(doc,'%d',[1]);
Blef= zeros(2,numlef);
Blef = fscanf(doc,'%f',[2, numlef]); %pontos do ladp LEFT --- Blef(1,:)= xi & Blef(2,:)= yj

%Right
numrig = fscanf(doc,'%d',[1]);
Brig= zeros(2,numrig);
Brig = fscanf(doc,'%f',[2, numrig]); %pontos do lado RIGHT --- Brig(1,:)= xi & Brig(2,:)= yj

fclose('all');
% 
Gridx = zeros(numtop, numrig);
Gridy = zeros(numtop, numrig);

Gridx(:,1)=Bbot(1,:)';  % primeira componente da funcao Bbut
Gridx(:,numrig)=Btop(1,:);  % primeira componente da funcao Btop
Gridx(1,:)=Blef(1,:);  % primeira componente da funcao Bleft
Gridx(numtop,:)=Brig(1,:); % primeira componente da funcao Bright

Gridy(:,1)=Bbot(2,:);  % segunda componente da funcao Bbut
Gridy(:,numrig)=Btop(2,:);  % segunda componente da funcao Btop
Gridy(1,:)=Blef(2,:);  % segunda componente da funcao Bleft
Gridy(numtop,:)=Brig(2,:); % segunda componente da funcao Bright

% Transfinita
dx = 1.0/(numtop-1);
dy = 1.0/(numrig-1);

 for i= 2 : numtop-1
     for j= 2 : numrig-1
          idx = (i-1)*dx;
          jdy = (j-1)*dy;
         
         Gridx(i,j) = (1.0-idx)*Blef(1,j) + idx*Brig(1,j)+ (1.0 - jdy)*Bbot(1,i)+ jdy*Btop(1,i)-(1.0-idx)*(1.0-jdy)*Brig(1,1)- (1.0 - idx)*jdy*Btop(1,1)- idx*(1.0-jdy)*Bbot(1,numtop)- idx*jdy*Brig(1,numrig);
         Gridy(i,j) = (1.0-idx)*Blef(2,j) + idx*Brig(2,j)+ (1.0 - jdy)*Bbot(2,i)+ jdy*Btop(2,i)-(1.0-idx)*(1.0-jdy)*Brig(2,1)- (1.0 - idx)*jdy*Btop(2,1)- idx*(1.0-jdy)*Bbot(2,numtop)- idx*jdy*Brig(2,numrig);
     end
 end
 
 % Winslow

dxi = 1.0/(numtop-1);
deta = 1.0/(numrig-1);

N = 800;

%xi_rf = [0.0001; 0.515];
%eta_rf = [0.90102; 0.995 ];
% a_rf=[100; 20];
% b_rf=[20; 10];
% c_rf=[20; 10];
% d_rf=[20; 10];

xi_rf = [0.515];
eta_rf = [0.995 ];
a_rf=[65];
b_rf=[50];
c_rf=[35];
d_rf=[35];

p=length(a_rf);

% -------------grid2vtk(gridx,gridy,'test.vtk')


for k = 1:N
    for i= 2 : numtop-1
       for j= 2 : numrig-1

            dxdxi = (Gridx(i + 1,j) - Gridx(i - 1,j)) / (2 * dxi);
            dydxi = (Gridy(i + 1,j) - Gridy(i - 1,j)) / (2 * dxi);

            dxdeta = (Gridx(i,j + 1) - Gridx(i,j - 1)) / (2 * deta);
            dydeta = (Gridy(i,j + 1) - Gridy(i,j - 1)) / (2 * deta);
% 
            g11 = dxdxi^2 + dydxi^2;
            g22 = dxdeta^2 + dydeta^2;
            g12 = dxdxi*dxdeta + dydxi*dydeta;

            a = 4.0 * (deta^2)*g22;
            b = 4.0 * dxi*deta*g12;
            c = 4.0 * (dxi^2)*g11;
g = g11*g22-g12^2;

w=0;
f=0;
wq=0;
fq=0;
for r=1:p 
    dif_xi = (i-1)*dxi-xi_rf(r);
    dif_ni = (j-1)*deta-eta_rf(r);
    if dif_xi==0
        fprintf('Não se pode pois x_%d =xi',i);
        break
    elseif dif_xi>0
        cal_xi = 1;
    else
        cal_xi = -1;
    end
   
if dif_ni==0
    fprintf('Não se pode pois n_%d =ni',j);
    break
elseif dif_ni>0
    cal_ni = 1;
else
    cal_ni = -1;
end

    w = w + a_rf(r)*(cal_xi)*exp(-c_rf(r)*abs(dif_xi));
    f = f + b_rf(r)*(cal_xi)*exp(-d_rf(r)*sqrt((dif_xi)^2 +dif_ni^2) );
    wq = wq + a_rf(r)*(cal_ni)*exp(-c_rf(r)*abs(dif_ni));
    fq = fq + b_rf(r)*(cal_ni)*exp(-d_rf(r)*sqrt((dif_xi)^2 +dif_ni^2) );
end

P = w +f;
Q = wq +fq;

Gx = 4*(dxi^2)*(deta^2)*g*(P*dxdxi+Q*dxdeta);
Gy = 4*(dxi^2)*(deta^2)*g*(P*dydxi+Q*dydeta);

            Gridx(i,j) = (1.0 / (2*(a + c))) * (-Gx + a*(Gridx(i+1,j) + Gridx(i-1,j)) + c*(Gridx(i,j+1) + Gridx(i,j-1)) - 0.5 *b*(Gridx(i+1,j+1) + Gridx(i-1,j-1) - Gridx(i-1,j+1) - Gridx(i+1,j-1)));
            Gridy(i,j) = (1.0 / (2*(a + c))) * (-Gy +a*(Gridy(i+1,j) + Gridy(i-1,j)) + c*(Gridy(i,j+1) + Gridy(i,j-1)) - 0.5 *b*(Gridy(i+1,j+1) + Gridy(i-1,j-1) - Gridy(i-1,j+1) - Gridy(i+1,j-1)));

       end
    end
end
% 
fid = fopen('refinamento.vtk', 'wt');
fprintf(fid,'# vtk DataFile Version 3.0\n');
fprintf(fid,'Comment goes here\n');
fprintf(fid, 'ASCII\n');
fprintf(fid,'DATASET STRUCTURED_GRID\n');
fprintf(fid, 'DIMENSIONS %d %d %d\n', numtop, numrig, 1);
% 
fprintf(fid, 'POINTS %d float\n', numrig*numtop);
for j = 1:numrig
    for i = 1:numtop
        fprintf(fid, '%5.5f %5.5f %d\n', Gridx(i,j),Gridy(i,j),0);
    end
end
% 
Cells = (numtop-1)*(numrig-1);
% 
fprintf(fid, 'POINT_DATA %d \n', numrig*numtop);
% % 
%Gridx
xref=eta_rf(1)*Blef(1,numrig) + (1-eta_rf(1))*Blef(1,1);
yref=Blef(2,numrig);
plot(Gridx(1,:),Gridy(1,:));
 hold on
 for i=2:numtop
     plot(Gridx(i,:),Gridy(i,:), 'k')
 end
 for i=1:numrig
     plot(Gridx(:,i),Gridy(:,i), 'b')
 end
plot(Btop(1,:),Btop(2,:), 'g')
plot(Bbot(1,:),Bbot(2,:), 'g')
plot(Blef(1,:),Blef(2,:), 'g')
plot(Brig(1,:),Brig(2,:), 'g')
%plot(xref,yref,'*r')
hold off