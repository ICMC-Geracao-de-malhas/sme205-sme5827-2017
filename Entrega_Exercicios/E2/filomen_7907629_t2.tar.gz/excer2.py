#Student: Filomen Incahuanaco Quispe
#Description:2 Points of control for tune grid


import sys
import numpy as np
import matplotlib.pyplot as plt
from grid2vtk import grid2vtk



f = open(sys.argv[1],'rt')

nx = int(f.readline())
rt = np.zeros((nx,2))
for i in range(nx):
    l=f.readline()
    rt[i,0]=l.split(' ')[0]
    rt[i,1]=l.split(' ')[1]

n2 = int(f.readline())

if (n2 != nx):
    print("top and botton discretization should match")
    sys.exit(0)

rb = np.zeros((nx,2))
for i in range(nx):
    l=f.readline()
    rb[i,0]=l.split(' ')[0]
    rb[i,1]=l.split(' ')[1]

ny = int(f.readline())
rl = np.zeros((ny,2))
for i in range(ny):
    l=f.readline()
    rl[i,0]=l.split(' ')[0]
    rl[i,1]=l.split(' ')[1]

n2 = int(f.readline())

if (n2 != ny):
    print("left and right discretization should match")
    sys.exit(0)

rr = np.zeros((ny,2))
for i in range(ny):
    l=f.readline()
    rr[i,0]=l.split(' ')[0]
    rr[i,1]=l.split(' ')[1]

f.close()

gridx = np.zeros((ny,nx))
gridy = np.zeros((ny,nx))


gridx[ny-1,:]=rt[:,0]
gridy[ny-1,:]=rt[:,1]

gridx[0,:]=rb[:,0]
gridy[0,:]=rb[:,1]

gridx[:,0]=rl[:,0]
gridy[:,0]=rl[:,1]

gridx[:,nx-1]=rr[:,0]
gridy[:,nx-1]=rr[:,1]

dx = 1.0/nx
dy = 1.0/ny
for j in range(1,ny-1):
    for i in range(1,nx-1):
        idx = i*dx
        jdy = j*dy
        gridx[j,i] = (1.0-idx)*rl[j,0] + idx*rr[j,0] + (1.0 - jdy)*rb[i,0] + jdy*rt[i,0] - (1.0-idx)*(1.0-jdy)*rb[0,0] - (1.0 - idx)*jdy*rt[0,0] - idx*(1.0-jdy)*rb[nx-1,0] - idx*jdy*rt[nx-1,0]

        gridy[j,i] = (1.0-idx)*rl[j,1] + idx*rr[j,1] + (1.0 - jdy)*rb[i,1] + jdy*rt[i,1] - (1.0-idx)*(1.0-jdy)*rb[0,1] - (1.0 - idx)*jdy*rt[0,1] - idx*(1.0-jdy)*rb[nx-1,1] - idx*jdy*rt[nx-1,1]

dxi = 1.0/nx
deta = 1.0/ny
N = 100

#print "gridx ",gridx
#print "gridy ",gridy

xi_rf={}
eta_rf={}
a_rf={}
b_rf={}
c_rf={}
d_rf={}

#first point
xi_rf[0] = 0.5 # 
eta_rf[0] = 0.9 # 0.8

a_rf[0]=5  #concentracao 
b_rf[0]=30  #atracao
c_rf[0]=30  #velocidad
d_rf[0]=10  #alcance

#second point
xi_rf[1] = 0.005 #  0.80(w), 0.85, 0.89 out, 2 - 9 out
eta_rf[1]= 0.9 #  0.9 ... 0.21

a_rf[1]=2  #concentracao < 20
b_rf[1]=30  #atracao >=5 < 40
c_rf[1]=5 #velocidad >=5
d_rf[1]=10 #alcance >=10 <20

xixi_rf={}
etaeta_rf={}

plt.figure(figsize=(20,10))

for k in range(N):
    for j in range(1,ny-1):
        for i in range(1,nx-1):
            dxdxi = (gridx[j,i+1]-gridx[j,i-1])/(2.0*dxi)
            dydxi = (gridy[j,i+1]-gridy[j,i-1])/(2.0*dxi)

            dxdeta = (gridx[j+1,i]-gridx[j-1,i])/(2.0*deta)
            dydeta = (gridy[j+1,i]-gridy[j-1,i])/(2.0*deta) 
      
            g11 = dxdxi**2 + dydxi**2
            g22 = dxdeta**2 + dydeta**2
            g12 = dxdxi*dxdeta + dydxi*dydeta

            a = 4.0*(deta**2)*g22
            c = 4.0*(dxi**2)*g11
            b = 4.0*dxi*deta*g12


            ax=gridx[j,i+1]+gridx[j,i-1]
            cx=gridx[j+1,i]+gridx[j-1,i]
            bx=gridx[j+1,i+1]+gridx[j-1,i-1]-gridx[j+1,i-1]-gridx[j-1,i+1]

            ay=gridy[j,i+1]+gridy[j,i-1]
            cy=gridy[j+1,i]+gridy[j-1,i]
            by=gridy[j+1,i+1]+gridy[j-1,i-1]-gridy[j+1,i-1]-gridy[j-1,i+1]

            g = g11*g22-g12**2

            xixi_rf[0] = i*dxi-xi_rf[0]
            etaeta_rf[0] = j*deta-eta_rf[0]

            xixi_rf[1] = i*dxi-xi_rf[1]
            etaeta_rf[1] = j*deta-eta_rf[1]

                
            sPL=0.0
            sPR=0.0
            sQL=0.0
            sQR=0.0
            for z in range(2):
                sPL+=a_rf[z]*np.sign(xixi_rf[z])*np.exp(-c_rf[z]*np.abs(xixi_rf[z]))
                sQL+=a_rf[z]*np.sign(etaeta_rf[z])*np.exp(-c_rf[z]*np.abs(etaeta_rf[z] ))
            for z in range(2):
                sPR+=b_rf[z]*np.sign(xixi_rf[z])*np.exp(-d_rf[z]*( np.sqrt(xixi_rf[z]**2 + etaeta_rf[z]**2))  )
                sQR+=b_rf[z]*np.sign(etaeta_rf[z])*np.exp(-d_rf[z]*( np.sqrt(xixi_rf[z]**2 + etaeta_rf[z]**2))  )

            P = sPL + sPR
            Q = sQL + sQR
 
            Gx = g*(P*dxdxi+Q*dxdeta)
            Gy = g*(P*dydxi+Q*dydeta)

 
            gridx[j,i] = (1.0/(2*(a+c)))*(-4.0*(Gx*dxi**2*deta**2 ) + a*ax+c*cx-0.5*b*bx)
            gridy[j,i] = (1.0/(2*(a+c)))*(-4.0*(Gy*dxi**2*deta**2 ) + a*ay+c*cy-0.5*b*by)


grid2vtk(gridx,gridy,'test.vtk')



for i in range(ny):
    plt.plot(gridx[i,:],gridy[i,:],color='gray')
for i in range(nx):
    plt.plot(gridx[:,i],gridy[:,i],color='gray')


plt.plot(rt[:,0],rt[:,1])
plt.plot(rb[:,0],rb[:,1])
plt.plot(rl[:,0],rl[:,1])
plt.plot(rr[:,0],rr[:,1])
plt.show()
