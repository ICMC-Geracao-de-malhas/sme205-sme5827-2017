# coding: utf-8
import numpy as np


#Dados de consulta
v_anel = 3 #Vértice para consulta de anel
f_ver = 3 #Face para consulta de vértices
f_compa = 3 #Face para consulta de vértices das faces com aresta compartilhada 

#lendo pontos e faces
with open('socket.vtk') as f:
    content = f.readlines()

aux = [x+1 for x in range(len(content)) if 'POINTS' in content[x]]
pointIndex = aux
aux = [x for x in range(len(content)) if 'CELLS' in content[x]]
pointIndex += aux
 
aux = [x+1 for x in range(len(content)) if 'CELLS' in content[x]]
cellIndex = aux
aux = [x for x in range(len(content)) if 'CELL_TYPES' in content[x]]
cellIndex += aux

points = np.loadtxt(content[pointIndex[0]:pointIndex[1]])
cells = np.loadtxt(content[cellIndex[0]:cellIndex[1]])[:,1:]

tCor = np.zeros(((3*len(cells),8)))
n = 1

#primeiroPreenchimento
for i in range(len(cells)):
    #corners
    tCor[(i+1)*3 - 3,0] = n 
    tCor[(i+1)*3 - 2,0] = n+1
    tCor[(i+1)*3 - 1,0] = n+2
    #vertices
    tCor[(i+1)*3 - 3, 1] = cells[i,0]+1 
    tCor[(i+1)*3 - 2, 1] = cells[i,1]+1
    tCor[(i+1)*3 - 1, 1] = cells[i,2]+1
    #faces
    tCor[(i+1)*3 - 3, 2] = i+1 
    tCor[(i+1)*3 - 2, 2] = i+1
    tCor[(i+1)*3 - 1, 2] = i+1
    #antihorario
    tCor[(i+1)*3 - 3, 3] = n+1 
    tCor[(i+1)*3 - 2, 3] = n+2
    tCor[(i+1)*3 - 1, 3] = n
    #horario
    tCor[(i+1)*3 - 3, 4] = n+2 
    tCor[(i+1)*3 - 2, 4] = n
    tCor[(i+1)*3 - 1, 4] = n+1
    #opostos
    #primeiroCorner
    p1 = cells[i,1] 
    p2 = cells[i,2]
    for j in range(len(cells)):
        if ((p1 in cells[j])and(p2 in cells[j])):
            cellNumber = j;
            if ((p1 in [cells[cellNumber,0],cells[cellNumber,1]])and(p2 in [cells[cellNumber,0],cells[cellNumber,1]])):
                opos = (cellNumber+1)*3 
                if opos != n:
                    break
            if ((p1 in [cells[cellNumber,1],cells[cellNumber,2]])and(p2 in [cells[cellNumber,1],cells[cellNumber,2]])):
                opos = (cellNumber+1)*3 - 2
                if opos != n:
                    break
            if ((p1 in [cells[cellNumber,2],cells[cellNumber,0]])and(p2 in [cells[cellNumber,2],cells[cellNumber,0]])):
                opos = (cellNumber+1)*3 - 1
                if opos != n:
                    break
    if opos == n:
        opos = 0
    tCor[(i+1)*3 - 3, 5] = opos
    
    #opostos
    #segudoCorner
    p1 = cells[i,2] 
    p2 = cells[i,0]
    for j in range(len(cells)):
        if ((p1 in cells[j])and(p2 in cells[j])):
            cellNumber = j;
            if ((p1 in [cells[cellNumber,0],cells[cellNumber,1]])and(p2 in [cells[cellNumber,0],cells[cellNumber,1]])):
                opos = (cellNumber+1)*3
                if opos != n+1:
                    break  
            if ((p1 in [cells[cellNumber,1],cells[cellNumber,2]])and(p2 in [cells[cellNumber,1],cells[cellNumber,2]])):
                opos = (cellNumber+1)*3 - 2
                if opos != n+1:
                    break
            if ((p1 in [cells[cellNumber,2],cells[cellNumber,0]])and(p2 in [cells[cellNumber,2],cells[cellNumber,0]])):
                opos = (cellNumber+1)*3 - 1
                if opos != n+1:
                    break
    if opos == n+1:
        opos = 0
    tCor[(i+1)*3 - 2, 5] = opos
    
    #opostos
    #terceiroCorner
    aux = False
    p1 = cells[i,0] 
    p2 = cells[i,1]
    for j in range(len(cells)):
        if ((p1 in cells[j])and(p2 in cells[j])):
            cellNumber = j;
            if ((p1 in [cells[cellNumber,0],cells[cellNumber,1]])and(p2 in [cells[cellNumber,0],cells[cellNumber,1]])):
                opos = (cellNumber+1)*3
                if opos != n+2:
                    break                    
            if ((p1 in [cells[cellNumber,1],cells[cellNumber,2]])and(p2 in [cells[cellNumber,1],cells[cellNumber,2]])):
                opos = (cellNumber+1)*3 - 2
                if opos != n+2:
                    break  
            if ((p1 in [cells[cellNumber,2],cells[cellNumber,0]])and(p2 in [cells[cellNumber,2],cells[cellNumber,0]])):
                opos = (cellNumber+1)*3 - 1
                if opos != n+2:
                    break  
    if opos == n+2:
        opos = 0
    tCor[(i+1)*3 - 1, 5] = opos
    n += 3

#segundoPreenchimento - corners direito e esquerdo
for i in range(len(tCor)):
    if tCor[i,5] !=  0:
        opos = int(tCor[i,5])
        hora = int(tCor[i,4])
        ahora = int(tCor[i,3])
      
        hora_opo = int(tCor[opos-1,4])
        ahora_opo = int(tCor[opos-1,3])
        
        
    tCor[ahora-1,7] = tCor[hora_opo-1,0]
    tCor[hora-1,6] = tCor[ahora_opo-1,0]
    
#np.savetxt('cornerTable.txt',tCor,fmt='%i')



#Consulta de vertices e faces
#Vertices do anel
v = v_anel+1
c_aux = []
v_aux = []
for i in tCor:
    if int(i[1]==v):
        c_aux.append(tCor[int(i[0]-1),3])
        c_aux.append(tCor[int(i[0]-1),4])

print "Os vértices do anel do vértice %i são:"%(v-1) 
for i in c_aux:
    if tCor[int(i-1),1] in v_aux:
        a =  0
    else:
        v_aux.append(int(tCor[int(i-1),1]))
        print points[int(tCor[int(i-1),1])-1]


#Vertices da face
f = f_ver+1
c_aux = []
v_aux = []
for i in tCor:
    if int(i[2]==f):
        c_aux.append(i[0])

print "Os vértices da face %i são:"%(f-1) 
for i in c_aux:
    if tCor[int(i-1),1] in v_aux:
        a =  0
    else:
        v_aux.append(int(tCor[int(i-1),1]))
        print points[int(tCor[int(i-1),1])-1]


#Vertices das faces compartilhadas
f = f_compa+1
f_aux = []
c_aux = []
v_aux = []
for i in tCor:
    if int(i[2]==f):
        c_aux.append(i[0])
        if i[5] != 0:
            f_aux.append(tCor[int(i[5])-1,2])
            
c_aux = []
for j in f_aux:
    for i in tCor:
        if int(i[2]==j):
            c_aux.append(i[0])

print "Os vértices das faces que compartilham uma aresta com a face %i são:"%(f-1) 
for i in c_aux:
    if tCor[int(i-1),1] in v_aux:
        a =  0
    else:
        v_aux.append(int(tCor[int(i-1),1]))
        print points[int(tCor[int(i-1),1])-1]

