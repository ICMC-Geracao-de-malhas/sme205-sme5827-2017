# -*- coding: utf-8 -*-
import os
import numpy
import matplotlib.pyplot as plt
import math
from util import Util

#                       .-'`'-.
#              ,-'`'.   '._     \     ______
#            /    .'  ___ `-._  |    \ .-'`
#           |   .' ,-' __ `'/.`.'  ___\\
#   ______  \ .' \',-' 12 '-.  '.  `-._ \
#   '`-. /   ` / / 11    7 1 `.  `.    '.\
#      //___  . '10     /    2 \  ;
#     / _.-'  | |      O      3|  |  ______
#    /.'      | |9      \      '  '  '`-. /
#      ______ '  \ 8     \   4/  /      //___
#      \ .-'`  '. `'.7  6  5.'  '      / _.-'
#    ___\\       `. _ `'''` _.'\\-.   /.'
#    `-._ \       .//`''--''   (   )
#        '.\     (   )          '-`
#                 `-'
# trim, trim trim: Sucks that this is a 3D mesh and it get's hard to make sure
# we did everything right

#TODO: Comment this code

class Vertex:
	def __init__(self, x, y, z):
		self.x = x
		self.y = y
		self.z = z
		self.corners = []

	def __str__(self):
		msg = str(self.x) + " " + str(self.y) + " " + str(self.z) + " "
		for i in self.corners:
			msg += str(i.index) + " "
		return msg

class Corner:
	def __init__(self):
		self.face = -1
		self.vertex = Vertex(0.0, 0.0, 0.0)
		self.next = None
		self.previous = None
		self.opost = None
		self.right = None
		self.left = None
		self.index = -1

	def __str__(self):
		msg = str(self.index) + " " + str(self.face) + " "
		msg += str(self.next.index) + " " + str(self.previous.index) + " "
		if self.opost is not None:
			msg += str(self.opost.index) + " "
		else:
			msg += "None "
		if self.right is not None:
			msg += str(self.right.index) + " "
		else:
			msg += "None "
		if self.left is not None:
			msg += str(self.left.index) + " "
		else:
			msg += "None "
		return msg

def get_ring(target_vertex, vertex_list, corner_list):
	target = vertex_list[target_vertex]
	vertex_corners = vertex_list[target_vertex].corners
	curr_set = set([])
	plt.plot(target.x, target.y, 'go', markersize=3.0)
	for i in range(0, len(vertex_corners)):
		corner = vertex_corners[i]
		v0 = corner.next.vertex
		v1 = corner.previous.vertex
		linesx = [v0.x, v1.x]
		linesy = [v0.y, v1.y]
		# plt.plot(linesx, linesy, 'b')
		plt.plot(v0.x, v0.y, 'bo', markersize=3.0)
		plt.plot(v1.x, v1.y, 'bo', markersize=3.0)

	plt.show()

def get_equals(list0, list1, curr_face):
	result = []
	for i in range(0, len(list0)):
		for j in range(0, len(list1)):
			ctx0 = list0[i]
			ctx1 = list1[j]
			if ctx0 == ctx1:
				result.append([i, j])
	if len(result) > 0:
		for i in result:
			if list0[i[0]] != curr_face:
				return i
	return [None, None]

data = Util.parseTriangularVTK("tri.vtk")

if data[0] is not None:
	print "Parsed ok, generating tables..."
	curr_corner = 0
	face_count = len(data[3])
	corner_list = [None]*3*len(data[4])
	vertex_list = [None]*len(data[0])
	for i in range(0, len(data[0])):
		vertex_list[i] = Vertex(data[0][i], data[1][i], data[2][i])

	Util.plotTriangularData(data[0], data[1], data[3], data[4], data[5])
	for i in range(0, face_count):
		idx0 = data[3][i]
		idx1 = data[4][i]
		idx2 = data[5][i]
		v0 = Vertex(data[0][idx0], data[1][idx0], data[2][idx0])
		v1 = Vertex(data[0][idx1], data[1][idx1], data[2][idx1])
		v2 = Vertex(data[0][idx2], data[1][idx2], data[2][idx2])

		corner0 = Corner()
		corner0.face = i
		corner0.vertex = v0
		corner0.index = curr_corner
		curr_corner += 1

		corner1 = Corner()
		corner1.face = i
		corner1.vertex = v1
		corner1.index = curr_corner
		curr_corner += 1

		corner2 = Corner()
		corner2.face = i
		corner2.vertex = v2
		corner2.index = curr_corner
		curr_corner += 1
		
		corner0.next = corner1
		corner0.previous = corner2
		corner1.next = corner2
		corner1.previous = corner0
		corner2.next = corner0
		corner2.previous = corner1


		vertex_list[idx0].corners.append(corner0)
		vertex_list[idx1].corners.append(corner1)
		vertex_list[idx2].corners.append(corner2)

		corner_list[corner0.index] = corner0
		corner_list[corner1.index] = corner1
		corner_list[corner2.index] = corner2

	curr_corner = 0
	for i in range(0, face_count):
		idx0 = data[3][i]
		idx1 = data[4][i]
		idx2 = data[5][i]

		# for idx0
		cornersA = vertex_list[idx1].corners
		cornersB = vertex_list[idx2].corners
		facesA = []
		facesB = []
		for corner in cornersA:
			facesA.append(corner.face)
		for corner in cornersB:
			facesB.append(corner.face)

		equals = get_equals(facesA, facesB, i)
		if equals[0] is not None:
			selected0 = corner_list[cornersA[equals[0]].index]
			selected1 = corner_list[cornersB[equals[1]].index]
			set0 = set([selected0.next.index, selected0.previous.index])
			set1 = set([selected1.next.index, selected1.previous.index])
			setsub0 = set([selected0.index])
			setsub1 = set([selected1.index])
			resp = set0.union(set1) - setsub0 - setsub1
			corner_curr = corner_list[curr_corner]
			corner_list[curr_corner].opost = corner_list[list(resp)[0]]
			corner_list[corner_curr.next.index].right = corner_list[list(resp)[0]]
			corner_list[corner_curr.previous.index].left = corner_list[list(resp)[0]]

		curr_corner += 1

		# for idx1
		cornersA = vertex_list[idx0].corners
		cornersB = vertex_list[idx2].corners
		facesA = []
		facesB = []
		for corner in cornersA:
			facesA.append(corner.face)
		for corner in cornersB:
			facesB.append(corner.face)

		equals = get_equals(facesA, facesB, i)
		if equals[0] is not None:
			selected0 = corner_list[cornersA[equals[0]].index]
			selected1 = corner_list[cornersB[equals[1]].index]
			set0 = set([selected0.next.index, selected0.previous.index])
			set1 = set([selected1.next.index, selected1.previous.index])
			setsub0 = set([selected0.index])
			setsub1 = set([selected1.index])
			resp = set0.union(set1) - setsub0 - setsub1
			corner_curr = corner_list[curr_corner]
			corner_list[curr_corner].opost = corner_list[list(resp)[0]]
			corner_list[corner_curr.next.index].right = corner_list[list(resp)[0]]
			corner_list[corner_curr.previous.index].left = corner_list[list(resp)[0]]
			
		curr_corner += 1

		# for idx2
		cornersA = vertex_list[idx0].corners
		cornersB = vertex_list[idx1].corners
		facesA = []
		facesB = []
		for corner in cornersA:
			facesA.append(corner.face)
		for corner in cornersB:
			facesB.append(corner.face)

		equals = get_equals(facesA, facesB, i)
		if equals[0] is not None:
			selected0 = corner_list[cornersA[equals[0]].index]
			selected1 = corner_list[cornersB[equals[1]].index]
			set0 = set([selected0.next.index, selected0.previous.index])
			set1 = set([selected1.next.index, selected1.previous.index])
			setsub0 = set([selected0.index])
			setsub1 = set([selected1.index])
			resp = set0.union(set1) - setsub0 - setsub1
			corner_curr = corner_list[curr_corner]
			corner_list[curr_corner].opost = corner_list[list(resp)[0]]
			corner_list[corner_curr.next.index].right = corner_list[list(resp)[0]]
			corner_list[corner_curr.previous.index].left = corner_list[list(resp)[0]]
			
		curr_corner += 1

	with open("output.txt", "w") as fd:
		fd.write("##### Begining of vertex table:\n")
		for vertex in vertex_list:
			msg = str(vertex)
			msg += "\n"
			fd.write(msg)
		fd.write("##### End of vertex table\n")
		fd.write("##### Begining of corner table\n")
		for corner in corner_list:
			msg = str(corner)
			msg += "\n"
			fd.write(msg)
		fd.write("##### End of corner table\n")

	print "finished, output is in 'output.txt'"
	get_ring(2, vertex_list, corner_list)

else:
	print "Could not parse vtk file"


