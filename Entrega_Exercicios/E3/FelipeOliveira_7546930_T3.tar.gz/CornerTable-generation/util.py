import os, sys
import numpy
import matplotlib.pyplot as plt
class Util:

    @staticmethod
    def parseTriangularVTK(filename):
        print "Opening file ", filename
        content = []
        try:
            with open(filename, "r") as fd:
                content = fd.readlines()
            content = [x.strip() for x in content]
            pointParse = False
            pointsFinished = False
            faceParse = False
            faceFinished = False
            data_x = []
            data_y = []
            data_z = []
            face_x = []
            face_y = []
            face_z = []
            for line in content:
                splitted = line.split(' ')
                if len(splitted) == 0:
                    continue
                else:
                    if splitted[0] == "POINTS":
                        pointParse = True
                        faceParse = False
                        continue
                    elif splitted[0] == "CELLS":
                        faceParse = True
                        pointParse = False
                        continue
                    else:
                        if pointParse:
                            if len(splitted) == 3:
                                data_x.append(float(splitted[0]))
                                data_y.append(float(splitted[1]))
                                data_z.append(float(splitted[2]))
                        elif faceParse:
                            if len(splitted) == 4 and splitted[0] == "3":
                                face_x.append(int(splitted[1]))
                                face_y.append(int(splitted[2]))
                                face_z.append(int(splitted[3]))
                            else:
                                print "Unknown line: ", line
            return [data_x, data_y, data_z, face_x, face_y, face_z]
        except:
            return [None]


    @staticmethod
    def mapTo(x, A, B, a, b):
        return ((x - A)*(b - a)/(B - A) + a)

    @staticmethod
    def plotPoints(X, Y):
        count = len(X)
        for i in range(0, count):
            plt.plot(X[i], Y[i], 'bo')
        plt.show()

    @staticmethod
    def plotTriangularData(X, Y, faces_x, faces_y, faces_z):
        triangles = len(faces_x)
        beg = 0
        end = triangles
        for i in range(beg, end):
            ix = faces_x[i]
            iy = faces_y[i]
            iz = faces_z[i]
            v0 = [X[ix], Y[ix]]
            v1 = [X[iy], Y[iy]]
            v2 = [X[iz], Y[iz]]
            linex = [v0[0], v1[0]]
            liney = [v0[1], v1[1]]
            plt.plot(linex, liney, 'r')
            linex = [v1[0], v2[0]]
            liney = [v1[1], v2[1]]
            plt.plot(linex, liney, 'r')
            linex = [v0[0], v2[0]]
            liney = [v0[1], v2[1]]
            plt.plot(linex, liney, 'r')
        
    @staticmethod
    # Construct vtk file from matrixes X and Y
    # they are supposed to be constructed in a col-major first manner
    def dataToVTK(X, Y, filename):
        print "Writing VTK file: ", filename
        try:
            with open(filename, "w") as fd:
                fd.write("# vtk DataFile Version 3.0\n")
                fd.write("Auto generated file\n")
                fd.write("ASCII\n")
                fd.write("DATASET POLYDATA\n")
                pointCount = len(X) * len(Y)
                cellCount = (len(X) - 1) * (len(Y) - 1)
                dataCount = cellCount * 5
                fd.write("POINTS " + str(pointCount) + " float\n")
                for j in range(0, len(Y)):
                    for i in range(0, len(X)):
                        fd.write(str(X[i, j]) +  " " + str(Y[i, j]) + " 0.0\n")
                fd.write("POLYGONS " + str(cellCount) + " " + str(dataCount) + "\n")
                position = 0
                line = 0
                for i in range(0, cellCount):
                    limit = (line + 1)*len(X) - 1
                    if position == limit:
                        line += 1
                        position = line * len(X)
                    nextline = position + len(X)
                    fd.write("4 " + str(position) + " " + str(position+1) \
                             + " " + str(nextline+1) + " " + str(nextline) + "\n")
                    position += 1
                fd.close()
                print "Finished generating VTK file"
        except:
            print "Error writing VTK file"

    @staticmethod
    def parseConfFile(filename):
        try:
            with open(filename, "r") as fd:
                content = fd.read()
                data = content.split('\n')
                pos = 0
                X = []
                Y = []
                reverse = False
                pos = 0
                if data[0] == "blocked":
                    reverse = True
                    pos = 1
                for i in range(pos, len(data)):
                    floats = data[pos].split()
                    if len(floats) == 2:
                        x = float(floats[0])
                        y = float(floats[1])
                        X.append(x)
                        Y.append(y)
                    elif reverse:
                        vals = data[pos:]
                        X = list(reversed(X))
                        Y = list(reversed(Y))
                        data = vals
                        pos = 0
                    pos += 1
                fd.close()
                if reverse:
                    return [list(reversed(X)),\
                            list(reversed(Y))]
                return [X, Y]
        except:
            print "Error parsing ", filename
            return None
