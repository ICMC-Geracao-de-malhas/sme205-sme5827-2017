import vtk
import sys
import numpy as np

class Corner(object):
   def __init__(self,id):
        self.id = id
        self.cv=-1
        self.ct=-1
        self.cn=-1
        self.cp=-1
        self.co=-1
        self.cl=-1
        self.cr=-1
   def __iter__(self):
       return [self.id, self.cv, self.ct, self.cn, self.cp, self.co, self.cl, self.cr] 
   def __repr__(self):
        return "<id:%4d, cv:%4d, ct:%4d, cn:%4d, cp:%4d, co:%4d, cl:%4d, cr:%4d>" % (self.id, self.cv, self.ct,self.cn, self.cp,self.co, self.cl, self.cr )
   def __str__(self):
        return "id:%4d, cv:%4d, ct:%4d, cn:%4d, cp:%4d, co:%4d, cl:%4d, cr:%4d" % (self.id, self.cv, self.ct,self.cn, self.cp,self.co, self.cl, self.cr )

if ( len(sys.argv) < 4 ):
  print("usage: \n  $"+sys.argv[0]+" filename.vtk <query1|query2> N\n")
  sys.exit("Wrong parameters!")
  

inf=9999
reader = vtk.vtkDataSetReader()
reader.SetFileName(sys.argv[1])
reader.Update()

vtkdata = reader.GetOutput()
CellArray = vtkdata.GetCells()
#for p in range(vtkdata.GetNumberOfPoints()):
#  print vtkdata.GetPoint(p)

corners = []
triangles=[]
trianglesc=[]

print "Computing corners - step 1..."
cid=0
for t in range(vtkdata.GetNumberOfCells()):

  CellData = vtkdata.GetCell(t)
  clabels=[]
  for i in range(3):
    corner=Corner(cid)
    corner.cv=CellData.GetPointIds().GetId(i)
    corner.ct=t
    corners.append(corner)
    clabels.append(cid)
    cid=cid+1

  triangles.append([CellData.GetPointIds().GetId(0),CellData.GetPointIds().GetId(1), CellData.GetPointIds().GetId(2) ])
  trianglesc.append(clabels) 

 
print "Computing corners - step 2..."
for c in corners:
  CellData = vtkdata.GetCell(c.ct)
  p0=CellData.GetPointIds().GetId(0)
  p1=CellData.GetPointIds().GetId(1)
  p2=CellData.GetPointIds().GetId(2)

  if( c.cv == p0 ):
      c.cn = trianglesc[c.ct][1]
      c.cp = trianglesc[c.ct][2]
  else:
    if( c.cv == p1 ):
        c.cn = trianglesc[c.ct][2]
        c.cp = trianglesc[c.ct][0]
    else :
      if( c.cv == p2 ):
        c.cn = trianglesc[c.ct][0]
        c.cp = trianglesc[c.ct][1]

for i in range(cid):
  #Opposite
  corner=corners[i]
  v1=corners[corner.cp].cv #v2
  v2=corners[corner.cn].cv #v1, inverted
  
  ti= [triangles.index(t) for t in triangles if (t[0] == v1 and t[1]==v2) or (t[1] == v1 and t[2]==v2) or (t[2] == v1 and t[0]==v2)]

  if( len(ti)==0 ): #if is empty
    corner.co=inf
  else:
    twhere =triangles[ti[0]]  #[0 1 2]
    twherec=trianglesc[ti[0]]  #[0 1 2]
    if( twhere[0]==v1 and twhere[1]==v2 ):
       corner.co=twherec[2]
    if( twhere[1]==v1 and twhere[2]==v2 ):
       corner.co=twherec[0]
    if( twhere[2]==v1 and twhere[0]==v2 ):
       corner.co=twherec[1]
  #Left
  newc=corners[corner.cn] #for left 
  v1=corners[newc.cp].cv 
  v2=corners[newc.cn].cv

  tl= [triangles.index(t) for t in triangles if (t[0] == v1 and t[1]==v2) or (t[1] == v1 and t[2]==v2) or (t[2] == v1 and t[0]==v2)]

  if( len(tl)==0 ): #if is empty
    corner.cl=inf
  else:
    twhere =triangles[tl[0]]  #[0 1 2]
    twherec=trianglesc[tl[0]]  #[0 1 2]
    if( twhere[0]==v1 and twhere[1]==v2 ):
       corner.cl=twherec[2]
    if( twhere[1]==v1 and twhere[2]==v2 ):
       corner.cl=twherec[0]
    if( twhere[2]==v1 and twhere[0]==v2 ):
       corner.cl=twherec[1]

  #Right
  newr=corners[corner.cp] #for right
  v1=corners[newr.cp].cv 
  v2=corners[newr.cn].cv

  tr= [triangles.index(t) for t in triangles if (t[0] == v1 and t[1]==v2) or (t[1] == v1 and t[2]==v2) or (t[2] == v1 and t[0]==v2)]

  if( len(tr)==0 ): #if is empty
    corner.cr=inf
  else:
    twhere =triangles[tr[0]]  #[0 1 2]
    twherec=trianglesc[tr[0]]  #[0 1 2]
    if( twhere[0]==v1 and twhere[1]==v2 ):
       corner.cr=twherec[2]
    if( twhere[1]==v1 and twhere[2]==v2 ):
       corner.cr=twherec[0]
    if( twhere[2]==v1 and twhere[0]==v2 ):
       corner.cr=twherec[1]

print "Executing query ..."

if( sys.argv[2]=="query1" ):
  queryv=int(sys.argv[3]) #785
  qtriangles=[c.ct for c in corners if (c.cv== queryv)] #triangles shared by vertex
  #print qtriangles
  qresponse={}
  for qt in qtriangles:
    if( queryv==triangles[qt][0] ):
      qresponse[triangles[qt][1]]=0
      qresponse[triangles[qt][2]]=0
    if( queryv==triangles[qt][1] ):
      qresponse[triangles[qt][0]]=0
      qresponse[triangles[qt][2]]=0
    if( queryv==triangles[qt][2] ):
      qresponse[triangles[qt][0]]=0
      qresponse[triangles[qt][1]]=0
  print qresponse.keys()
else:
  if( sys.argv[2]=="query2" ):
    queryt=int(sys.argv[3]) #1 for small grid, 1476 for socket
    vertexs=triangles[queryt]
    #print vertexs
    qresponse={} #triangles
    for v in vertexs:
      qtriangles=[c.ct for c in corners if (c.cv== v)]
      #print qtriangles
      for qt in qtriangles:
        qresponse[qt]=triangles[qt]
    del qresponse[queryt]
    #print qresponse.values()
    print qresponse
   


