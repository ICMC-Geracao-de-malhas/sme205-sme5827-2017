import numpy as np

import sys

if( len(sys.argv) < 5 ):
  print "Use: "
  print "Ex. $python corner.py 515 515 469 516"
  exit(0)

#Para executar digite python corner.py <vertice do anel> <vertice1 do triangulo> <vertice2 do triangulo> <vertice3 do triangulo>

#Carrega vertices e celulas do vtk
def leVtk():

    datafile = open('socket.vtk','rt')

    vertices = [[]]

    while True:
        line = datafile.readline()
        if "POINTS" in line:
            numPoints = int(line.split()[1])
            vertices = [[0 for i in xrange(0,3)] for i in xrange(0,numPoints)]
            for i in range (0,numPoints):
                l = datafile.readline()
                vertices[i][0] = float(l.split()[0])
                vertices[i][1] = float(l.split()[1])
                vertices[i][2] = float(l.split()[2])


        if "CELLS" in line:
            numCells = int(line.split()[1])
            celulas = [[0 for i in xrange(0,3)] for i in xrange(0,numCells)]
            for i in range (0,numCells):
                l = datafile.readline()
                celulas[i][0] = int(l.split()[1])
                celulas[i][1] = int(l.split()[2])
                celulas[i][2] = int(l.split()[3])

            return numCells, numPoints, vertices, celulas


cell = [[]]

vertex = [[]]

numCells, numP, vertex, cell = leVtk()

#cria a tabela
def constroiCorner():

    tam = numCells*3

    tableCorner = [[-1 for i in xrange(0,7)] for i in xrange(0,tam)]

    t = 0

    flag = 0
    k = 0
    for i in range(0,tam):
        flag = flag + 1

        tableCorner[i][0] = cell[t][k]
        tableCorner[i][1] = t
        tableCorner[i][2] = 3*t + (i+1)%3
        if (k == 0):
            tableCorner[i][3] = tableCorner[i][2] + 1
        else:
            tableCorner[i][3] = i - 1

        k = k + 1

        if flag == 3:

            if (t < numCells-1):
                t = t + 1
                for c in range(0, i+1):

                    if ((tableCorner[tableCorner[c][2]][0] == cell[t][0] and
                                tableCorner[tableCorner[c][3]][0] == cell[t][2]) or (tableCorner[tableCorner[c][2]][0] == cell[t][2] and
                                tableCorner[tableCorner[c][3]][0] == cell[t][0])):
                        tableCorner[c][4] = i + 2
                        tableCorner[i + 2][4] = c
                    if ((tableCorner[tableCorner[c][2]][0] == cell[t][0] and
                                tableCorner[tableCorner[c][3]][0] == cell[t][1]) or (tableCorner[tableCorner[c][2]][0] == cell[t][1] and
                                tableCorner[tableCorner[c][3]][0] == cell[t][0])):
                        tableCorner[c][4] = i + 3
                        tableCorner[i + 3][4] = c
                    if ((tableCorner[tableCorner[c][2]][0] == cell[t][1] and
                                tableCorner[tableCorner[c][3]][0] == cell[t][2]) or (tableCorner[tableCorner[c][2]][0] == cell[t][2] and
                                tableCorner[tableCorner[c][3]][0] == cell[t][1])):
                        tableCorner[c][4] = i + 1
                        tableCorner[i + 1][4] = c

            for c in range(0, i + 1):

                if (tableCorner[c][5] == -1):
                    if (tableCorner[tableCorner[c][3]][4] != -1):
                        tableCorner[c][5] = tableCorner[tableCorner[c][3]][4]

                if (tableCorner[c][6] == -1):
                    if (tableCorner[tableCorner[c][2]][4] != -1):
                        tableCorner[c][6] = tableCorner[tableCorner[c][2]][4]

            flag = 0
            k = 0

    return tableCorner


tableCorner = [[]]

corner = constroiCorner()

#Checa de esta no array
def isInArray(arr, v1, v2, v3):

    for j in range (0,arr.__len__()):
        if (v1 in arr[j] and v2 in arr[j] and v3 in arr[j]):
            return 1

    return 0

#calcula o anel de um vertice
def anel(v):

    anel = []

    tam = numCells * 3

    for i in range(0,tam):

        if (corner[i][0] == v):

            if (corner[corner[i][2]][0] not in anel):
                anel.append(corner[corner[i][2]][0])
            if (corner[corner[i][3]][0] not in anel):
                anel.append(corner[corner[i][3]][0])

    return anel


#verifica todas as interseccoes de um triangulo
def interseccaoTriangulo(v1,v2,v3):

    triangulos = []

    tam = numCells * 3

    p = []

    p.append([v1,v2,v3])

    for i in range(0, tam):

        if (corner[i][0] == v1):
            if (isInArray(triangulos,v1,corner[corner[i][2]][0],corner[corner[i][3]][0]) == 0 and isInArray(p,v1,corner[corner[i][2]][0],corner[corner[i][3]][0]) == 0):
                triangulos.append([v1,corner[corner[i][2]][0],corner[corner[i][3]][0]])
        if (corner[i][0] == v2):
            if (isInArray(triangulos,v2,corner[corner[i][2]][0],corner[corner[i][3]][0]) == 0 and isInArray(p,v2,corner[corner[i][2]][0],corner[corner[i][3]][0]) == 0):
                triangulos.append([v2,corner[corner[i][2]][0],corner[corner[i][3]][0]])
        if (corner[i][0] == v3):
            if (isInArray(triangulos,v3,corner[corner[i][2]][0],corner[corner[i][3]][0]) == 0 and isInArray(p,v3,corner[corner[i][2]][0],corner[corner[i][3]][0]) == 0):
                triangulos.append([v3,corner[corner[i][2]][0],corner[corner[i][3]][0]])

    return triangulos


print("O anel do triangulo eh: " + str(anel(int(sys.argv[1]))))
print("\n")
print("Os triangulos que tem interseccao com triangulo " + str(int(sys.argv[2])) + " " + str(int(sys.argv[3]))+ " " + str(int(sys.argv[4])) + " sao: " + str(interseccaoTriangulo(int(sys.argv[2]),int(sys.argv[3]),int(sys.argv[4]))))



