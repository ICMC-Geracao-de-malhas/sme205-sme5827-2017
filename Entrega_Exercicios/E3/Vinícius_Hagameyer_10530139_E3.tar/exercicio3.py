# -*- coding: utf-8 -*-
"""
Created on Thu Sep 21 11:23:33 2017

@author: vinicius
"""

import sys
import numpy as np

def leituravtk(nome,t=3):
    f = open(nome,'rt')
    i = 0
    n = 0
    cell = 0
    p = 0
    nc = 0
    while 1 == 1:
        l = f.readline()
        if i == 4:
            n = int(l.split(' ')[1])
            p = np.zeros((n,3))
        elif i > 4 and i < (n+5):
            p[i-5,0]= float(l.split(' ')[0])
            p[i-5,1]= float(l.split(' ')[1])
        elif i== n+5:
            nc = int(l.split(' ')[1])
            cell = np.zeros((nc,t))
        elif i>= n+6 and i< n+6+nc:
            for j in range(t):
                cell[i-n-6,j]=int(l.split(' ')[j+1])
                
        elif i == n+6+nc:
            break
        i+=1
        
    return (p, cell )




p,cell = leituravtk('teste.vtk')

def vtktoconer(p,cell):
    c =[]# np.zeros((nc,7))
    
    for i in range(len(cell)):
        c.append([cell[i,0],i, 1 + i*3,2 + i*3 ,'','','' ])
        c.append([cell[i,1],i, 2 + i*3, i*3 ,'','','' ])
        c.append([cell[i,2],i,  i*3,1 + i*3 ,'','','' ])
        for j in range(len(c)-3):
            if c[j][0]==c[i*3][0]:
                if c[c[j][2]][0]==c[c[i*3][3]][0]:
                    c[i*3][5]= j
                    c[j][6]= i*3
                if c[c[j][3]][0]==c[c[i*3][2]][0]:
                    c[i*3][6]= j
                    c[j][5]= i*3
            if c[j][0]==c[i*3 +1][0]:
                if c[c[j][2]][0]==c[c[i*3 +1][3]][0]:
                    c[i*3 +1][5]= j
                    c[j][6]= i*3 +1
                if c[c[j][3]][0]==c[c[i*3 +1][2]][0]:
                    c[i*3 +1][6]= j
                    c[j][5]= i*3 +1
            if c[j][0]==c[i*3 +2][0]:
                if c[c[j][2]][0]==c[c[i*3 +2][3]][0]:
                    c[i*3 + 2][5]= j
                    c[j][6]= i*3 +2
                if c[c[j][3]][0]==c[c[i*3 +2][2]][0]:
                    c[i*3 +2][6]= j
                    c[j][5]= i*3 +2
        if c[c[i*3][2]][6] != '' :
            c[i*3][4]=c[c[c[i*3][2]][6] ][2]
            c[c[i*3][4]][4] = i*3
        if c[c[i*3 +1][2]][6] != '' :
            c[i*3 +1][4]=c[c[c[i*3 +1][2]][6] ][2]
            c[c[i*3 +1][4]][4] = i*3 + 1
        if c[c[i*3 +2][2]][6] != '' :
            c[i*3 +2][4]=c[c[c[i*3 +2][2]][6] ][2]
            c[c[i*3 +2][4]][4] = i*3 + 2
        
    return (p,c)
        

def anel(v,c):
    #v é o indice do vértice
    for i in range(len(c)):
        if c[i][1]==v:
            break
    a = [c[i][3]]
    if c[i][6] != ('') :
        j = c[i][6]
        while i!=j:
            if c[j][6] != ('') :
                j = c[j][6]
                a.append(c[j][3])
            else:
                break
    else:
        if c[i][5] != ('') :
            j = c[i][5]
            while i!=j:
                if c[j][5] != ('') :
                    j = c[j][5]
                    a.append(c[j][2])
                else:
                    break
    return (a)
    
def fadjacente(f,c):
    faces = ['']*3
    if c[f*3][4]!='':
        faces[0] = c[c[f*3][4]][1]
    if c[f*3 +1][4]!='':
        faces[0] = c[c[f*3 +1][4]][1]
    if c[f*3 + 2][4]!='':
        faces[0] = c[c[f*3 + 2][4]][1]
    return (faces)