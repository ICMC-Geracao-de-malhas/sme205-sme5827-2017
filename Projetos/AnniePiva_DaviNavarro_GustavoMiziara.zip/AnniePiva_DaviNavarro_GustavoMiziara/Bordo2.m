function [ gridx2, gridy2, gridx1, gridy1, n2] = Bordo2(D, R, L, K, nt, nv)

%Top
x_top = linspace(0, R, nt);
y_top = sqrt(R^2 - x_top.^2);
x_top = [(D+R)*ones(1,nt) - x_top, D+x_top(:,2:nt)];
for i = 1:nt-1
    y_help(i) = y_top(nt-i);
end
y_top = [y_top, -y_help];

rt = [x_top; y_top];

%%Bottom
nb = 2*nt - 1;
per = 2*(D/2+R) + 4*R;
dx = per/(nb-1);
n1 = round((D/2+R)/dx);
n2 = nb - 2*n1 + 2;

x_DE = linspace(D+R, D/2,n1);
y_DE = 2*R*ones(1,n1);

x_EF = D/2*ones(1,n2);
y_EF = linspace(2*R, -2*R, n2);

x_FC = linspace(D/2, D+R, n1);
y_FC = -2*R*ones(1,n1);

rb = [x_DE(:, 1:n1-1), x_EF(:, 1:n2-1), x_FC;...
    y_DE(:, 1:n1-1), y_EF(:, 1:n2-1), y_FC];
    
%%Left
x_left = (D+R)*ones(1,nv);
y_left = linspace(2*R, R, nv);

rl = [x_left; y_left];

%%Right
x_right = x_left;
y_right = linspace(-2*R, -R, nv);

rr = [x_right; y_right];

%% Parametros
ny = nv;
nx = nb;

%%Formacao do grid
gridx2 = zeros(ny,nx);
gridy2 = zeros(ny,nx);

gridx2(1,:) = rb(1,:);
gridx2(ny,:) = rt(1,:);
gridx2(:, 1) = rl(1,:);
gridx2(:, nx) = rr(1,:);
gridy2(1,:) = rb(2,:);
gridy2(ny,:) = rt(2,:);
gridy2(:, 1) = rl(2,:);
gridy2(:, nx) = rr(2,:);

%Chute inicial = metodo transfinito
dx = 1/(nx-1);
dy = 1/(ny-1);

for j = 2:ny-1
    for i = 2:nx-1
        idx = (i-1)*dx;
        jdy = (j-1)*dy;
        gridx2(j,i) = (1 - idx)*rl(1,j) + idx*rr(1,j) + (1 - jdy)*rb(1,i) + ...
            jdy*rt(1,i) - (1 -idx)*(1 - jdy)*rb(1,1) - (1 - idx)*jdy*rt(1,1) - ...
            idx*(1 - jdy)*rb(1,nx) - idx*jdy*rt(1,nx);
        gridy2(j,i) = (1 - idx)*rl(2,j) + idx*rr(2,j) + (1 - jdy)*rb(2,i) + ...
            jdy*rt(2,i) - (1 -idx)*(1 - jdy)*rb(2,1) - (1 - idx)*jdy*rt(2,1) -...
            idx*(1 - jdy)*rb(2,nx) - idx*jdy*rt(2,nx);
    end
end

%Metodo eliptico
dxi = 1/nx;
deta = 1/ny;
N = 100;

ai = 20*70;
ci = 15;
eta_i = 1;

for k = 1:N
    for j = 2:ny-1
        for i = 2:nx-1
            idx = (i-1)*dx;
            jdy = (j-1)*dy;
            dxdxi = (gridx2(j,i+1) - gridx2(j,i-1))/(2*dxi);
            dydxi = (gridy2(j,i+1) - gridy2(j,i-1))/(2*dxi);
            dxdeta = (gridx2(j+1,i) - gridx2(j-1,i))/(2*deta);
            dydeta = (gridy2(j+1,i)-gridy2(j-1,i))/(2*deta);
            g11 = dxdxi^2 + dydxi^2;
            g22 = dxdeta^2 + dydeta^2;
            g12 = dxdxi*dxdeta + dydxi*dydeta;
            g = g11*g22 - g12^2;
            a = 4*(deta^2)*g22;
            b = 4*dxi*deta*g12;
            c = 4*(dxi^2)*g11;
            P(j,i) = 0;
            Q(j,i) = ai*(jdy - eta_i)/abs(jdy - eta_i)*exp(-ci*abs(jdy - eta_i));
            ControlX(j,i) = 4*dxi^2*deta^2*g*(P(j,i)*dxdxi + Q(j,i)*dxdeta);
            ControlY(j,i) = 4*dxi^2*deta^2*g*(P(j,i)*dydxi + Q(j,i)*dydeta);
            gridx2(j,i) = (1/(2*(a+c)))*(a*(gridx2(j,i+1)+gridx2(j,i-1))+c*...
                (gridx2(j+1,i)+gridx2(j-1,i))-0.5*(b*(gridx2(j+1,i+1)+gridx2(j-1,i-1)-...
                gridx2(j+1,i-1)-gridx2(j-1,i+1)))-ControlX(j,i));
            gridy2(j,i) = (1/(2*(a+c)))*(a*(gridy2(j,i+1)+gridy2(j,i-1))+c*...
                (gridy2(j+1,i)+gridy2(j-1,i))-0.5*(b*(gridy2(j+1,i+1)+gridy2(j-1,i-1)-...
                gridy2(j+1,i-1)-gridy2(j-1,i+1)))-ControlY(j,i));
        end
    end
end

%Plot
for i = 1:nx
    plot(gridx2(:,i),gridy2(:,i),'k')
    hold on
end
for i = 1:ny
    plot(gridx2(i,:),gridy2(i,:),'k')
end

plot(rb(1,:), rb(2,:),'k', 'linewidth', 1.5)
plot(rt(1,:), rt(2,:),'g', 'linewidth', 1.5)
plot(rr(1,:), rr(2,:),'b', 'linewidth', 1.5)
plot(rl(1,:), rl(2,:),'r', 'linewidth', 1.5)
axis([0, L, -2*R, 2*R])

%%Grid 1

nx = 5;
x_1 = linspace(0,D/2, nx);
ny = n2;

gridx1 = zeros(ny,nx);
for i = 1:ny
    gridx1(i,:) = x_1;
end

gridy1 = zeros(ny,nx);
for i = 1:nx
    gridy1(:,i) = linspace(2*R, -2*R, n2);
end

for i = 1:ny
plot(gridx1(i,:),gridy1(i,:),'k')
end

for i = 1:nx
plot(gridx1(:,i),gridy1(:,i),'k')
end

