function [gridx3, gridy3] = Bordo3(D, R, L, K, nt, nv,X3);

%%Top
x_top = linspace(0, R, nt);
y_top = sqrt(R^2 - x_top.^2);

for i = 1:nt-1
    y_help(i) = y_top(nt-i);
    x_help(i) = x_top(nt-i);
end
y_top = [y_top, -y_help];
x_top = [(D+R)*ones(1,nt)+x_top, (D+R)*ones(1,nt-1)+x_help];

rt3 = [x_top; y_top];

%Bottom
nb = 2*nt - 1;
per = 2*(D/2+R) + 4*R;
dx = per/(nb-1);
n1 = round((D/2+R)/dx);
n2 = nb - 2*n1 + 2;

x_DE = linspace(D+R, X3,n1);
y_DE = 2*R*ones(1,n1);

x_EF = X3*ones(1,n2);
y_EF = linspace(2*R, -2*R, n2);

x_FC = linspace(X3, D+R, n1);
y_FC = -2*R*ones(1,n1);

rb3 = [x_DE(:, 1:n1-1), x_EF(:, 1:n2-1), x_FC;...
    y_DE(:, 1:n1-1), y_EF(:, 1:n2-1), y_FC];
    
%Left
x_left = (D+R)*ones(1,nv);
y_left = linspace(2*R, R, nv);

rl3 = [x_left; y_left];

%Right
x_right = x_left;
y_right = linspace(-2*R, -R, nv);

rr3 = [x_right; y_right];

%% Parametros
ny = nv;
nx = nb;

%%Formacao do grid
gridx3 = zeros(ny,nx);
gridy3 = zeros(ny,nx);

gridx3(1,:) = rb3(1,:);
gridx3(ny,:) = rt3(1,:);
gridx3(:, 1) = rl3(1,:);
gridx3(:, nx) = rr3(1,:);
gridy3(1,:) = rb3(2,:);
gridy3(ny,:) = rt3(2,:);
gridy3(:, 1) = rl3(2,:);
gridy3(:, nx) = rr3(2,:);

%Chute inicial = metodo transfinito
dx = 1/(nx-1);
dy = 1/(ny-1);

for j = 2:ny-1
    for i = 2:nx-1
        idx = (i-1)*dx;
        jdy = (j-1)*dy;
        gridx3(j,i) = (1 - idx)*rl3(1,j) + idx*rr3(1,j) + (1 - jdy)*rb3(1,i) + ...
            jdy*rt3(1,i) - (1 -idx)*(1 - jdy)*rb3(1,1) - (1 - idx)*jdy*rt3(1,1) - ...
            idx*(1 - jdy)*rb3(1,nx) - idx*jdy*rt3(1,nx);
        gridy3(j,i) = (1 - idx)*rl3(2,j) + idx*rr3(2,j) + (1 - jdy)*rb3(2,i) + ...
            jdy*rt3(2,i) - (1 -idx)*(1 - jdy)*rb3(2,1) - (1 - idx)*jdy*rt3(2,1) -...
            idx*(1 - jdy)*rb3(2,nx) - idx*jdy*rt3(2,nx);
    end
end

%Metodo eliptico
dxi = 1/nx;
deta = 1/ny;
N = 100;

ai = 7;
ci = 5;
eta_i = 1;
ni_i = 0.499;

for k = 1:N
    for j = 2:ny-1
        for i = 2:nx-1
            idx = (i-1)*dx;
            jdy = (j-1)*dy;
            dxdxi = (gridx3(j,i+1) - gridx3(j,i-1))/(2*dxi);
            dydxi = (gridy3(j,i+1) - gridy3(j,i-1))/(2*dxi);
            dxdeta = (gridx3(j+1,i) - gridx3(j-1,i))/(2*deta);
            dydeta = (gridy3(j+1,i)-gridy3(j-1,i))/(2*deta);
            g11 = dxdxi^2 + dydxi^2;
            g22 = dxdeta^2 + dydeta^2;
            g12 = dxdxi*dxdeta + dydxi*dydeta;
            g = g11*g22 - g12^2;
            a = 4*(deta^2)*g22;
            b = 4*dxi*deta*g12;
            c = 4*(dxi^2)*g11;
            P(j,i) = ai*(idx - ni_i)/abs(idx - ni_i)*exp(-ci*abs(idx - ni_i));
%             P(j,i) = 0;
            Q(j,i) = ai*(jdy - eta_i)/abs(jdy - eta_i)*exp(-ci*abs(jdy - eta_i));
            ControlX(j,i) = 4*dxi^2*deta^2*g*(P(j,i)*dxdxi + Q(j,i)*dxdeta);
            ControlY(j,i) = 4*dxi^2*deta^2*g*(P(j,i)*dydxi + Q(j,i)*dydeta);
            gridx3(j,i) = (1/(2*(a+c)))*(a*(gridx3(j,i+1)+gridx3(j,i-1))+c*...
                (gridx3(j+1,i)+gridx3(j-1,i))-0.5*(b*(gridx3(j+1,i+1)+gridx3(j-1,i-1)-...
                gridx3(j+1,i-1)-gridx3(j-1,i+1)))-ControlX(j,i));
            gridy3(j,i) = (1/(2*(a+c)))*(a*(gridy3(j,i+1)+gridy3(j,i-1))+c*...
                (gridy3(j+1,i)+gridy3(j-1,i))-0.5*(b*(gridy3(j+1,i+1)+gridy3(j-1,i-1)-...
                gridy3(j+1,i-1)-gridy3(j-1,i+1)))-ControlY(j,i));
        end
    end
end

%%Plot
for i = 1:nx
    plot(gridx3(:,i),gridy3(:,i),'k')
    hold on
end
for i = 1:ny
    plot(gridx3(i,:),gridy3(i,:),'k')
end

plot(rb3(1,:), rb3(2,:),'k', 'linewidth', 1.5)
plot(rt3(1,:), rt3(2,:),'g', 'linewidth', 1.5)
plot(rr3(1,:), rr3(2,:),'b', 'linewidth', 1.5)
plot(rl3(1,:), rl3(2,:),'r', 'linewidth', 1.5)