function [gridxi, gridyi] = Bordoi(D, R, L, K, nt,n2, Xi, Xf);


x_top = linspace(Xi, Xf, nt);
y_top = 2*R*ones(1,nt);
rt = [x_top; y_top];

x_bottom = x_top;
y_bottom = -2*R*ones(1,nt);
rb = [x_bottom; y_bottom];

x_left = Xi*ones(1,n2);
y_left = linspace(-2*R, 2*R, n2);
rl = [x_left; y_left];

x_right = Xf*ones(1,n2);
y_right = linspace(-2*R, 2*R, n2);
rr = [x_right; y_right];

%% Parametros
ny = n2;
nx = nt;

%%Formacao do grid
gridxi = zeros(ny,nx);
gridyi = zeros(ny,nx);

gridxi(1,:) = rb(1,:);
gridxi(ny,:) = rt(1,:);
gridxi(:, 1) = rl(1,:);
gridxi(:, nx) = rr(1,:);
gridyi(1,:) = rb(2,:);
gridyi(ny,:) = rt(2,:);
gridyi(:, 1) = rl(2,:);
gridyi(:, nx) = rr(2,:);

%Chute inicial = metodo transfinito
dx = 1/(nx-1);
dy = 1/(ny-1);

for j = 2:ny-1
    for i = 2:nx-1
        idx = (i-1)*dx;
        jdy = (j-1)*dy;
        gridxi(j,i) = (1 - idx)*rl(1,j) + idx*rr(1,j) + (1 - jdy)*rb(1,i) + ...
            jdy*rt(1,i) - (1 -idx)*(1 - jdy)*rb(1,1) - (1 - idx)*jdy*rt(1,1) - ...
            idx*(1 - jdy)*rb(1,nx) - idx*jdy*rt(1,nx);
        gridyi(j,i) = (1 - idx)*rl(2,j) + idx*rr(2,j) + (1 - jdy)*rb(2,i) + ...
            jdy*rt(2,i) - (1 -idx)*(1 - jdy)*rb(2,1) - (1 - idx)*jdy*rt(2,1) -...
            idx*(1 - jdy)*rb(2,nx) - idx*jdy*rt(2,nx);
    end
end

%Metodo eliptico
dxi = 1/nx;
deta = 1/ny;
N = 100;

ai = 7;
ci = 5;
eta_i = 0.499;

for k = 1:N
    for j = 2:ny-1
        for i = 2:nx-1
            idx = (i-1)*dx;
            jdy = (j-1)*dy;
            dxdxi = (gridxi(j,i+1) - gridxi(j,i-1))/(2*dxi);
            dydxi = (gridyi(j,i+1) - gridyi(j,i-1))/(2*dxi);
            dxdeta = (gridxi(j+1,i) - gridxi(j-1,i))/(2*deta);
            dydeta = (gridyi(j+1,i)-gridyi(j-1,i))/(2*deta);
            g11 = dxdxi^2 + dydxi^2;
            g22 = dxdeta^2 + dydeta^2;
            g12 = dxdxi*dxdeta + dydxi*dydeta;
            g = g11*g22 - g12^2;
            a = 4*(deta^2)*g22;
            b = 4*dxi*deta*g12;
            c = 4*(dxi^2)*g11;
            P(j,i) = 0;
            Q(j,i) = ai*(jdy - eta_i)/abs(jdy - eta_i)*exp(-ci*abs(jdy - eta_i));
            ControlX(j,i) = 4*dxi^2*deta^2*g*(P(j,i)*dxdxi + Q(j,i)*dxdeta);
            ControlY(j,i) = 4*dxi^2*deta^2*g*(P(j,i)*dydxi + Q(j,i)*dydeta);
            gridxi(j,i) = (1/(2*(a+c)))*(a*(gridxi(j,i+1)+gridxi(j,i-1))+c*...
                (gridxi(j+1,i)+gridxi(j-1,i))-0.5*(b*(gridxi(j+1,i+1)+gridxi(j-1,i-1)-...
                gridxi(j+1,i-1)-gridxi(j-1,i+1)))-ControlX(j,i));
            gridyi(j,i) = (1/(2*(a+c)))*(a*(gridyi(j,i+1)+gridyi(j,i-1))+c*...
                (gridyi(j+1,i)+gridyi(j-1,i))-0.5*(b*(gridyi(j+1,i+1)+gridyi(j-1,i-1)-...
                gridyi(j+1,i-1)-gridyi(j-1,i+1)))-ControlY(j,i));
        end
    end
end

%%Plot
for i = 1:nx
    plot(gridxi(:,i),gridyi(:,i),'k')
    hold on
end
for i = 1:ny
    plot(gridxi(i,:),gridyi(i,:),'k')
end

plot(rb(1,:), rb(2,:),'k', 'linewidth', 1.5)
plot(rt(1,:), rt(2,:),'g', 'linewidth', 1.5)
plot(rr(1,:), rr(2,:),'b', 'linewidth', 1.5)
plot(rl(1,:), rl(2,:),'r', 'linewidth', 1.5)