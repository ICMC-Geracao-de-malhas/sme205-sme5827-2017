clc
clear all
close all

D = 1;
R = 1;
L = 10;
H = 4*R; %Altura
K = 5;

l1 = D/2; %Comprimento do primeiro dom�nio
l2 = D/2 + R;
l = (L - (D + R))/(K - 1);


X = zeros(1, K);
X(1) = l1;
X(2) = l1 + l2;

for i = 3:K+1
    X(i) = X(2) + (i-2)*l;
    if X(3) < D + 2*R
        X(3) = D + 2*R;
        l = (L - X(3))/(K - 1);
    end
end

nt = 41;
nv = 15;
[gridx2, gridy2, gridx1, gridy1, n2] = Bordo2(D, R, L, K, nt, nv);
[gridx3, gridy3] = Bordo3(D, R, L, K, nt, nv,X(3));

if K > 2
    nd = K - 2;
    for i = 1:nd
        Xi = X(i+2);
        Xf = X(i+3);
        [gridxi, gridyi] = Bordoi(D, R, L, K, nt,n2, Xi, Xf);
        gridx_dir((i-1)*n2+1:i*n2,(i-1)*nt+1:i*nt) = gridxi;
        gridy_dir((i-1)*n2+1:i*n2,(i-1)*nt+1:i*nt) = gridyi;
    end
end

%%Escrever em texto
XX = [gridx1(:); gridx2(:); gridx3(:); gridx_dir(:)];
XX = XX';
YY = [gridy1(:); gridy2(:); gridy3(:); gridy_dir(:)];
YY = YY';

Cord = [XX; YY];

arq = fopen('Malha1.txt','w');
fprintf(arq,'%4.2f %4.2f\n', Cord);
fclose(arq)
