function[]=p12TTM()
	
	%xi-eta Domain
	global mcsi;  
	global neta; 
	global dcsi; 
	global deta; 
    global cor;
    global dataX;
    global dataY;
    cor = 'm';
	
	mcsi=20;
	neta=20;
	dcsi=1/(mcsi-1);
	deta=1/(neta-1);
	
	%x-y Domain
	%primary
	
	global R
	global P
	global cc
	global dZCD;
	global delta;
	global dL;
	
	%not primary
	global L
	global A
	global B
	global C
	global D
	global E
	global F
	
	global ZC;
	global ZD;
	global ZE;
	global dZDE;
	global dAZC
	
	global YC;
	global YD;
	global YE;
	global YB;
	global dYCD;
	global dYDE;
	global dFYC;
	
	
	global AA;
	global FF;
	global BB;
	global EE;
	global theta_0;
	
	global AAR;
	global BBR;
	global gamma_0;
	
	global moveA;
	global moveB;
	
	global moveAA;
	global moveBB;
	global moveAA_theta;
	global moveA_theta;
	
	global moveAAR;
	global moveBBR; 
	global moveAAR_gamma
	global moveA_gamma
	
	
	
	
	figure(2);
	
	% set(Primary) parameters values
	
	
	R=2.5;
	dL=7.5;
	P=5;
	L=dL+R;
	cc=[L,0]
	dZCD=5;
	delta=0.001;
	
	% set (Not Primary) parameters values
	B=[L,R+P];
	C=[0,B(2)];
	D=[0,-C(2)];
	E=[L,D(2)];
	A=rB(0);
	F=rB(1);
	
	theta_0=60*pi/180;
	gamma_0=10*pi/180;
	%theta_0=0+0.05;
	%gamma_0=pi/2-0.05;
	AA=rBBB(0);
	FF=rBBB(1);
	BB=[AA(1),B(2)];
	EE=[FF(1),D(2)];
	
	moveA_gamma=pi/2;
	moveAAR_gamma=gamma_0;
	AAR=movingBot_Right(1);
	BBR=[AAR(1),B(2)];
	
	
	
	ZC=[cc(1)+R*sin(pi/2-delta),cc(2)+R*cos(pi/2-delta)];
	ZD=[ZC(1)+dZCD,ZC(2)];
	dZDE=B(2)-ZD(2);
	ZE=[ZD(1),B(2)];
	dAZC=(pi/2-delta)*R;
	
	dYCD=dZCD;
	YC=[ZC(1),-ZC(2)];
	YD=[ZD(1),-ZD(2)];
	YE=[ZE(1),-ZE(2)];
	dYDE=dZDE;
	dFYC=dAZC;
	
	% end parameters values
	
	
	%Draw Left Piece(Single Piece)
	
	hold on;
	topCurve=TopCurve(@rTTT);
	botCurve=BotCurve(@rBBB);
	leftCurve=LeftCurve(@rLLL);
	rightCurve=RightCurve(@rRRR);
	plot(topCurve(:,1),topCurve(:,2),'r','linewidth',2)%,'marker','o');
	plot(botCurve(:,1),botCurve(:,2),'m','linewidth',2)%,'marker','o');
	plot(rightCurve(:,1),rightCurve(:,2),'g','linewidth',2)%,'marker','o');
	plot(leftCurve(:,1),leftCurve(:,2),'k','linewidth',2)%,'marker','o');
	
	
	%Draw Right Piece(Single Piece)
	hold on;
	topCurve=TopCurve(@rTTTT);
	botCurve=BotCurve(@rBBBB);
	leftCurve=LeftCurve(@rLLLL);
	rightCurve=RightCurve(@rRRRR);
	plot(topCurve(:,1),topCurve(:,2),'r','linewidth',2)%,'marker','o');
	plot(botCurve(:,1),botCurve(:,2),'m','linewidth',2)%,'marker','o');
	plot(rightCurve(:,1),rightCurve(:,2),'g','linewidth',2)%,'marker','o');
	plot(leftCurve(:,1),leftCurve(:,2),'k','linewidth',2)%,'marker','o');
	
	%legend('Top','Bottom','Right','Left');
	
	%text
	text(A(1),A(2),'A');
	text(B(1),B(2),'B');
	text(C(1),C(2),'C');
	text(D(1),D(2),'D');
	text(E(1),E(2),'E');
	text(F(1),F(2),'F');
	
	text(cc(1),cc(2),'cc');
	
	text(AA(1),AA(2),'AA');
	text(FF(1),FF(2),'FF');
	text(EE(1),EE(2),'EE');
	text(BB(1),BB(2),'BB');
	
	
	
	plot(ZC(1),ZC(2));
	plot(ZD(1),ZD(2));
	plot(ZE(1),ZE(2));
	ZE
	text(ZC(1),ZC(2),'ZC');
	text(ZD(1),ZD(2),'ZD');
	text(ZE(1),ZE(2),'ZE');
	
	
	text(AAR(1),AAR(2),'AAR');
	text(BBR(1),BBR(2),'BBR');
	text(YC(1),YC(2),'YC');
	text(YD(1),YD(2),'YD');
	text(YE(1),YE(2),'YE');
	
	tic 
	build_AAToA(2);
	build_AToAAR(2)
	
	
	
	board=Board(@rTTT,@rBBB,@rLLL,@rRRR);
	boardZ=Board(@rTTTT,@rBBBB,@rLLLL,@rRRRR);
	
	[bT,bB,bL,bR]=verificaBound(board);
	
	
	plot(bT(:,1),bT(:,2),'color','r','marker','s','markersize',10);
	plot(bB(:,1),bB(:,2),'color','m','marker','s','markersize',10);
	plot(bL(:,1),bL(:,2),'color','k','marker','s','markersize',10)
	plot(bR(:,1),bR(:,2),'color','g','marker','s','markersize',10);
	
	[bT,bB,bL,bR]=verificaBound(boardZ);
	
	plot(bT(:,1),bT(:,2),'color','r','marker','s','markersize',10);
	plot(bB(:,1),bB(:,2),'color','m','marker','s','markersize',10);
	plot(bL(:,1),bL(:,2),'color','k','marker','s','markersize',10)
	plot(bR(:,1),bR(:,2),'color','g','marker','s','markersize',10);
	
	
	
	Y=inicia(board,@rTTT,@rBBB,@rLLL,@rRRR);
	%drawGrid(Y);
	
	
	%Y=fsolveJacobiTTM(Y,board);
	Y=fsolveJacobiTTM(Y,board);
	
	drawGrid(Y,0,cor)
	
	
	Y=inicia(boardZ,@rTTTT,@rBBBB,@rLLLL,@rRRRR);
	%drawGrid(Y);
	
	%Y=fsolveJacobiTTM(Y,boardZ);
	Y=fsolveJacobiTTM(Y,boardZ);
	toc
	drawGrid(Y,0,cor);
	%drawGrid(Y,1,'m');
    
    save('dataX.mat','dataX')
    save('dataY.mat','dataY')
    
    Xe = matfile('dataX.mat');
    Ye = matfile('dataY.mat');
    
    C = Xe.dataX
    D = Ye.dataY
    
    size(C)
    size(D)
    size(dataX)
    size(dataY)
    
    figure (3)
    plot(C,D)
    
    	
end

function[]=build_AAToA(kPieces)
	
	global A;
	global B;
	global AA;
	global BB;
	global theta_0;
    global cor;
	
	global moveA;
	global moveAA;
	global moveA_theta;
	global moveAA_theta;
	
	global moveB;
	global moveBB;
	kPieces=4;
	s=[0:0.01:1];
	ns=max(size(s));
	theta=zeros(1,kPieces);
	
	for i=1:kPieces
		theta(i)=theta_0-theta_0*(i-1)/(kPieces-1);
		
	end
	
	for i=1:kPieces-1
			
			moveAA_theta=theta(i);
			moveA_theta=theta(i+1);
			
			moveAA=movingBot_Left(0);
			moveBB=[moveAA(1),BB(2)];
			
			moveA=movingBot_Left(1);
			moveB=[moveA(1),B(2)];
			
			topCurve=TopCurve(@movingTop_Left);
			botCurve=BotCurve(@movingBot_Left);
			leftCurve=LeftCurve(@movingLeft_Left);
			rightCurve=RightCurve(@movingRight_Left);
			
			plot(topCurve(:,1),topCurve(:,2),'r','linewidth',2)%,'marker','o');
			plot(botCurve(:,1),botCurve(:,2),'m','linewidth',2)%,'marker','o');
			plot(rightCurve(:,1),rightCurve(:,2),'g','linewidth',2)%,'marker','o');
			plot(leftCurve(:,1),leftCurve(:,2),'k','linewidth',2)%,'marker','o');
			
			board=Board(@movingTop_Left,@movingBot_Left,@movingLeft_Left,@movingRight_Left);
			Y=inicia(board,@movingTop_Left,@movingBot_Left,@movingLeft_Left,@movingRight_Left);
			
			Y=fsolveJacobiTTM(Y,board);
			
			drawGrid(Y,0,cor)
			
			
			
			
	end
end

function[]=build_AToAAR(kPieces)
	
	global A;
	global B;
    global cor;
	
	global AAR;
	global BBR;
	global gamma_0;
	
	global moveA_gamma;
	global moveAAR_gamma;
	
	global moveA;
	global moveB;
	global moveAAR;
	global moveBBR;
	
	%global cc%
	%global R%
	kPieces=3;
	
	s=[0:0.01:1];
	ns=max(size(s));
	gamma_=zeros(1,kPieces);
	
	for i=1:kPieces
		gamma_(i)=pi/2+(gamma_0-pi/2)*(i-1)/(kPieces-1);
		
	end
	
	
	for i=1:kPieces-1
			
			moveAAR_gamma=gamma_(i+1);
			moveA_gamma=gamma_(i);
			
			moveAAR=movingBot_Right(1);
			moveBBR=[moveAAR(1),B(2)];
			
			
			moveA=movingBot_Right(0);
			moveB=[moveA(1),B(2)];
			
			%pause;
			topCurve=TopCurve(@movingTop_Right);
			botCurve=BotCurve(@movingBot_Right);
			leftCurve=LeftCurve(@movingLeft_Right);
			rightCurve=RightCurve(@movingRight_Right);
			
			plot(topCurve(:,1),topCurve(:,2),'r','linewidth',2)%,'marker','o');
			plot(botCurve(:,1),botCurve(:,2),'m','linewidth',2)%,'marker','o');
			plot(rightCurve(:,1),rightCurve(:,2),'g','linewidth',2)%,'marker','o');
			plot(leftCurve(:,1),leftCurve(:,2),'k','linewidth',2)%,'marker','o');
			
			board=Board(@movingTop_Right,@movingBot_Right,@movingLeft_Right,@movingRight_Right);
			Y=inicia(board,@movingTop_Right,@movingBot_Right,@movingLeft_Right,@movingRight_Right);
			Y=fsolveJacobiTTM(Y,board);
			drawGrid(Y,0,cor);
			
			
			
	end
	
	
end

function[mtr]=movingTop_Right(s)
	
	global moveB;
	global moveBBR;
	
	mtr=moveB+s*(moveBBR-moveB);
	
	
end


function[mtl]=movingTop_Left(s)
	
	global moveB;
	global moveBB;
	
	mtl=[0 0];
	mtl=moveBB+s*(moveB-moveBB);
	
end

function[rt]=rT(s)
	
	global L
	global R
	global P
	
	global B
	global C
	global D
	global E
	rt=[0 0];
	M=2*(L+R+P);
	Q=2*(R+P);
	
	if(s<=L/M)
		s0=0;
		s1=L/M;
		ts=(s-s0)/(s1-s0);
		rt=B+ts*(C-B);
	
	elseif(s<=(L+Q)/M)
		s0=L/M;
		s1=(L+Q)/M;
		ts=(s-s0)/(s1-s0);
		rt=C+ts*(D-C);
		
	elseif(s<=1)
		s0=(L+Q)/M;
		s1=1;
		ts=(s-s0)/(s1-s0);
		rt=D+ts*(E-D);
	end
	
	
end

function[rtt]=rTT(s)
	
	global B;
	global ZE;
	rtt=B+s*(ZE-B);
	
end

function[rttt]=rTTT(s)
	
	global L
	global R
	global P
	
	global BB
	global C
	global D
	global EE
	rttt=[0 0];
	LL=L-BB(1);
	M=2*(LL+R+P);
	Q=2*(R+P);
	
	if(s<=LL/M)
		s0=0;
		s1=LL/M;
		ts=(s-s0)/(s1-s0);
		rttt=BB+ts*(C-BB);
	
	elseif(s<=(LL+Q)/M)
		s0=LL/M;
		s1=(LL+Q)/M;
		ts=(s-s0)/(s1-s0);
		rttt=C+ts*(D-C);
		
	elseif(s<=1)
		s0=(LL+Q)/M;
		s1=1;
		ts=(s-s0)/(s1-s0);
		rttt=D+ts*(EE-D);
	end
	
	
end

function[rtttt]=rTTTT(s)
	
	global BBR;
	
	global ZE;
	rtttt=BBR+s*(ZE-BBR);
	
end



function[mbr]=movingBot_Right(s)
	
	global moveA_gamma;
	global moveAAR_gamma;
	global cc;
	global R;
	
	ts=(moveAAR_gamma-moveA_gamma)*s+moveA_gamma;
	
	
	mbr=[cc(1)+R*cos(ts),cc(2)+R*sin(ts)];
	
	
	
end

function[mbl]=movingBot_Left(s)
	
	global moveA_theta;
	global moveAA_theta;
	
	global cc;
	global R;
	
	ts=(moveA_theta-moveAA_theta)*s+moveAA_theta;
	mbl=[cc(1)+R*cos(ts+pi/2),cc(2)+R*sin(ts+pi/2)];
	
end


function[rb]=rB(s)
	
	global cc
	global R
	rb=[cc(1)+R*cos(pi*(0.5+s)),cc(2)+R*sin(pi*(0.5+s))];
	
	
end


function[rbb]=rBB(s)
	
	
	global cc;
	global R;
	global dAZC;
	global dZCD;
	global ZC;
	global ZD;
	global delta;
	
	M=dAZC+dZCD;
	
	rbb=[0 0];
	
	if(s<=dAZC/M)
		s0=0;
		s1=dAZC/M;
		ts=(s-s0)/(s1-s0);
		rbb=[cc(1)+R*sin(ts*(0.5*pi-delta)),cc(2)+R*cos(ts*(0.5*pi-delta))];
	else
		s0=dAZC/M;
		s1=1;
		ts=(s-s0)/(s1-s0);
		rbb=ZC+ts*(ZD-ZC);
	end
	
	
end

function[rbbb]=rBBB(s)
	
	global cc;
	global R;
	global theta_0;
	
	ts=(pi-2*theta_0)*s+(pi/2)+theta_0;
	rbbb=[cc(1)+R*cos(ts),cc(2)+R*sin(ts)];
	
end


function[rbbbb]=rBBBB(s)
	
	
	global cc;
	global R;
	global dAZC;
	global dZCD;
	global ZC;
	global ZD;
	global gamma_0;
	global delta;
	rbbbb=[0 0];
	
	dAARZC=R*(gamma_0-delta);
	M=dAARZC+dZCD;
	
	if(s<=dAARZC/M)
		s0=0;
		s1=dAARZC/M;
		ts=(s-s0)/(s1-s0);
		rbbbb=[cc(1)+R*cos(gamma_0+ts*(delta-gamma_0)),cc(2)+R*sin(gamma_0+ts*(delta-gamma_0))];
	else
		s0=dAARZC/M;
		s1=1;
		ts=(s-s0)/(s1-s0);
		rbbbb=ZC+ts*(ZD-ZC);
	end
	
	
end

function[mlr]=movingLeft_Right(s)
	
	global moveA;
	global moveB;
	
	mlr=moveA+s*(moveB-moveA);
	
end

function[mll]=movingLeft_Left(s)
	
	global moveAA;
	global moveBB;
	
	mll=moveAA+s*(moveBB-moveAA);
	

end

function[rl]=rL(s)
	
	global A
	global B
	
	
	rl=A+s*(B-A);
	
end
function[rll]=rLL(s)
	
	global A
	global B
	
	
	rll=A+s*(B-A);
	
end
function[rlll]=rLLL(s)
	
	global AA;
	global BB
	
	
	rlll=AA+s*(BB-AA);
	
end
function[rllll]=rLLLL(s)
	
	global AAR;
	global BBR;
	
	
	rllll=AAR+s*(BBR-AAR);
	
end

function[mrl]=movingRight_Left(s)
	
	global moveA;
	global moveB;
	
	mrl=moveA+s*(moveB-moveA);
	

end
function[mrr]=movingRight_Right(s)
	
	global moveAAR;
	global moveBBR;
	
	mrr=moveAAR+s*(moveBBR-moveAAR);
	
end
function[rr]=rR(s)
	
	global E
	global F
	
	rr=F+s*(E-F);

end
function[rrr]=rRR(s)
	
	global ZC;
	global ZD;
	global ZE;
	
	rrr=ZD+s*(ZE-ZD);
	
end

function[rrrr]=rRRR(s)
	
	global EE
	global FF
	
	rrrr=FF+s*(EE-FF);
	
	

end

function[rrrrr]=rRRRR(s)
	
	global ZD;
	global ZE;
	
	rrrrr=ZD+s*(ZE-ZD);
	

end

function[topCurve]=TopCurve(ff)
	
	s=0:0.01:1;
	ns=max(size(s));
	topCurve=zeros(ns,2);
	for i=1:ns
		topCurve(i,:)=ff(s(i));
	end
	mid=ceil(ns/2);
	
	text(topCurve(mid,1),topCurve(mid,2),'TOP','color','r');
	
end

function[botCurve]=BotCurve(ff)
	
	s=0:0.01:1;
	ns=max(size(s));
	botCurve=zeros(ns,2);
	for i=1:ns
		botCurve(i,:)=ff(s(i));
	end
	
	mid=ceil(ns/2);
	text(botCurve(mid,1),botCurve(mid,2),'BOTTOM','color','m');
	
end

function[leftCurve]=LeftCurve(ff)
	
	s=0:0.01:1;
	ns=max(size(s));
	leftCurve=zeros(ns,2);
	for i=1:ns
		
		leftCurve(i,:)=ff(s(i));
	end
	
	mid=ceil(ns/2);
	text(leftCurve(mid,1),leftCurve(mid,2),'LEFT','color','k');
	
end

function[rightCurve]=RightCurve(ff)
	
	s=0:0.01:1;
	ns=max(size(s));
	rightCurve=zeros(ns,2);
	
	for i=1:ns
		rightCurve(i,:)=ff(s(i));
	end
	
	mid=ceil(ns/2);
	text(rightCurve(mid,1),rightCurve(mid,2),'RIGHT','color','g');
	
	
end

function[board]=Board(ftop,fbot,fleft,fright)
	
	global mcsi;
	global neta;
	M=mcsi*neta;
	
	%bottom
	j=1;
	
	for i=1:mcsi
		
		K=mij(i,j);
		s=(i-1)/(mcsi-1);
		rb=fbot(s);
		board(K)=rb(1);
		board(K+M)=rb(2);
		
		
	end
	
	%top
	j=neta;
	
	for i=1:mcsi
		
		K=mij(i,j);
		s=(i-1)/(mcsi-1);
		rt=ftop(s);
		board(K)=rt(1);
		board(K+M)=rt(2);
		
		end
	
	
	%left
	i=1;
	
	for j=1:neta
		
		K=mij(i,j);
		s=(j-1)/(neta-1);
		rl=fleft(s);
		board(K)=rl(1);
		board(K+M)=rl(2);
		
	end
	
	i=mcsi;
	
	for j=1:neta
		
		K=mij(i,j);
		s=(j-1)/(neta-1);
		rr=fright(s);
		board(K)=rr(1);
		board(K+M)=rr(2);
		
	end

	
	
end

function[bT,bB,bL,bR]=verificaBound(Y)
	
	global mcsi;
	global neta;
	global dcsi;
	global deta;
	
	bT=zeros(mcsi,2);
	bB=zeros(mcsi,2);
	
	bL=zeros(neta,2);
	bR=zeros(neta,2);
	
	M=neta*mcsi;
	%bottom
	j=1;
	
	for i=1:mcsi
		K=mij(i,j);
		bB(i,:)=[Y(K),Y(K+M)];
		
		
	end
	
	%top
	j=neta;
	
	for i=1:mcsi
		K=mij(i,j);
		bT(i,:)=[Y(K),Y(K+M)];
	end
	
	%left
	i=1;
	
	for j=1:neta
		K=mij(i,j);
		bL(j,:)=[Y(K),Y(K+M)];
	end
	
	
	%right
	i=mcsi;
	
	for j=1:neta
		K=mij(i,j);
		bR(j,:)=[Y(K),Y(K+M)];
	end
	
	
	
end

function[Pt]=somaBool(csi,eta,ftop,fbot,fleft,fright)
	
	Pt=(1-csi)*fleft(eta)+csi*fright(eta)+(1-eta)*fbot(csi)+eta*ftop(csi)-(1-csi)*(1-eta)*fbot(0)-(1-csi)*eta*ftop(0)-csi*(1-eta)*fbot(1)-csi*eta*ftop(1);
	
end

function[Y0]=inicia(board,ftop,fbot,fleft,fright)
	global mcsi;
	global neta;
	
	M=neta*mcsi;
	
	Y0=board;
	
	for i=2:mcsi-1
		for j=2:neta-1
			
			
			csi=(i-1)/(mcsi-1);
			eta=(j-1)/(neta-1);
			Pt=somaBool(csi,eta,ftop,fbot,fleft,fright);
			K=mij(i,j);
			
			Y0(K)=Pt(1);
			Y0(K+M)=Pt(2);
		end
	end
	
	
	
	
end

function[]=drawGrid(Y,opposite,color)
	

	global mcsi;
	global neta;
	XX=zeros(mcsi,neta);
	YY=zeros(mcsi,neta);
	M=mcsi*neta;
	
	% desenhar a solucao
	
	for i=1:mcsi
		for j=1:neta
			K=mij(i,j);
			XX(i,j)=Y(K);
			YY(i,j)=Y(M+K);
		end
	end
	if(opposite==1)
			YY=-YY;
	end
	plot(XX,YY,color);
	%plot(XX',YY','m');
	saveX(XX);
    saveY(YY);
	
end

function[K]=mij(i,j)
	global mcsi;
	
	K=i+mcsi*(j-1);
	
end

function[d]=fc(fiij,fi_1j,dcsi)
	
	d=(fiij-fi_1j)/(2*dcsi);
	
end

function[d]=fu(fijj,fij_1,deta)
	
	d=(fijj-fij_1)/(2*deta);
	
end

function[d]=fcc_ij(fiij,fi_1j,dcsi)
	
	d=(fiij+fi_1j)/(dcsi^2);
	
	
end

function[d]=fuu_ij(fijj,fij_1,deta)
	
	d=(fijj+fij_1)/(deta^2);
	
	
end

function[fij]=fof(fiij,fi_1j,dcsi,fijj,fij_1,deta,g_11,g_12,g_22,f_uc)
	
	aij=2*g_22/(dcsi^2);
	bij=2*g_11/(deta^2);
	
	fij=(g_22*fcc_ij(fiij,fi_1j,dcsi)-2*g_12*f_uc+g_11*fuu_ij(fijj,fij_1,deta))/(aij+bij);
	
	
	
end

function[fij]=fofExt(fiij,fi_1j,dcsi,fijj,fij_1,deta,g_11,g_12,g_22,f_uc,p,q)
	
	aij=2*g_22/(dcsi^2);
	bij=2*g_11/(deta^2);
	
	g=g_11*g_22-(g_12)^2;
	
	fext=g*(p*fc(fiij,fi_1j,dcsi)+q*fu(fijj,fij_1,deta));
	
	fij=(g_22*fcc_ij(fiij,fi_1j,dcsi)-2*g_12*f_uc+g_11*fuu_ij(fijj,fij_1,deta)-fext)/(aij+bij);
	
	
	
	

end

function[d]=fuc(fiijj,fi_1j_1,fi_1jj,fiij_1,dcsi,deta)
	
	d=(fiijj+fi_1j_1-fi_1jj-fiij_1)/(4*dcsi*deta);
	
end

function[g]=g11(xiij,xi_1j,yiij,yi_1j,dcsi)
	
	g=(fc(xiij,xi_1j,dcsi))^2 +(fc(yiij,yi_1j,dcsi))^2;
	
end

function[g]=g22(xijj,xij_1,yijj,yij_1,deta)
	
	g=(fu(xijj,xij_1,deta))^2+(fu(yijj,yij_1,deta))^2;
	
end

function[g]=g12(xiij,xi_1j,  xijj,xij_1,  yiij,yi_1j,  yijj,yij_1,  deta,dcsi)
	
	g=fc(xiij,xi_1j,dcsi)*fu(xijj,xij_1,deta)+fc(yiij,yi_1j,dcsi)*fu(yijj,yij_1,deta);
	
	
	
end

function[Y]=fsolveJacobi(Y0,board)
	
	Y_old=Y0;
	for k=1:30
	Y_new=fJacobi(Y_old,board);
	Y_old=Y_new;
	end
	Y=Y_new;
	
end

function[F]=fJacobi(Y,board)
	global mcsi;
	global neta;
	global dcsi;
	global deta;
	
	mF=max(size(board));
	F=zeros(mF,1);
	M=mcsi*neta;
	F=board;
	
	%now the inner points
	for i=2:mcsi-1
		for j=2:neta-1
			
			ij=mij(i,j);
			
			iij=mij(i+1,j);
			i_1j=mij(i-1,j);
			
			ijj=mij(i,j+1);
			ij_1=mij(i,j-1);
			
			iijj=mij(i+1,j+1);
			i_1j_1=mij(i-1,j-1);
			i_1jj=mij(i-1,j+1);
			iij_1=mij(i+1,j-1);
			
			
			g_11=g11(Y(iij),Y(i_1j),Y(M+iij),Y(M+i_1j),dcsi);
			
			g_22=g22(Y(ijj),Y(ij_1),Y(M+ijj),Y(M+ij_1),deta);
			
			g_12=g12(Y(iij),Y(i_1j),  Y(ijj),Y(ij_1),  Y(M+iij),Y(M+i_1j),  Y(M+ijj),Y(M+ij_1),  deta,dcsi);
			
		
			xuc=fuc(Y(iijj),Y(i_1j_1),Y(i_1jj),Y(iij_1),dcsi,deta);
			yuc=fuc(Y(M+iijj),Y(M+i_1j_1),Y(M+i_1jj),Y(M+iij_1),dcsi,deta);
			
			
			F(ij)=fof(Y(iij),Y(i_1j),dcsi,Y(ijj),Y(ij_1),deta,g_11,g_12,g_22,xuc);
			F(M+ij)=fof(Y(iij+M),Y(i_1j+M),dcsi,Y(ijj+M),Y(ij_1+M),deta,g_11,g_12,g_22,yuc);
			
			
		end
	
	end
	
	
end

function[Y]=fsolveJacobiTTM(Y0,board)
	
	Y_old=Y0;
	for k=1:30
	Y_new=fJacobiTTM(Y_old,board);
	Y_old=Y_new;
	end
	Y=Y_new;
	
end

function[F]=fJacobiTTM(Y,board)
	
	global mcsi;
	global neta;
	global dcsi;
	global deta;
	global coor_CsiEta;
	
	mF=max(size(Y));
	F=zeros(mF,1);
	M=mcsi*neta;
	F=board;
	
	%now the inner points
	for i=2:mcsi-1
		for j=2:neta-1
			
			ij=mij(i,j);
			
			iij=mij(i+1,j);
			i_1j=mij(i-1,j);
			
			ijj=mij(i,j+1);
			ij_1=mij(i,j-1);
			
			iijj=mij(i+1,j+1);
			i_1j_1=mij(i-1,j-1);
			i_1jj=mij(i-1,j+1);
			iij_1=mij(i+1,j-1);
			
			
			g_11=g11(Y(iij),Y(i_1j),Y(M+iij),Y(M+i_1j),dcsi);
			
			g_22=g22(Y(ijj),Y(ij_1),Y(M+ijj),Y(M+ij_1),deta);
			
			g_12=g12(Y(iij),Y(i_1j),  Y(ijj),Y(ij_1),  Y(M+iij),Y(M+i_1j),  Y(M+ijj),Y(M+ij_1),  deta,dcsi);
			
			
			xuc=fuc(Y(iijj),Y(i_1j_1),Y(i_1jj),Y(iij_1),dcsi,deta);
			yuc=fuc(Y(M+iijj),Y(M+i_1j_1),Y(M+i_1jj),Y(M+iij_1),dcsi,deta);
			
			csi=(i-1)*dcsi;
			eta=(j-1)*deta;
			
			
			%q=3.8*sign(eta-0)*exp(-14.5*abs(eta-0));
			p=0;
			
            q=0;
			
			F(ij)=fofExt(Y(iij),Y(i_1j),dcsi,Y(ijj),Y(ij_1),deta,g_11,g_12,g_22,xuc,p,q);
			
			F(M+ij)=fofExt(Y(iij+M),Y(i_1j+M),dcsi,Y(ijj+M),Y(ij_1+M),deta,g_11,g_12,g_22,yuc,p,q);
			
			
		end
	
	end
	
end

function[] = saveX(XX)
    global dataX;
    
    dataX = [dataX XX];
      

end

function[] = saveY(YY)

    global dataY;
    dataY = [dataY YY];
    
end