function [] = processa()
    

    Xe = matfile('dataX.mat');
    Ye = matfile('dataY.mat');
    
    C = Xe.dataX;
    D = Ye.dataY;
    %plot(C(1:20,1:20),D(1:20,1:20));
    
    sizeC = size(C,1)*size(C,2);
    sizeD = size(D,1)*size(D,2);
    
    size(C)
    size(D)
    
    C = reshape(C, sizeC,1);
    D = reshape(D, sizeD,1);
       % figure(2);
        
            res = [C D]
            save('res.mat','res')
       
        %plot(C(1:400),D(1:400)); 
   
end