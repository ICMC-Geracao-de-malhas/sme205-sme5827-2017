import numpy as np
import math

def cutdomain(D,r,L,K):
  F=L-(2*r+D)
  g=(D+F)/(K)

  ys=[]
  xs=[]

  H=2*r+2*g #Normal case

  xs.append(0.0) 

  if( K<1 ):
    print "Select K>1, wrong parameter..!"
    exit(1)
  if( K==1 ):
    xs.append(D+r) #cut just in middle of circle
  if( K > 1 ):
    #Cut to Left and Cut to Right
    lsteps=int(D/g)
    rsteps=int(F/g)
    xsa=[]
    if F < g:
      H=2*r+2*F
      p=D-F+g
    else:
      p=D
    for i in range(0,lsteps):
      p=p-g
      xsa.insert(0,p)
    xs.extend(xsa)
    xs.append(D+r) #cut just in middle of circle
    if D < g:
      p=2*D+2*r-g
      H=2*r+2*D
    else:
      p=D+2*r   
    for i in range(0,rsteps):
      p=p+g
      xs.append(p)
  xs.append(L)
  ys.append(0)
  ys.append(H/2)
  ys.append(H)

  return H, xs, ys
#Create SubDomain and return Grid with borders filled
def adaptsubgrid(x1,x2,y1,y2,scase,r,H,row):

  nx=50 #41 #31 #29 #50  # 31 #35 #15 # 40 #60 #80  # 120, minutes, n%2>0
  ny=50 #41 #31 #40 #50  # 40 #50 #15 # 60 #80 #100  # 130

  #Grid is Regular or Irregular (flag)
  if( scase == 0 ):
    nx=int( (x2-x1)/(H/(2*nx)) )+1
    GX=np.zeros((ny,nx))
    GY=np.zeros((ny,nx))

    if( nx==1 ):
     deltaH=(x2-x1)
     deltaV=(y2-y1)
    else:
     deltaH=(x2-x1)/(nx-1)
     deltaV=(y2-y1)/(ny-1) 

     for j in range(nx): #rt rb
        GX[0   ,j] = x1+j*deltaH
        GY[0   ,j] = y1
        GX[ny-1,j] = x1+j*deltaH 
        GY[ny-1,j] = y2
     for i in range(ny): #rl and rr
        GX[i,0   ]=x1
        GY[i,0   ]=y1+i*deltaV
        GX[i,nx-1]=x2
        GY[i,nx-1]=y1+i*deltaV


    return [GX,GY]
  else:  #Four cases 1 2 3 4
    GY=np.zeros((ny,nx))
    GX=np.zeros((ny,nx))
    arc4=(1.0/2.0)*math.pi*r
    dx=(arc4 + (x2-x1)-r) /(nx)
    if( scase==1):
      xalpha=x2+r*math.cos(math.pi)
      c=int( arc4/dx ) #number of points in circle

      alpha=(math.pi/2.0)/c
      for j in range( c ): #rt
        GX[0,j]=x2+r*math.cos((3.0/2)*math.pi-alpha*j)
        GY[0,j]=y2+r*math.sin((3.0/2)*math.pi-alpha*j)
      deltaV=(xalpha-x1)/(nx-c-1)
      for j in range(nx-c):
        GX[0,j+c]=xalpha-j*deltaV
        GY[0,j+c]=y2

      deltaV=( (y2+r*math.sin((3.0/2)*math.pi)) - y1 ) / (ny-1)
      for i in range(ny): #rr
        GX[i,0]=x2
        GY[i,0]=(y2+r*math.sin((3.0/2)*math.pi)) -i*deltaV  

      deltaV=(y2-y1) / (ny-1)
      for i in range(ny): #rl and rr
       GX[i,nx-1]=x1
       GY[i,nx-1]=y2-i*deltaV

      deltaH=(1.0)*(x2-x1)/(nx-1)
      for i in range(nx):   #rb
       GX[ny-1,i]=x2-i*deltaH 
       GY[ny-1,i]=y1

    if( scase==3):
      xalpha=x2+r*math.cos(math.pi)
      c=int( arc4/dx ) #number of points in rect (line)
      alpha=(math.pi/2)/c
      for j in range( c ): #rt
        GX[0,j]=x2+r*math.cos((1.0/2)*math.pi+alpha*j)
        GY[0,j]=y1+r*math.sin((1.0/2)*math.pi+alpha*j)
      deltaV=(xalpha-x1)/(nx-c-1)
      for j in range(nx-c):
        GX[0,j+c]=xalpha-j*deltaV
        GY[0,j+c]=y1

      deltaV=( y2 - (y1+r*math.sin((1.0/2)*math.pi)) ) / (ny-1)
      for i in range(ny): #rr
        GX[i,0]=x2
        GY[i,0]=(y1+r*math.sin((1.0/2)*math.pi)) +i*deltaV  

      deltaV=(y2-y1) / (ny-1)
      for i in range(ny): #rl and rr
       GX[i,nx-1]=x1
       GY[i,nx-1]=y1+i*deltaV

      deltaH=(x2-x1)/(nx-1)
      for i in range(nx):   #rb
       GX[ny-1,i]=x2-i*deltaH 
       GY[ny-1,i]=y2
    if( scase==2):
   
      xalpha=x1+r
      c=int( arc4/dx ) #number of points in rect (line)
      alpha=(math.pi/2)/c
      for j in range( c ): #rt
        GX[0,j]=x1+r*math.cos((3.0/2)*math.pi+alpha*j)
        GY[0,j]=y2+r*math.sin((3.0/2)*math.pi+alpha*j)
      deltaH=(x2-xalpha)/(nx-c-1)
      for j in range(nx-c):
        GX[0,j+c]=xalpha+j*deltaH
        GY[0,j+c]=y2

      deltaV=( (y2+r*math.sin((3.0/2)*math.pi)) - y1 ) / (ny-1)
      for i in range(ny): #rr
        GX[i,0]=x1
        GY[i,0]=(y2+r*math.sin((3.0/2)*math.pi)) -i*deltaV  

      deltaV=(y2-y1) / (ny-1)
      for i in range(ny): #rl and rr
       GX[i,nx-1]=x2
       GY[i,nx-1]=y2-i*deltaV

      deltaH=(x2-x1)/(nx-1)
      for i in range(nx):   #rb
       GX[ny-1,i]=x1+i*deltaH 
       GY[ny-1,i]=y1

    if( scase==4):
   
      xalpha=x1+r
      c=int( arc4/dx ) #number of points in rect (line)
      alpha=(math.pi/2)/c
      for j in range( c ): #rt
        GX[0,j]=x1+r*math.cos((1.0/2)*math.pi-alpha*j)
        GY[0,j]=y1+r*math.sin((1.0/2)*math.pi-alpha*j)
      deltaH=(x2-xalpha)/(nx-c-1)
      for j in range(nx-c):
        GX[0,j+c]=xalpha+j*deltaH
        GY[0,j+c]=y1

      deltaV=(y2 - (y1+r*math.sin((1.0/2)*math.pi)) ) / (ny-1)
      for i in range(ny): #rr
        GX[i,0]=x1
        GY[i,0]=(y1+r*math.sin((1.0/2)*math.pi)) +i*deltaV  

      deltaV=(y2-y1) / (ny-1)
      for i in range(ny): #rl and rr
       GX[i,nx-1]=x2
       GY[i,nx-1]=y1+i*deltaV

      deltaH=(x2-x1)/(nx-1)
      for i in range(nx):   #rb
       GX[ny-1,i]=x1+i*deltaH 
       GY[ny-1,i]=y2

      #GX[ny-1,nx-1]=x2
      #GY[ny-1,nx-1]=y2       
    return [GX,GY]

#Join SubGrids

def joinsubgrids(vissubgrids):
#Order blocks (depend of how was divided), if is right is not necessary
  subgrids0=[]
  for item in range(0, len(vissubgrids)/2):
    gx=vissubgrids[item][0]
    gy=vissubgrids[item][1]
    h,w=gx.shape
    if( gx[0,0] > gx[0,w-1] ):
      gx=np.flip(gx,1) #horizontal
      gy=np.flip(gy,1) #horizontal
    if( gy[0,0] < gy[h-1,0] ):
      gx=np.flip(gx,0) #horizontal
      gy=np.flip(gy,0) #horizontal
    subgrids0.append([gx,gy])

  subgrids1=[]
  for item in range(len(vissubgrids)/2,len(vissubgrids)):
    gx=vissubgrids[item][0]
    gy=vissubgrids[item][1]
    h,w=gx.shape
    if( gx[0,0] > gx[0,w-1] ):
      gx=np.flip(gx,1) #horizontal
      gy=np.flip(gy,1) #horizontal
    if( gy[0,0] < gy[h-1,0] ):
      gx=np.flip(gx,0) #vertical
      gy=np.flip(gy,0) #vertical
    subgrids1.append([gx,gy])
#join subgrid by columns (overwrite last(prev) and first(next) column)
  row0x=subgrids0[0][0]
  row0y=subgrids0[0][1]
  for item in range(1, len(subgrids0)):
    gx=subgrids0[item][0]
    gy=subgrids0[item][1]
    h,w=gx.shape
    gx=gx[0:0+h,1:1+(w-1)]
    gy=gy[0:0+h,1:1+(w-1)]
    row0x=np.concatenate((row0x, gx), axis=1)  
    row0y=np.concatenate((row0y, gy), axis=1)  

  row1x=subgrids1[0][0]
  row1y=subgrids1[0][1]
  for item in range(1, len(subgrids1)):
    gx=subgrids1[item][0]
    gy=subgrids1[item][1]
    h,w=gx.shape
    gx=gx[0:0+h,1:1+(w-1)]
    gy=gy[0:0+h,1:1+(w-1)]
    row1x=np.concatenate((row1x, gx), axis=1)  
    row1y=np.concatenate((row1y, gy), axis=1)  

#join subgrid top and bottom
  h,w=row0y.shape
  h1,w1=row1y.shape
  s1=0  
  s2=0
  cs1=True
  for x in range(w):
    smothys=np.linspace(row0y[1,x],row1y[h-2,x], num=4)
    deltaB=(row0y[0,x]-row0y[1,x])/2
    deltaT=(row1y[h-2,x]-row1y[h-1,x])/2
    if( row0y[0,x] == row1y[h-1,x] ):
      if( cs1 ):
        s1=s1+1
      row0y[0  ,x]= smothys[1] #row0y[0,x] - deltaB 
      row1y[h-1,x]= smothys[2] #row1y[h-1,x] + deltaT
    else:
      cs1=False
      s2=s2+1
  fsubgrids=[]
  fsubgrids.append([row1x,row1y])
  fsubgrids.append([row0x,row0y])
  return fsubgrids, s1, s2


#Fill Computational Domain

def fillgrid(subgrid,scase): #elliptic
  gridx=subgrid[0]
  gridy=subgrid[1]

  ny=len(gridx)
  nx=len(gridx[0])

  dx = 1.0/nx
  dy = 1.0/ny
  
  for j in range(1,ny-1):
    for i in range(1,nx-1):
        idx = i*dx
        jdy = j*dy
        #changed T by B, for correct orientation
        RB =gridx[0,i] # rt[i,0]
        RB0=gridx[0,0] # rt[0,0]
        RBN=gridx[0,nx-1] #rt[nx-1,0]

        RT =gridx[ny-1,i] # rb[i,0] 
        RT0=gridx[ny-1,0] #rb[0,0]
        RTN=gridx[ny-1,nx-1] #rb[nx-1,0]

        RL= gridx[j,0]    #rl[j,0]
        RR= gridx[j,nx-1] #rr[j,0]

        gridx[j,i] = (1.0-idx)*RL + idx*RR + (1.0 - jdy)*RB + jdy*RT - (1.0-idx)*(1.0-jdy)*RB0 - (1.0 - idx)*jdy*RT0 - idx*(1.0-jdy)*RBN - idx*jdy*RTN

        RB =gridy[0,i] # rt[i,0]
        RB0=gridy[0,0] # rt[0,0]
        RBN=gridy[0,nx-1] #rt[nx-1,0]
        RT =gridy[ny-1,i] # rb[i,0] 
        RT0=gridy[ny-1,0] #rb[0,0]
        RTN=gridy[ny-1,nx-1] #rb[nx-1,0]
        RL= gridy[j,0]    #rl[j,0]
        RR= gridy[j,nx-1] #rr[j,0]

        gridy[j,i] = (1.0-idx)*RL + idx*RR + (1.0 - jdy)*RB + jdy*RT - (1.0-idx)*(1.0-jdy)*RB0 - (1.0 - idx)*jdy*RT0 - idx*(1.0-jdy)*RBN - idx*jdy*RTN
  
  dxi = 1.0/nx
  deta = 1.0/ny
  
  N=100
  for k in range(N):
    for j in range(1,ny-1):
        for i in range(1,nx-1):
            dxdxi = (gridx[j,i+1]-gridx[j,i-1])/(2.0*dxi)
            dydxi = (gridy[j,i+1]-gridy[j,i-1])/(2.0*dxi)
            dxdeta = (gridx[j+1,i]-gridx[j-1,i])/(2.0*deta)
            dydeta = (gridy[j+1,i]-gridy[j-1,i])/(2.0*deta)       
            g11 = dxdxi**2 + dydxi**2
            g22 = dxdeta**2 + dydeta**2
            g12 = dxdxi*dxdeta + dydxi*dydeta
            a = 4.0*(deta**2)*g22
            b = 4.0*dxi*deta*g12
            c = 4.0*(dxi**2)*g11

            ax=gridx[j,i+1]+gridx[j,i-1]
            cx=gridx[j+1,i]+gridx[j-1,i]
            bx=gridx[j+1,i+1]+gridx[j-1,i-1]-gridx[j+1,i-1]-gridx[j-1,i+1]

            ay=gridy[j,i+1]+gridy[j,i-1]
            cy=gridy[j+1,i]+gridy[j-1,i]
            by=gridy[j+1,i+1]+gridy[j-1,i-1]-gridy[j+1,i-1]-gridy[j-1,i+1]

            xtemp = (1.0/(2*(a+c)))*(a*ax+c*cx-0.5*b*bx)
            ytemp = (1.0/(2*(a+c)))*(a*ay+c*cy-0.5*b*by)

            gridx[j,i] =xtemp
            gridy[j,i] =ytemp
  return [gridx, gridy] 

def poissoncontrole(subgrid,scase):

  gridx=subgrid[0]
  gridy=subgrid[1]

  ny=len(gridx)
  nx=len(gridx[0])


  dx = 1.0/nx
  dy = 1.0/ny
  for j in range(1,ny-1):
    for i in range(1,nx-1):
        idx = i*dx
        jdy = j*dy # rt ny-1
        #changed T by B, for correct orientation
        RT =gridx[0,i] # rt[i,0]
        RT0=gridx[0,0] # rt[0,0]
        RTN=gridx[0,nx-1] #rt[nx-1,0]

        RB =gridx[ny-1,i] # rb[i,0] 
        RB0=gridx[ny-1,0] #rb[0,0]
        RBN=gridx[ny-1,nx-1] #rb[nx-1,0]

        RL= gridx[j,0]    #rl[j,0]
        RR= gridx[j,nx-1] #rr[j,0]

        gridx[j,i] = (1.0-idx)*RL + idx*RR + (1.0 - jdy)*RB + jdy*RT - (1.0-idx)*(1.0-jdy)*RB0 - (1.0 - idx)*jdy*RT0 - idx*(1.0-jdy)*RBN - idx*jdy*RTN

        RT =gridy[0,i] # rt[i,0]
        RT0=gridy[0,0] # rt[0,0]
        RTN=gridy[0,nx-1] #rt[nx-1,0]
        RB =gridy[ny-1,i] # rb[i,0] 
        RB0=gridy[ny-1,0] #rb[0,0]
        RBN=gridy[ny-1,nx-1] #rb[nx-1,0]
        RL= gridy[j,0]    #rl[j,0]
        RR= gridy[j,nx-1] #rr[j,0]

        gridy[j,i] = (1.0-idx)*RL + idx*RR + (1.0 - jdy)*RB + jdy*RT - (1.0-idx)*(1.0-jdy)*RB0 - (1.0 - idx)*jdy*RT0 - idx*(1.0-jdy)*RBN - idx*jdy*RTN
  

  # 3 | 4|..
  # - O -|..
  # 1 | 2|..
  #with control points
  N = 100
  dxi = 1.0/nx
  deta = 1.0/ny

  xi_rf =0.5
  eta_rf=0.5
  if(scase[2]==0): #boxes, scase[2] ~{0*,1,2,3,4}
   xi_rf = 0.001
   if( scase[1]==1 ): #top, scase[1] ~ {0,1}
     eta_rf = 0.115
   else: #bottom
     eta_rf = 1-0.115
   a_rf=0.5 
   b_rf=0.01
   c_rf=150#100
   d_rf=200.2

  else:
   if( scase[2]==1 ): 
    xi_rf = 1-0.01
    eta_rf = 0.115
    a_rf=0.5 
    b_rf=0.01
    c_rf=80
    d_rf=100.2
   if( scase[2]==3 ):    
    xi_rf = 1-0.01
    eta_rf = 0.115
    a_rf=0.5 
    b_rf=0.01
    c_rf=80
    d_rf=100.2
   if( scase[2]==2 ):    
    xi_rf = 1-0.01
    eta_rf = 0.115
    a_rf=0.5 
    b_rf=0.01
    c_rf=80
    d_rf=100.2
   if( scase[2]==4 ):    
    xi_rf = 1-0.01
    eta_rf = 0.115
    a_rf=0.5 
    b_rf=0.01
    c_rf=80
    d_rf=100.2

  for k in range(N):
     for j in range(1,ny-1):
        for i in range(1,nx-1):
            dxdxi = (gridx[j,i+1]-gridx[j,i-1])/(2.0*dxi)
            dydxi = (gridy[j,i+1]-gridy[j,i-1])/(2.0*dxi)
            dxdeta = (gridx[j+1,i]-gridx[j-1,i])/(2.0*deta)
            dydeta = (gridy[j+1,i]-gridy[j-1,i])/(2.0*deta)       
            g11 = dxdxi**2 + dydxi**2
            g22 = dxdeta**2 + dydeta**2
            g12 = dxdxi*dxdeta + dydxi*dydeta
            a = 4.0*(deta**2)*g22
            b = 4.0*dxi*deta*g12
            c = 4.0*(dxi**2)*g11
            g = g11*g22-g12**2

            xixi_rf = i*dxi-xi_rf
            etaeta_rf = j*deta-eta_rf
            
            sPL=a_rf*np.sign(xixi_rf)*np.exp(-c_rf*np.abs(xixi_rf))
            sQL=a_rf*np.sign(etaeta_rf)*np.exp(-c_rf*np.abs(etaeta_rf ))
            sPR=b_rf*np.sign(xixi_rf)*np.exp(-d_rf*( np.sqrt(xixi_rf**2 + etaeta_rf**2))  )
            sQR=b_rf*np.sign(etaeta_rf)*np.exp(-d_rf*( np.sqrt(xixi_rf**2 + etaeta_rf**2))  )

            P = sPL + sPR
            Q = sQL + sQR

            Gx = g*(P*dxdxi+Q*dxdeta)
            Gy = g*(P*dydxi+Q*dydeta)


            gridx[j,i] = (1.0/(2*(a+c)))*(-4.0*Gx*dxi**2*deta**2+a*(gridx[j,i+1]+gridx[j,i-1])+c*(gridx[j+1,i]+gridx[j-1,i])-0.5*(b*(gridx[j+1,i+1]+gridx[j-1,i-1]-gridx[j+1,i-1]-gridx[j-1,i+1])))
            gridy[j,i] = (1.0/(2*(a+c)))*(-4.0*Gy*dxi**2*deta**2+a*(gridy[j,i+1]+gridy[j,i-1])+c*(gridy[j+1,i]+gridy[j-1,i])-0.5*(b*(gridy[j+1,i+1]+gridy[j-1,i-1]-gridy[j+1,i-1]-gridy[j-1,i+1])))
     for j in range(1,ny-1):   #  
       gridy[j,0]= gridy[j,1] 
       gridy[j,nx-1]= gridy[j,nx-2]

  return [gridx, gridy]
