# Aluno(s): Filomen Incahuanaco Quispe
#           Jaqueline Alvarenga Silveira
#           Rosalia Taboada 
import sys
import numpy as np
import grid_library as gl #user function related to grid
import grid_iolibrary as gio #user function related to output vtk or display
from joblib import Parallel, delayed 
import multiprocessing 

if( len(sys.argv) < 5 ): #Validate parameters
  print "Wrong parameters..."
  print "Usage App D r L K [filename.vtk]"
  print "Ex. $python projeto1.py 10 5 80 3"
  exit(0)

D=float(sys.argv[1]) #Get command line parameters
r=float(sys.argv[2])
L=float(sys.argv[3])
K=float(sys.argv[4])

H,xs,ys=gl.cutdomain(D,r,L,K) #divide domain in subgrids
subgrids=[]
cases=[]
for j in range(2): #discretize sub domains
  for i in range(len(xs)-1): 
      scase=0
      scase=1+j*2 if xs[i+1]==(D+r) else (2+j*2 if xs[i]==(D+r) else 0 )
      subgrid=gl.adaptsubgrid(xs[i],xs[i+1],ys[j],ys[j+1],scase,r,H,j)
      subgrids.append(subgrid)
      cases.append([i,j,scase])

num_cores = multiprocessing.cpu_count()  #getting number of cores
#vissubgrids = Parallel(n_jobs=num_cores)(delayed(gl.fillgrid)(sg,cases[i]) for i,sg in enumerate(subgrids)) #Elliptic
vissubgrids = Parallel(n_jobs=num_cores)(delayed(gl.poissoncontrole)(sg,cases[i]) for i,sg in enumerate(subgrids)) #run fill subgrid in multi core

fsubgrids,s1,s2=gl.joinsubgrids(vissubgrids)  #Join by columns

if ( len(sys.argv)==6 ): #if have filename
  gio.twogrids2vtk(fsubgrids,sys.argv[5],s1,s2) #Join by rows and save file
else:
  gio.plotgrid(vissubgrids,L,H,xs,ys) #plot grid

