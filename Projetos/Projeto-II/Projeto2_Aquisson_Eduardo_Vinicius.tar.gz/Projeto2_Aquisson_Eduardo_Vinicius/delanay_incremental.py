# coding: utf-8

import numpy as np
from matplotlib import pyplot as pt
import random as rand

#Pontos para triangulacao
P = np.array([[2,10],[20,20],[1,0], [3,5], [10,20],[10,9],[20,15],[17,5],[13,1]])


#-------------------------------------------------------------------#
#funçoes utilizadas durante o calculo

def cordBar(P,tri,Pref):
    mP = np.array([[1,1,1],[P[tri[0],0],P[tri[1],0],P[tri[2],0]],[P[tri[0],1],P[tri[1],1],P[tri[2],1]]])
    mX = np.array([[1],[Pref[0]],[Pref[1]]])
    cordeBar = np.linalg.solve(mP,mX)
    return np.round(cordeBar,6)


def circunfe(P):
    x = P[:,0]
    y = P[:,1]
    A = x[0]*(y[1]-y[2]) - y[0]*(x[1]-x[2]) + x[1]*y[2] - x[2]*y[1]
    B = (x[0]**2+y[0]**2)*(y[2]-y[1]) + (x[1]**2+y[1]**2)*(y[0]-y[2]) + (x[2]**2+y[2]**2)*(y[1]-y[0])
    C = (x[0]**2+y[0]**2)*(x[1] - x[2])+(x[1]**2+y[1]**2)*(x[2]-x[0]) + (x[2]**2+y[2]**2)*(x[0]-x[1])
    D = (x[0]**2+y[0]**2)*(x[2]*y[1] - x[1]*y[2])+(x[1]**2+y[1]**2)*(x[0]*y[2] - x[2]*y[0]) + (x[2]**2+y[2]**2)*(x[1]*y[0] - x[0]*y[1])  
    xc = -B/(2*A)
    yc = -C/(2*A)
    R = ((B**2 +  C**2 - 4*A*D)/(4*A**2))**0.5
    return [xc,yc,R]

def distan(P,circ):
    return ((P[0] - circ[0])**2 + (P[1] - circ[1])**2)**0.5

def local_delanay(P,Pref):
    Res = circunfe(P)
    if round(distan(Pref,Res)-abs(Res[2]),4) <= 0:
        return False
    else:
        return True

def flip(a,b,c): #a e b são os indices das faces em que vai ocorrer o flip
    #verifica se as faces são adjacentes
    c1 = a*3
    #c4 = b*3-3
    if c[c1][5] != None:
        if c[c[c1][5]][2] == b:
            c1 = c1 
        elif c[c1][6] != None:
            if c[c[c1][6]][2] == b:
                c1 = c[c1][3]               
            elif c[c1][7] != None:        
                if c[c[c1][7]][2] == b:
                    c1 = c[c1][4]                  
    else:
        print(" As faces não são adjacentes ")

    c2 = c[ c1 ][3]
    c3 = c[c1][4]
    c4 = c[c[c1][5]][4]
    c5 = c[c1][5]
    c6 = c[c[c1][5]][3]        

    if c[c6][5] != None: 
        c[c[c6][5]][5] = c1
        c[c[c[c6][5]][4]][6] = c1
        c[c[c[c6][5]][3]][7] = c1
        
    if c[c2][5] != None:
        c[c[c2][5]][5] = c5
        c[c[c[c2][5]][4]][6] = c5
        c[c[c[c2][5]][3]][7] = c5
    
    a = [c1, c[c1][1], c[c1][2], c[c1][3], c[c1][4], c[c4][7], c6,       c[c1][7]]
    b = [c2, c[c2][1], c[c1][2], c[c2][3], c[c2][4], c6,       c[c1][7], c[c4][7]]
    d = [c3, c[c5][1], c[c1][2], c[c3][3], c[c3][4], c[c1][7], c[c4][7], c6 ]
    
    e = [c4, c[c1][1], c[c4][2], c[c4][3], c[c4][4], c[c4][5], c[c1][6], c2 ]
    f = [c5, c[c5][1], c[c5][2], c[c5][3], c[c5][4], c[c1][6], c2,       c[c4][5]]
    g = [c6, c[c6][1], c[c6][2], c[c6][3], c[c6][4], c2,       c[c4][5], c[c1][6]]
    
    c[c1] = a
    c[c2] = b
    c[c3] = d
    c[c4] = e
    c[c5] = f
    c[c6] = g    
    return (c)

def Remove_Triangulo (T ,v):
    for i in range(len(T)-1,-1,-1): # tem um pequeno erro aqui
        for j in range(len(v)):
            if T[i][0]==v[j]:
                T.remove(T[i])
		break
            elif T[i][1]==v[j]:
                T.remove(T[i])
		break
            elif T[i][2]==v[j]:
                T.remove(T[i])
		break
    return (T)

def vtktoconer(cell):
    c =[]
    
    for i in range(len(cell)):
        c.append([ i*3  ,cell[i][0],i, 1 + i*3,2 + i*3 ,None,None,None ])
        c.append([i*3 +1,cell[i][1],i, 2 + i*3, i*3    ,None,None,None ])
        c.append([i*3 +2,cell[i][2],i,  i*3   ,1 + i*3 ,None,None,None ])

        for j in range(len(c)-3):
            if c[j][1]==c[i*3][1]:
                if c[c[j][3]][1]==c[c[i*3][4]][1]:
                    c[i*3][6]  = c[j][4]
                    c[c[i*3][3]][5]= c[j][4]
                    c[c[i*3][4]][7]= c[j][4]
                    c[j][7] = c[i*3][3]
                    c[c[j][3]][6] = c[i*3][3]
                    c[c[j][4]][5] = c[i*3][3]
             
            if c[j][1]==c[i*3 +1][1]:
                if c[c[j][3]][1]==c[c[i*3 +1][4]][1]:
                    c[i*3+1][6]  = c[j][4]
                    c[c[i*3+1][3]][5]= c[j][4]
                    c[c[i*3+1][4]][7]= c[j][4]
                    c[j][7] = c[i*3+1][3]
                    c[c[j][3]][6] = c[i*3+1][3]
                    c[c[j][4]][5] = c[i*3+1][3]
                    
            if c[j][1]==c[i*3 +2][1]:
                if c[c[j][3]][1]==c[c[i*3 +2][4]][1]:
                    c[i*3+2][6]  = c[j][4]
                    c[c[i*3+2][3]][5]= c[j][4]
                    c[c[i*3+2][4]][7]= c[j][4]
                    c[j][7] = c[i*3+2][3]
                    c[c[j][3]][6] = c[i*3+2][3]
                    c[c[j][4]][5] = c[i*3+2][3]
        
    return (c)
#-------------------------------------------------------------------#

n = len(P)

#calculo de 3 pontos que contenham os pontos iniciais
minX = min(P[:,0])*0.9 -0.1 
minY = min(P[:,1])*0.9 - 3 
maxX = max(P[:,0])*1.1 +0.1
maxY = max(P[:,1])*1.1 +0.1

dx = (maxY - minY)/np.tan(np.radians(60))
dy = (maxX - minX)/(2*np.tan(np.radians(30)))

Ptri = np.array([[minX - dx,minY],[maxX+dx,minY],[(maxX - minX)/2,maxY+dy]])
points = np.zeros((len(P[:,0])+len(Ptri[:,0]),2))
points[-3:,:] = Ptri
points[:-3,:] = P

triangu = [[len(points)-3,len(points)-2,len(points)-1]]
cornTable = []
v = triangu[0]
cornTable.append([0, v[0],0,1,2,None,None,None])
cornTable.append([1, v[1],0,2,0,None,None,None])
cornTable.append([2, v[2],0,0,1,None,None,None])

#laço de calculo da triangulacao
for p_index in range(len(points)-3):
#for p_index in range(3):
    for t_index  in range(len(triangu)):
        lambda_bari = cordBar(points,triangu[t_index],points[p_index])
        case = "dentro"

        for i in lambda_bari:
            if i == 0:
                case = "aresta"
            elif i < 0:
                case = "fora"
                break
        if case == "dentro":
            break
    if case=="dentro":
        
        aux = triangu[t_index]
        c_oposto = [cornTable[c][5] for c in [t_index*3,t_index*3+1, t_index*3+2]]
        c_aux = 3*t_index
        c_aux = cornTable[c_aux][3]
        cornTable[c_aux][1] = p_index
        
        #corner do primeiro triangulo
        nt = len(triangu)
        cornTable[c_aux][6:8] = [(nt)*3 + 1,(nt+1)*3 + 1]
        cornTable[3*t_index][5] = (nt+1)*3 + 1
        cornTable[3*t_index][7] = (nt)*3 + 1
        cornTable[3*t_index+2][5:7] = [(nt)*3 + 1,(nt+1)*3 + 1]        
        
        triangu[t_index] = [aux[0], p_index, aux[2]]
        t_aux = [aux[0], aux[1], p_index]
        #corner do segundo triangulo
        triangu.append(t_aux)
        cornTable.append([3*nt,  t_aux[0], nt, 3*nt+1, 3*nt+2, (nt+1)*3+2, (t_index)*3+2, c_oposto[2]])
        cornTable.append([3*nt+1,t_aux[1], nt, 3*nt+2, 3*nt  , (t_index)*3+2, c_oposto[2], (nt+1)*3+2])
        cornTable.append([3*nt+2,t_aux[2], nt, 3*nt  , 3*nt+1, c_oposto[2], (nt+1)*3+2, (t_index)*3+2])

        t_aux = [p_index, aux[1], aux[2]]
        triangu.append(t_aux)
        nt = nt+1
        #corner do terceiro triangulo
        cornTable.append([3*nt,  t_aux[0], nt, 3*nt+1, 3*nt+2, c_oposto[0], (t_index)*3, (nt-1)*3])
        cornTable.append([3*nt+1,t_aux[1], nt, 3*nt+2, 3*nt  , (t_index)*3, (nt-1)*3, c_oposto[0]])
        cornTable.append([3*nt+2,t_aux[2], nt, 3*nt  , 3*nt+1, (nt-1)*3, c_oposto[0], (t_index)*3])
        
        #corner dos triangulos de fora
        if c_oposto[2]!=None:
            cornTable[c_oposto[2]][5] = (nt-1)*3+2
            cornTable[cornTable[c_oposto[2]][3]][7] = (nt-1)*3+2 
            cornTable[cornTable[c_oposto[2]][4]][6] = (nt-1)*3+2
        
        if c_oposto[0]!=None:
            cornTable[c_oposto[0]][5] = (nt)*3
            cornTable[cornTable[c_oposto[0]][3]][7] = (nt)*3
            cornTable[cornTable[c_oposto[0]][4]][6] = (nt)*3

        nF = 1
        nTeste = 0
        while nF>0:
            nTeste += 1
            nF = 0
            for c in range(len(cornTable)):
                if cornTable[c][5] != None:
                    f = cornTable[c][2]
                    P_aux = np.zeros((3,2))
                    P_aux[0,:] = points[triangu[f][0]]
                    P_aux[1,:] = points[triangu[f][1]]
                    P_aux[2,:] = points[triangu[f][2]]
                    P_ref = points[cornTable[cornTable[c][5]][1]]
                    fo = cornTable[cornTable[c][5]][2]
                    if local_delanay(P_aux,P_ref) == False:
                        nF += 1 
                        flip(f,fo,cornTable)
                        triangu = [[cornTable[t*3][1],cornTable[t*3+1][1],cornTable[t*3+2][1]] for t in range(len(triangu))]
                    if nTeste > 1000:
                        break
#pt.figure(1)
#pt.plot(P[:,0],P[:,1],"o")
#triangu = [[cornTable[t*3][1],cornTable[t*3+1][1],cornTable[t*3+2][1]] for t in range(len(triangu))]
#pt.triplot(points[:,0],points[:,1],triangu)
#pt.show()

triangu = Remove_Triangulo(triangu,[n,n+1,n+2])
cornTable = vtktoconer(triangu)
pt.figure(2)
pt.plot(P[:,0],P[:,1],"o")
triangu = [[cornTable[t*3][1],cornTable[t*3+1][1],cornTable[t*3+2][1]] for t in range(len(triangu))]
pt.triplot(points[:,0],points[:,1],triangu)
for i in range(len(triangu)):
	pt.text((points[triangu[i][0]][0]+points[triangu[i][1]][0]+points[triangu[i][2]][0])/3,(points[triangu[i][0]][1]+points[triangu[i][1]][1]+points[triangu[i][2]][1])/3, str(i), fontsize=7)
for i in range(len(points)):
	pt.text(points[i][0]+0.2,points[i][1],str(i))    
pt.show()
