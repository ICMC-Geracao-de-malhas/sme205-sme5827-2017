function[]=confere
	
	global trigs;
	global points;
	
	trigs = [];
	points = Points()
	
	iniciaTrig();
	

	
	%lbda=0.5;
	%pp=[-10,-5]+lbda*[10,38];
	%pp=[-33,-33]+lbda*[23,28];
	%pp2=[2,3]+lbda*[6,8];
	
	%points=[points;pp;pp2];
	hold on;
	
	%trigs=delaunay(points(:,1),points(:,2));
	%trimesh(trigs,points(:,1),points(:,2),"m");
	
	trigs = delaunay(points(4:size(points,1),1),points(4:size(points,1),2))
	trimesh(trigs,points(4:size(points,1),1),points(4:size(points,1),2));
	
end

function[points ]=Points()
	
	%points=[-1 1 ;2 3; 5 -5; 8 11; -10 -5];
	%xx=rand(7,1);
	%yy=rand(7,1);
	%points=100*[xx yy];
	points = load('points.txt');
	M = 3*max(max(abs(points(:,1))),max(abs(points(:,2))));
	
	p_2 = [-M -M];
	p_1 = [M 1];
	p_0 = [1 M];
	
	points = [p_2; p_1; p_0; points];
end

function[ ] = iniciaTrig()
	global trigs;
	trigs = [trigs;[1 2 3]];
	
end
