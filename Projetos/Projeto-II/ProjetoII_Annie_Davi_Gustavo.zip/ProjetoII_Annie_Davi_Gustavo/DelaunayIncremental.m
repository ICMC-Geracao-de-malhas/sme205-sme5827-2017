function[]=teste3()
	
	global trigs;
	global points;
	
	trigs=[];
	
	points=Points();
	
	iniciaTrig();
	
    inserePonto();
	drawTrigs('b',1);
	trigs=removeEspPoints();
	figure(2);
	drawTrigs('r',4);
end


function[points ]=Points()
	
	%points=[-1 1 ;2 3; 5 -5; 8 11; -10 -5];
	%xx=rand(7,1);
	%yy=rand(7,1);
	%points=100*[xx yy];
	points=load('points.txt');
	
	
	M=3*max(max(abs(points(:,1))),max(abs(points(:,2))));
	
	p_2=[-M -M];
	p_1=[M 0];
	p_0=[0 M];
	
	points=[p_2;p_1;p_0;points];
end


function[newTrigs]=removeEspPoints()
	
	global trigs
	newTrigs=[];
	nTrigs=size(trigs,1);
	iNewTrigs=1;
	for i=1:nTrigs
		m=min(trigs(i,:));
		if((m==1)||(m==2)||(m==3))
				continue;
		end
		newTrigs(iNewTrigs,:)=trigs(i,:);
		iNewTrigs=iNewTrigs+1;
	end

end

function[ ]=iniciaTrig()
	global trigs;
	trigs = [trigs;[1 2 3]];
	
end

function[ ]=inserePonto()
	
	global trigs;
	global points;
	
	nPoints=size(points,1);
	
	for zpoint = 4:nPoints
		
		loc = -1;
		ztrig = 0;
		pnew = points(zpoint,:);
		
		while(loc == -1)
            ztrig = ztrig + 1;
            [loc,ed] = intTrig(pnew,ztrig);
        end
		
		ii = trigs(ztrig,1);
		jj = trigs(ztrig,2);
		kk = trigs(ztrig,3);
        
		if(loc == 1)
            trigs(ztrig,:)=[];
            insereTrigs(ii,jj,zpoint);
			insereTrigs(jj,kk,zpoint);
			insereTrigs(kk,ii,zpoint);
			
			ntrigs = size(trigs,1);
			
			trocaArestas(ntrigs-2);
			trocaArestas(ntrigs-1);
			trocaArestas(ntrigs);
        else
			
			adjTri = buscaEdge(ed,ztrig);
			
			jj_ = trigs(adjTri,1);
			ii_ = trigs(adjTri,2);
			ll = trigs(adjTri,3);
			
			trigs(ztrig,:) = [];
            trigs(adjTri,:) = [];
			
			insereTrigs(kk,ii,zpoint);
			insereTrigs(jj,kk,zpoint);
			
			insereTrigs(ll,jj_,zpoint);
			insereTrigs(ii_,ll,zpoint);
			
			ntrigs = size(trigs,1);
			
			trocaArestas(ntrigs-3);
			trocaArestas(ntrigs-2);
			trocaArestas(ntrigs-1);
			trocaArestas(ntrigs);
		end
    end
end

function[ ] = trocaArestas(itrig)
	global trigs;
    
	tri_new = trigs(itrig,:);
	adjTri = buscaEdge([tri_new(1),tri_new(2)],itrig);
	
	if(adjTri == -1)
		return;
	end
	
	adjTri_new = trigs(adjTri,:);
	
	if(inCircle(tri_new(1),adjTri_new(3),adjTri_new(1),tri_new(3))==1)
		%        a  b  p        a  c  p
		% tri = [ii jj kk] --> [ii ll kk]
		
		%           b  a  c      c  b  p
		% adjTri = [jj ii ll]-->[ll jj kk]
	
		%              ii       ll        kk
		tri_new=[tri_new(1),adjTri_new(3),tri_new(3)];
	
		%               ll          jj              kk
		adjTri_new=[adjTri_new(3),adjTri_new(1),tri_new(3)];
		
		trigs(itrig,:)=tri_new;
		trigs(adjTri,:)=adjTri_new;
		
		trocaArestas(itrig)
		trocaArestas(adjTri)
	
	end
end

function[inc ]=inCircle(ii,ll,jj,kk)
	
	global points;
	inc=0;
	m1=[points(ii,:);points(ll,:);points(jj,:);points(kk,:)];
	m2=[sq(points(ii,:));sq(points(ll,:));sq(points(jj,:));sq(points(kk,:))];
	m3=ones(4,1);
	m=[m1 m2 m3];
	
	if(det(m)>=0)
		inc=1;
	end
	
end
function[square]=sq(vet)
	
	square=vet(1)^2+vet(2)^2;
	
end


function[ ]=insereTrigs(ii,jj,kk)
	
	global trigs;
	trigs=[trigs;[ii jj kk]];
	
end

function[loc,ed ]=intTrig(p,ztrig)
	
	global trigs;
	global points
	
	loc=-1;
	ed=-1;
	
	ii=trigs(ztrig,1);
	jj=trigs(ztrig,2);
	kk=trigs(ztrig,3);
	
	vi=points(ii,:);
	vj=points(jj,:);
	vk=points(kk,:);
	
	aij=det([p-vi;vj-vi]);
	ajk=det([p-vj;vk-vj]);
	aki=det([p-vk;vi-vk]);
	
	if((aij<0)&&(ajk<0)&&(aki<0))
		loc=1;
		return;
	end
	
	if(aij==0)
		res=dot(vi-p,vj-p);
		if(res<0)
			ed=[ii jj];
			loc=0;
			%[ii jj kk]
			return;
		end
	end
	
	if(ajk==0)
		res=dot(vj-p,vk-p);
		if(res<0)
			ed=[jj kk];
			%[ii jj kk]
			trigs(ztrig,:)=[jj kk ii];
			loc=0;
			return;
		end
	end
	
	if(aki==0)
		res=dot(vk-p,vi-p);
		if(res<0)
			ed=[kk ii];
			%[ii jj kk]
			trigs(ztrig,:)=[kk ii jj];
			loc=0;
			return;
		end
	end

end
function[adjTri] = buscaEdge(edg,itrig)
	global trigs;
	
	nTrigs=size(trigs,1);
	ed=[edg(2) edg(1)];
	
	adjTri=-1;
	
	for ztrigs=1:nTrigs
		
		if(ztrigs==itrig)
			continue;
		end
		tri=trigs(ztrigs,:);
		
		if(tri(1:2) == ed)
			
			%[j i l]
			adjTri=ztrigs;
			return;
			
		elseif(tri(2:3)==ed)
			
			%[l j i]          j        i       l
			trigs(ztrigs,:)=[tri(2),tri(3),tri(1)];
			adjTri=ztrigs;
			return;
		
		elseif([tri(3) tri(1)]==ed)
			
			%[i l j]           j       i      l
			trigs(ztrigs,:)=[tri(3),tri(1),tri(2)];
			adjTri=ztrigs;
			return ;
		
		end
		
	end
	
end


function[ ]=drawTrigs(cor,inicio)
	
	global trigs;
	global points;
	nTrigs=size(trigs,1);
	np=size(points,1);
	
	hold off;
	for i=inicio:np
		plot(points(i,1),points(i,2));
		hold on;
		text(points(i,1),points(i,2),num2str(i),'fontsize',14);
	end
	
	
	for i=1:nTrigs
		
		p1=points(trigs(i,1),:);
		p2=points(trigs(i,2),:);
		p3=points(trigs(i,3),:);
		
		l1=[p1;p2];
		l2=[p2;p3];
		l3=[p3;p1];
		
		plot(l1(:,1),l1(:,2),cor);
		
		plot(l2(:,1),l2(:,2),cor);
		
		plot(l3(:,1),l3(:,2),cor);
		
		
		
	end
	
end
