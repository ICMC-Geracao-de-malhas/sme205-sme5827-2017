# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 14:45:45 2017

@author: vinicius
"""
import numpy as np

def eliptico(gx,gy, tol = 0.0001 , nmax = 1000 , w=1 , Ax = [0] ,   Bx = [0], Cx = [10], Dx = [5],
    Ay = [0],
    By = [0],
    Cy = [0],
    Dy = [0],
    eta = [0.0401], xi = [0.5001]):
        
    nx,ny = gx.shape
    dx = 1.0/nx
    dy = 1.0/ny
    #
    for j in range(1,ny-1):
        jdy = j*dy
        for i in range(1,nx-1):
            idx = i*dx
            gx[i,j] = (1.0-idx)*gx[0,j] + idx*gx[-1,j] + (1.0 - jdy)*gx[i,0] + jdy*gx[i,-1] - (1.0-idx)*(1.0-jdy)*gx[0,0] - (1.0 - idx)*jdy*gx[0,-1] - idx*(1.0-jdy)*gx[-1,0] - idx*jdy*gx[-1,-1]
            gy[i,j] = (1.0-idx)*gy[0,j] + idx*gy[-1,j] + (1.0 - jdy)*gy[i,0] + jdy*gy[i,-1] - (1.0-idx)*(1.0-jdy)*gy[0,0] - (1.0 - idx)*jdy*gy[0,-1] - idx*(1.0-jdy)*gy[-1,0] - idx*jdy*gy[-1,-1]
 
    """Elipitico"""
    gx2 = np.empty_like(gx)
    gy2 = np.empty_like(gx)
    gx2[:,:]=gx[:,:]
    gy2[:,:]=gy[:,:]
    erro = 1
    cont=0
    

    
    while (erro > tol) and (cont < nmax):
        erro = 0
        for j in range(1,ny-1):
            for i in range(1,nx-1):
                dxdxi = (gx[i+1,j]-gx[i-1,j])/(2.0*dx)
                dydxi = (gy[i+1,j]-gy[i-1,j])/(2.0*dx)
                dxdeta = (gx[i,j+1]-gx[i,j-1])/(2.0*dy)
                dydeta = (gy[i,j+1]-gy[i,j-1])/(2.0*dy)       
                g11 = dxdxi**2 + dydxi**2
                g22 = dxdeta**2 + dydeta**2
                g12 = dxdxi*dxdeta + dydxi*dydeta
                a = g22/(dx**2)
                b = 2*g22/(dx**2) + 2*g11/(dy**2)
                d = (g11/(dy**2) )*(gx[i,j+1] + gx[i,j-1]) - 2*g12*(gx[i+1,j+1]+gx[i-1,j-1]-gx[i-1,j+1]-gx[i+1,j-1])/(4*dx*dy)
                e = (g11/(dy**2) )*(gy[i,j+1] + gy[i,j-1]) - 2*g12*(gy[i+1,j+1]+gy[i-1,j-1]-gy[i-1,j+1]-gy[i+1,j-1])/(4*dx*dy)
    
                g = g11*g22-g12**2
                p = 0
                q = 0
                for k in range(len(Ax)):
                    p += - g*(Ax[k]*(i*dx- xi[k])/abs(i*dx-xi[k])*np.e**(-Cx[k]*abs(i*dx-xi[k])) + Bx[k]*(i*dx- xi[k])/abs(i*dx-xi[k])*np.e**(-Dx[k]*((i*dx-xi[k])**2 + (j*dy -eta[k])**2 )**0.5))
                    q += - g*(Ay[k]*(j*dy - eta[k])/abs(j*dy - eta[k])*np.e**(-Cy[k]*abs(j*dy-eta[k])) + By[k]*(j*dy - eta[k])/abs(j*dy - eta[k])*np.e**(-Dy[k]*((i*dx-xi[k])**2 + (j*dy -eta[k])**2 )**0.5))
                
                gx2[i,j]= (a*(gx[i+1,j] + gx[i-1,j]) + d +p*dxdxi + q*dxdeta )/b
                gy2[i,j]= (a*(gy[i+1,j] + gy[i-1,j]) + e +p*dydxi + q*dydeta )/b
                if abs(gx2[i,j] - gx[i,j])>erro:
                    erro = abs(gx2[i,j] - gx[i,j])
                if abs(gy2[i,j] - gy[i,j])>erro:
                    erro = abs(gy2[i,j] - gy[i,j])
    
        gx[:,:]=w*gx2[:,:] +(1-w)*gx[:,:]
        gy[:,:]=w*gy2[:,:] +(1-w)*gy[:,:]
        print(cont, erro)
        cont+=1
    return (gx,gy)
