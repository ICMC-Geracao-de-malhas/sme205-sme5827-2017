# -*- coding: utf-8 -*-
import numpy as np

r = 1.0 
l = 40.0
k = 5
D = 10.0
h = 12.0

neta = 70 # em "y" #deve ser par
nxi = 60 # em "x"

n = l/k

nome = [0]*k
for i in range(k):
    nome[i]='bloco_'+str(i+1)
print("Nome dos arquivos contento os bordos:")
print(nome)

#Cria os bordos do cilindro
p1 = np.array([0 , -h/2])
p2 = np.array([ D-n,-h/2])
p3 = np.array([ D-n ,h/2])
p4 = np.array([0 ,h/2])

a = np.zeros([int((D-n)/(n/nxi)),2])
b = np.zeros([neta,2])
c = np.zeros([int((D-n)/(n/nxi)),2])
d = np.zeros([neta,2])



a[:,0] = np.linspace(p1[0],p2[0],int((D-n)/(n/nxi))) # b
b[:,0] = np.linspace(p2[0],p3[0],neta) # r
c[:,0] = np.linspace(p4[0],p3[0],int((D-n)/(n/nxi))) # t
d[:,0] = np.linspace(p1[0],p4[0],neta) # l


a[:,1] = np.linspace(p1[1],p2[1],int((D-n)/(n/nxi)))
b[:,1] = np.linspace(p2[1],p3[1],neta)
c[:,1] = np.linspace(p4[1],p3[1],int((D-n)/(n/nxi)))
d[:,1] = np.linspace(p1[1],p4[1],neta)


#plt.plot([x[0] for x in a],[x[1] for x in a],"b")
#plt.plot([x[0] for x in b],[x[1] for x in b],"g")
#plt.plot([x[0] for x in c],[x[1] for x in c],"r")
#plt.plot([x[0] for x in d],[x[1] for x in d],"black")
#plt.axis([-5, 45, -7, 7])
#plt.show()

#Salva os bordos
f = open(nome[0],'wt')

#top
f.write(str(int((D-n)/(n/nxi))))
f.write('\n')
for i in range(int((D-n)/(n/nxi))):
	f.write("{:.7f}".format(c[i][0]))
	f.write(' ')
	f.write("{:.7f}".format(c[i][1]))
	f.write('\n')

#b
f.write(str(int((D-n)/(n/nxi))))
f.write('\n')
for i in range(int((D-n)/(n/nxi))):
	f.write("{:.7f}".format(a[i][0]))
	f.write(' ')
	f.write("{:.7f}".format(a[i][1]))
	f.write('\n')

#l
f.write(str(neta))
f.write('\n')
for i in range(neta):
	f.write("{:.7f}".format(d[i][0]))
	f.write(' ')
	f.write("{:.7f}".format(d[i][1]))
	f.write('\n')

#r
f.write(str(neta))
f.write('\n')
for i in range(neta):
	f.write("{:.7f}".format(b[i][0]))
	f.write(' ')
	f.write("{:.7f}".format(b[i][1]))
	f.write('\n')

f.close()

##########

p1 = np.array([D-n, -h/2])
p2 = np.array([D,-h/2])
p3 = np.array([D,h/2])
p4 = np.array([D-n,h/2])

a = np.zeros([2*nxi + neta,2])
b = np.zeros([int(neta/2),2])
c = np.zeros([2*nxi + neta,2])
d = np.zeros([int(neta/2),2])

for i in range(neta + nxi*2):
    if i<nxi:
        c[i] = i*(p4 - p3)/(nxi) + p3
    elif i<(neta+nxi):
        c[i] = (i-nxi)*(p1-p4)/(neta-1) + p4
    else:
        c[i] = (i-neta-nxi + 1)*(p2-p1)/(nxi) + p1

comp = h/2 - r
A = comp/(comp**2)
for i in range(int(neta/2)):
	d[i]=[D, r + A*(i*comp/(int(neta/2)-1))**2] 
	b[i]=[D, -r - A*(i*comp/(int(neta/2)-1))**2] 

for i in range(len(a)):
    a[i] = [-r*np.sin(i*np.pi/(2*nxi + neta -1)) +D ,  r*np.cos(i*np.pi/(2*nxi + neta -1))] 

#plt.plot([x[0] for x in a],[x[1] for x in a],"b")
#plt.plot([x[0] for x in b],[x[1] for x in b],"g")
#plt.plot([x[0] for x in c],[x[1] for x in c],"r")
#plt.plot([x[0] for x in d],[x[1] for x in d],"-")
#plt.show()

f = open(nome[1],'wt')

#top
f.write(str(2*nxi + neta))
f.write('\n')
for i in range(2*nxi + neta):
	f.write("{:.7f}".format(c[i][0]))
	f.write(' ')
	f.write("{:.7f}".format(c[i][1]))
	f.write('\n')

#b
f.write(str(2*nxi + neta))
f.write('\n')
for i in range(2*nxi + neta):
	f.write("{:.7f}".format(a[i][0]))
	f.write(' ')
	f.write("{:.7f}".format(a[i][1]))
	f.write('\n')

#l
f.write(str(int(neta/2)))
f.write('\n')
for i in range(int(neta/2)):
	f.write("{:.7f}".format(d[i][0]))
	f.write(' ')
	f.write("{:.7f}".format(d[i][1]))
	f.write('\n')

#r
f.write(str(int(neta/2)))
f.write('\n')
for i in range(int(neta/2)):
	f.write("{:.7f}".format(b[i][0]))
	f.write(' ')
	f.write("{:.7f}".format(b[i][1]))
	f.write('\n')

f.close()

p1 = np.array([D+n, -h/2])
p2 = np.array([D,-h/2])
p3 = np.array([D,h/2])
p4 = np.array([D+n,h/2])

a = np.zeros([2*nxi + neta,2])
b = np.zeros([int(neta/2),2])
c = np.zeros([2*nxi + neta,2])
d = np.zeros([int(neta/2),2])

B = 0.3
comp = (h)/2
A = (comp -B*h/2)/(comp**3)
for i in range(neta + nxi*2):
    if i<nxi:
        c[i] = i*(p4 - p3)/(nxi) + p3
    elif i<(neta+nxi):
        c[i] =[p1[0], -A*((i-nxi)*h/(neta-1) -h/2)**3  -B*((i-nxi)*h/(neta-1)) +B*h/2]
    else:
        c[i] = (i-neta-nxi + 1)*(p2-p1)/(nxi) + p1


comp = h/2 - r
A = comp/(comp**2)
for i in range(int(neta/2)):
	b[i]=[D, -r - A*(i*comp/(int(neta/2)-1))**2] 
	d[i]=[D, r + A*(i*comp/(int(neta/2)-1))**2] 


for i in range(len(a)):
    a[i] = [r*np.sin(i*np.pi/(2*nxi + neta -1)) +D ,  r*np.cos(i*np.pi/(2*nxi + neta -1))] 

#plt.plot([x[0] for x in a],[x[1] for x in a],"b")
#plt.plot([x[0] for x in b],[x[1] for x in b],"g")
#plt.plot([x[0] for x in c],[x[1] for x in c],"r")
#plt.plot([x[0] for x in d],[x[1] for x in d],"black")
#plt.show()

f = open(nome[2],'wt')

#top
f.write(str(2*nxi + neta))
f.write('\n')
for i in range(2*nxi + neta):
	f.write("{:.7f}".format(c[i][0]))
	f.write(' ')
	f.write("{:.7f}".format(c[i][1]))
	f.write('\n')

#b
f.write(str(2*nxi + neta))
f.write('\n')
for i in range(2*nxi + neta):
	f.write("{:.7f}".format(a[i][0]))
	f.write(' ')
	f.write("{:.7f}".format(a[i][1]))
	f.write('\n')

#l
f.write(str(int(neta/2)))
f.write('\n')
for i in range(int(neta/2)):
	f.write("{:.7f}".format(d[i][0]))
	f.write(' ')
	f.write("{:.7f}".format(d[i][1]))
	f.write('\n')

#r
f.write(str(int(neta/2)))
f.write('\n')
for i in range(int(neta/2)):
	f.write("{:.7f}".format(b[i][0]))
	f.write(' ')
	f.write("{:.7f}".format(b[i][1]))
	f.write('\n')
f.close()

#Demais bordos
N = (l-(D+n))/(k-3)
for i in range(k-3):
    p1 = np.array([D+n + i*N, -h/2])
    p2 = np.array([D+n+N+ i*N,-h/2])
    p3 = np.array([D+n+N+ i*N,h/2])
    p4 = np.array([D+n+ i*N,h/2])

    a = np.zeros([nxi,2])
    b = np.zeros([neta,2])
    c = np.zeros([nxi,2])
    d = np.zeros([neta,2])


    a[:,0] = np.linspace(p1[0],p2[0],nxi) # b
    c[:,0] = np.linspace(p4[0],p3[0],nxi) # t
    
    a[:,1] = np.linspace(p1[1],p2[1],nxi)
    c[:,1] = np.linspace(p4[1],p3[1],nxi)

    B = 0.3
    comp = (h)/2
    A = (comp -B*h/2)/(comp**3)
    for j in range (len(d)):
        d[j] =[p1[0], A*(j*h/(neta-1) -h/2)**3 +B*(j*h/(neta-1)) -B*h/2]
        b[j] =[p2[0], A*(j*h/(neta-1) -h/2)**3 +B*(j*h/(neta-1)) -B*h/2]

    #plt.plot([x[0] for x in a],[x[1] for x in a],"b")
    #plt.plot([x[0] for x in b],[x[1] for x in b],"g")
    #plt.plot([x[0] for x in c],[x[1] for x in c],"r")
    #plt.plot([x[0] for x in d],[x[1] for x in d],"black")
    #plt.show()

    #Salva os bordos
    f = open(nome[i+3],'wt')
    
    #top
    f.write(str(nxi))
    f.write('\n')
    for i in range(nxi):
        f.write("{:.7f}".format(c[i][0]))
        f.write(' ')
        f.write("{:.7f}".format(c[i][1]))
        f.write('\n')
    
    #b
    f.write(str(nxi))
    f.write('\n')
    for i in range(nxi):
        f.write("{:.7f}".format(a[i][0]))
        f.write(' ')
        f.write("{:.7f}".format(a[i][1]))
        f.write('\n')
    
    #l
    f.write(str(neta))
    f.write('\n')
    for i in range(neta):
        f.write("{:.7f}".format(d[i][0]))
        f.write(' ')
        f.write("{:.7f}".format(d[i][1]))
        f.write('\n')
    
    #r
    f.write(str(neta))
    f.write('\n')
    for i in range(neta):#-1,-1,-1):
        f.write("{:.7f}".format(b[i][0]))
        f.write(' ')
        f.write("{:.7f}".format(b[i][1]))
        f.write('\n')
    
    f.close()

