# -*- coding: utf-8 -*-

"""leitura do arquivo"""

import sys
import numpy as np
import matplotlib.pyplot as plt
import grid as grid
import Eliptico as eli

k = 5
P = ['bloco_%i' % (i) for i in range(1,k+1)] 

def leitura(nome):
    f = open(nome,'rt')

    nx = int(f.readline())
    rt = np.zeros((nx,2))
    for i in range(nx):
        l=f.readline()
        rt[i,0]=l.split(' ')[0]
        rt[i,1]=l.split(' ')[1]
    
    n2 = int(f.readline())
    
    if (n2 != nx):
        print("top and botton discretization should match")
        sys.exit(0)
    
    rb = np.zeros((nx,2))
    for i in range(nx):
        l=f.readline()
        rb[i,0]=l.split(' ')[0]
        rb[i,1]=l.split(' ')[1]
    
    ny = int(f.readline())
    rl = np.zeros((ny,2))
    for i in range(ny):
        l=f.readline()
        rl[i,0]=l.split(' ')[0]
        rl[i,1]=l.split(' ')[1]
    
    n2 = int(f.readline())
    
    if (n2 != ny):
        print("left and right discretization should match")
        sys.exit(0)
    
    rr = np.zeros((ny,2))
    for i in range(ny):
        l=f.readline()
        rr[i,0]=l.split(' ')[0]
        rr[i,1]=l.split(' ')[1]
    
    f.close()
    
    gx = np.zeros((nx,ny))
    gy = np.zeros((nx,ny))
    
    gx[:,0] = rb[:,0]
    gx[:,-1] = rt[:,0]
    gx[0,:] = rl[:,0]
    gx[-1,:] = rr[:,0]
     
    gy[:,0]  = rb[:,1]
    gy[:,-1] = rt[:,1]
    gy[0,:]  = rl[:,1]
    gy[-1,:] = rr[:,1]
    
    return(gx,gy)

p = []
cell=[]

for i in range(len(P)):
    gx,gy = leitura(P[i])
    if i == 1:
        gx,gy = eli.eliptico(gx,gy,nmax=1000, tol = 0.001, eta=[0.00001] ,Ay=[12], Cy=[10])
    elif i ==2:
        gx,gy = eli.eliptico(gx,gy,nmax=10000,Ax = [0.17],Cx = [25],eta=[0.00001], xi=[0.499], tol = 0.001 ,Ay=[12],Cy=[10] )
    else:
        gx,gy = eli.eliptico(gx,gy,nmax=0)#transfinita
    m = np.shape(gx)[1]
    if i ==0:
        for j in range(np.shape(gx)[0]):
            for k in range(np.shape(gx)[1]):
                p.append([gx[j,k],gy[j,k]])
                if j != np.shape(gx)[0]-1 and k != np.shape(gx)[1]-1:
                    cell.append([j*m+k , j*m+k+1,(j+1)*m+k+1,(j+1)*m+k])

    #Procura pontos em comum
    if i!= 0:
        a =[]
        n = len(p)
        for j in range(np.shape(gx)[0]):
            for k in range(len(p)):
                if [gx[j,0],gy[j,0]]==p[k]:
                    a.append([p[k],k])
                if [gx[j,-1],gy[j,-1]]==p[k]:
                    a.append([p[k],k])
        for j in range(1,np.shape(gx)[1]-1):
            for k in range(len(p)):
                if [gx[0,j],gy[0,j]]==p[k]:
                    a.append([p[k],k])
                if [gx[-1,j],gy[-1,j]]==p[k]:
                    a.append([p[k],k])
        v = []
        c = 0
        for j in range(np.shape(gx)[0]):
            for k in range(np.shape(gx)[1]):
                b = False
                for l in range(len(a)): 
                    if [gx[j,k],gy[j,k]] == a[l][0]:
                        v.append(a[l][1])
                        b = True
                        c+=1
                        break
                if b == False:
                    p.append([gx[j,k],gy[j,k]])
                    v.append(j*m+k + n -c)
        
        for j in range(np.shape(gx)[0]-1):
            for k in range(np.shape(gx)[1]-1):             
                cell.append([v[j*m+k], v[j*m+k+1],v[(j+1)*m+k+1] ,v[(j+1)*m+k]])
        
    for i in range(np.shape(gx)[0]):
       plt.plot(gx[i,:],gy[i,:],color='gray')
    for i in range(np.shape(gx)[1]):
       plt.plot(gx[:,i],gy[:,i],color='gray')

p = np.array(p)
cell = np.array(cell)
grid.vtk(p,cell,"malha.vtk")

