import os
import numpy
import matplotlib.pyplot as plt
import math
from util import Util
from hull import TGenerator

class Vertex:
	def __init__(self, x, y, z):
		self.x = x
		self.y = y
		self.z = z

	def __str__(self):
		msg = str(self.x) + "," + str(self.y)
		return msg

class Corner:
	def __init__(self):
		self.face = -1
		self.vertex = -1
		self.next = None
		self.previous = None
		self.opost = None
		self.right = None
		self.left = None
		self.index = -1

	def __str__(self):
		msg = str(self.index) + "," + str(self.vertex) + "," + str(self.face) + ","
		msg += str(self.next.index) + "," + str(self.previous.index) + ","
		if self.opost is not None:
			msg += str(self.opost.index) + ","
		else:
			msg += "None,"
		if self.right is not None:
			msg += str(self.right.index) + ","
		else:
			msg += "None,"
		if self.left is not None:
			msg += str(self.left.index)
		else:
			msg += "None"
		return msg

class CornerTable:
	def __init__(self, init=True, filename=None):
		self.corner_list = []
		self.vertex_list = []
		self.data = None
		if init == True:
			data = None
			if filename is not None:
				data = Util.parseTriangularVTK(filename)
				if data[0] is not None:
					print "Parsed ok..."
			else:
				print "Randomizing points..."
				data = TGenerator.generate(8)
			self.data = data
			self.build_from(self.data)
			self.dump()
		else:
			print "Not initing"

	def get_table(self):
		return self.corner_list

	def get_vertex(self):
		return self.vertex_list

	def get_equals(self, list0, list1, curr_face):
		result = []
		for i in range(0, len(list0)):
			for j in range(0, len(list1)):
				ctx0 = list0[i]
				ctx1 = list1[j]
				if ctx0 == ctx1:
					result.append([i, j])
		if len(result) > 0:
			for i in result:
				if list0[i[0]] != curr_face:
					return i
		return [None, None]

	def plot_table(self):
		idx = 0
		facex = []
		facey = []
		facez = []
		while idx < len(self.corner_list):
			corner0 = self.corner_list[idx+0]
			corner1 = self.corner_list[idx+1]
			corner2 = self.corner_list[idx+2]
			facex = corner0.vertex
			facey = corner1.vertex
			facez = corner2.vertex
			v0 = self.vertex_list[facex]
			v1 = self.vertex_list[facey]
			v2 = self.vertex_list[facez]
			Util.plotTriangle(v0, v1, v2, 'r')
			idx += 3
		# Util.plotTriangularData(self.data[0], self.data[1], facex, facey, facez)

	def update(self):	
		self.build_from(self.data)

	def get_corners_from_vertex(self, vertex):
		resp = []
		for corner in self.corner_list:
			if corner.vertex == vertex:
				resp.append(corner)
		return resp

	def rebuild_opost(self):
		curr_corner = 0
		face_count = len(self.data[3])
		for i in range(0, face_count):
			idx0 = self.data[3][i]
			idx1 = self.data[4][i]
			idx2 = self.data[5][i]
			# corners0 = self.get_corners_from_vertex(idx0)
			# corners1 = self.get_corners_from_vertex(idx1)
			# corners2 = self.get_corners_from_vertex(idx2)

			# for idx0
			# cornersA = self.vertex_list[idx1].corners
			# cornersB = self.vertex_list[idx2].corners
			cornersA = self.get_corners_from_vertex(idx1)
			cornersB = self.get_corners_from_vertex(idx2)
			facesA = []
			facesB = []
			for corner in cornersA:
				facesA.append(corner.face)
			for corner in cornersB:
				facesB.append(corner.face)

			equals = self.get_equals(facesA, facesB, i)
			if equals[0] is not None:
				selected0 = self.corner_list[cornersA[equals[0]].index]
				selected1 = self.corner_list[cornersB[equals[1]].index]
				set0 = set([selected0.next.index, selected0.previous.index])
				set1 = set([selected1.next.index, selected1.previous.index])
				setsub0 = set([selected0.index])
				setsub1 = set([selected1.index])
				resp = set0.union(set1) - setsub0 - setsub1
				corner_curr = self.corner_list[curr_corner]
				self.corner_list[curr_corner].opost = self.corner_list[list(resp)[0]]
				self.corner_list[corner_curr.next.index].right = self.corner_list[list(resp)[0]]
				self.corner_list[corner_curr.previous.index].left = self.corner_list[list(resp)[0]]

			curr_corner += 1

			# for idx1
			# cornersA = self.vertex_list[idx0].corners
			# cornersB = self.vertex_list[idx2].corners
			cornersA = self.get_corners_from_vertex(idx0)
			cornersB = self.get_corners_from_vertex(idx2)
			facesA = []
			facesB = []
			for corner in cornersA:
				facesA.append(corner.face)
			for corner in cornersB:
				facesB.append(corner.face)

			equals = self.get_equals(facesA, facesB, i)
			if equals[0] is not None:
				selected0 = self.corner_list[cornersA[equals[0]].index]
				selected1 = self.corner_list[cornersB[equals[1]].index]
				set0 = set([selected0.next.index, selected0.previous.index])
				set1 = set([selected1.next.index, selected1.previous.index])
				setsub0 = set([selected0.index])
				setsub1 = set([selected1.index])
				resp = set0.union(set1) - setsub0 - setsub1
				corner_curr = self.corner_list[curr_corner]
				self.corner_list[curr_corner].opost = self.corner_list[list(resp)[0]]
				self.corner_list[corner_curr.next.index].right = self.corner_list[list(resp)[0]]
				self.corner_list[corner_curr.previous.index].left = self.corner_list[list(resp)[0]]
				
			curr_corner += 1

			# for idx2
			# cornersA = self.vertex_list[idx0].corners
			# cornersB = self.vertex_list[idx1].corners
			cornersA = self.get_corners_from_vertex(idx0)
			cornersB = self.get_corners_from_vertex(idx1)
			facesA = []
			facesB = []
			for corner in cornersA:
				facesA.append(corner.face)
			for corner in cornersB:
				facesB.append(corner.face)

			equals = self.get_equals(facesA, facesB, i)
			if equals[0] is not None:
				selected0 = self.corner_list[cornersA[equals[0]].index]
				selected1 = self.corner_list[cornersB[equals[1]].index]
				set0 = set([selected0.next.index, selected0.previous.index])
				set1 = set([selected1.next.index, selected1.previous.index])
				setsub0 = set([selected0.index])
				setsub1 = set([selected1.index])
				resp = set0.union(set1) - setsub0 - setsub1
				corner_curr = self.corner_list[curr_corner]
				self.corner_list[curr_corner].opost = self.corner_list[list(resp)[0]]
				self.corner_list[corner_curr.next.index].right = self.corner_list[list(resp)[0]]
				self.corner_list[corner_curr.previous.index].left = self.corner_list[list(resp)[0]]
				
			curr_corner += 1

	# data = [x, y, z, ix, iy, iz]
	def build_from(self, data):
		curr_corner = 0
		face_count = len(self.data[3])
		self.corner_list = [None]*3*len(self.data[4])
		self.vertex_list = [None]*3*len(self.data[0])
		for i in range(0, len(data[0])):
			self.vertex_list[i] = Vertex(self.data[0][i], self.data[1][i], self.data[2][i])

		for i in range(0, face_count):
			idx0 = self.data[3][i]
			idx1 = self.data[4][i]
			idx2 = self.data[5][i]
			v0 = Vertex(self.data[0][idx0], self.data[1][idx0], self.data[2][idx0])
			v1 = Vertex(self.data[0][idx1], self.data[1][idx1], self.data[2][idx1])
			v2 = Vertex(self.data[0][idx2], self.data[1][idx2], self.data[2][idx2])

			corner0 = Corner()
			corner0.face = i
			corner0.vertex = idx0
			corner0.index = curr_corner
			curr_corner += 1

			corner1 = Corner()
			corner1.face = i
			corner1.vertex = idx1
			corner1.index = curr_corner
			curr_corner += 1

			corner2 = Corner()
			corner2.face = i
			corner2.vertex = idx2
			corner2.index = curr_corner
			curr_corner += 1			

			corner0.next = corner1
			corner0.previous = corner2
			corner1.next = corner2
			corner1.previous = corner0
			corner2.next = corner0
			corner2.previous = corner1

			self.corner_list[corner0.index] = corner0
			self.corner_list[corner1.index] = corner1
			self.corner_list[corner2.index] = corner2

		self.rebuild_opost()

	def dump(self):
		self.write_table("dump.txt")

	def load_dump(self):
		self.read_table("dump.txt")

	def dump_data(self, filename):
		with open(filename, 'w') as fd:
			size = len(self.data[0])
			for i in range(0, size):
				msg = str(self.data[0][i]) + " "
				msg += str(self.data[1][i]) + " "
				msg += str(self.data[2][i]) + '\n'
				fd.write(msg)

	def debug(self):
		for corner in self.corner_list:
			opost = corner.opost
			if opost is None: continue
			self.plot_table()
			vertex0 = self.vertex_list[corner.vertex]
			vertex1 = self.vertex_list[corner.next.vertex]
			vertex2 = self.vertex_list[corner.previous.vertex]
			Util.plotTriangle(vertex0, vertex1, vertex2, 'b')
			Util.plotPoint(self.vertex_list[corner.vertex], 'g')
			Util.plotPoint(self.vertex_list[opost.vertex], 'k')
			if corner.right is not None:
				Util.plotPoint(self.vertex_list[corner.right.vertex], 'c')
			plt.show()

	def read_table(self, filename):
		with open(filename, "r") as fd:
			content = fd.read()
			data = content.split('\n')
			links = []
			stage = 0
			self.vertex_list = []
			self.corner_list = []
			X = []
			Y = []
			Z = []
			facex = []
			facey = []
			facez = []
			for line in data:
				el = line.split(',')
				if len(el) == 2:
					self.vertex_list.append(Vertex(float(el[0]), \
												   float(el[1]), \
												   0.0))
					X.append(float(el[0]))
					Y.append(float(el[1]))
					Z.append(0.0)
				elif len(el) == 8:
					corner = Corner()
					corner.index = int(el[0])
					corner.vertex = int(el[1])
					corner.face = int(el[2])
					links.append(el[3:])
					self.corner_list.append(corner)

				elif len(el) == 1 and el[0] == 'None':
					continue
				else:
					if stage == 0:
						print "Got ", el[0], " vertices"
						stage = 1
					elif stage == 1:
						print "Got ", el[0], " corners"
						stage = 2
					else:
						print "Unknown"
			print "Finished loading, constructing table..."
			i = 0
			for corner in self.corner_list:
				corner.next = None
				corner.previous = None
				corner.left = None
				corner.right = None
				corner.opost = None
				next_idx = links[i][0]
				previous_idx = links[i][1]
				opost_idx = links[i][2]
				right_idx = links[i][3]
				left_idx = links[i][4]
				if next_idx != "None": corner.next = self.corner_list[int(next_idx)]
				if previous_idx != "None": corner.previous = self.corner_list[int(previous_idx)]
				if opost_idx != "None": corner.opost = self.corner_list[int(opost_idx)]
				if right_idx != "None": corner.right = self.corner_list[int(right_idx)]
				if left_idx != "None": corner.left = self.corner_list[int(left_idx)]
				i += 1

			i = 0
			while i < len(self.corner_list):
				corner0 = self.corner_list[i+0]
				corner1 = self.corner_list[i+1]
				corner2 = self.corner_list[i+2]
				facex.append(corner0.index)
				facey.append(corner1.index)
				facez.append(corner2.index)
				i += 3
			self.data = [X, Y, Z, facex, facey, facez]
			print "Finished table"



	def write_table(self, filename):
		with open(filename, "w") as fd:
			fd.write(str(len(self.vertex_list)) + "\n")
			for vertex in self.vertex_list:
				msg = str(vertex)
				msg += "\n"
				fd.write(msg)
			fd.write(str(len(self.corner_list)) + "\n")
			for corner in self.corner_list:
				msg = str(corner)
				msg += "\n"
				fd.write(msg)
		print "finished, output is in ", filename