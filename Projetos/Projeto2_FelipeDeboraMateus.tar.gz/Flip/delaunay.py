from corner import CornerTable
from util import Util
from copy import deepcopy

corner_table = CornerTable(init=True)
corner_table.dump_data("test_out_0.txt")

anyFlip = True
debug_iteration = 1
iteration = 0

while anyFlip:
	idx = 0
	anyFlip = False
	table = corner_table.get_table()
	vertex = corner_table.get_vertex()
	# for every entry in our table
	while idx < len(table):
		# get a face [corners]
		corners = [table[idx+0], table[idx+1], table[idx+2]]
		# for each corner in this face test if we need to Flip
		v0 = vertex[corners[0].vertex]
		v1 = vertex[corners[1].vertex]
		v2 = vertex[corners[2].vertex]
		i0 = (v0.x)**2 + (v0.y)**2
		i1 = (v1.x)**2 + (v1.y)**2
		i2 = (v2.x)**2 + (v2.y)**2
		for corner in corners:
			# grab opost so we can get the opost triangle
			opost = corner.opost
			# if we do not have opost, this is a boundary triangle
			if opost is None: 
				continue
			vo = vertex[opost.vertex]
			io = (vo.x)**2 + (vo.y)**2
			matrix = [i0, v0.x, v0.y, 1, i1, v1.x, v1.y, 1, \
					  i2, v2.x, v2.y, 1, io, vo.x, vo.y, 1]
			det = Util.computeDet4x4(matrix)
			if det > 0:
				corner_table.plot_table()
				Util.plotTriangle(v0, v1, v2, 'g')
				Util.plotPoint(vertex[opost.vertex], 'k')
				Util.plotPoint(vertex[corner.vertex], 'b')
				Util.plotTriCircle(v0, v1, v2, 'g')
				Util.display()
				
				face0 = corner.face
				face1 = opost.face

				v0_f0 = corner.previous.vertex
				v1_f0 = corner.vertex
				v2_f0 = opost.vertex

				v0_f1 = opost.previous.vertex
				v1_f1 = opost.vertex
				v2_f1 = corner.vertex

				corner_table.data[3][face0] = v0_f0
				corner_table.data[4][face0] = v1_f0
				corner_table.data[5][face0] = v2_f0

				corner_table.data[3][face1] = v0_f1
				corner_table.data[4][face1] = v1_f1
				corner_table.data[5][face1] = v2_f1

				corner_table.update()
				anyFlip = True
				break
		if anyFlip:
			break
		idx += 3

print "Finished generation..."
table = corner_table.get_table()
vertex = corner_table.get_vertex()
idx = 0
while idx < len(table):
	# get a face [corners]
	corners = [table[idx+0], table[idx+1], table[idx+2]]
	# for each corner in this face test if we need to Flip
	v0 = vertex[corners[0].vertex]
	v1 = vertex[corners[1].vertex]
	v2 = vertex[corners[2].vertex]
	corner_table.plot_table()
	Util.plotTriangle(v0, v1, v2, 'g')
	Util.plotTriCircle(v0, v1, v2, 'b')
	Util.display()
	idx += 3

corner_table.plot_table()
Util.display()
