import os
import sys
import random
import copy
import matplotlib.pyplot as plt
from util import Triangle
from util import Util

class TGenerator:
	@staticmethod
	def plot_all_points(points, col):
		for p in points:
			plt.plot(p[0], p[1], col)

	@staticmethod
	def plot(hull, points):
		for p in points:
			plt.plot(p[0], p[1], 'bo')

		for i in range(0, len(hull)):
			col = 'r'
			pt0 = hull[i]
			t = i + 1
			if t == len(hull):
				t = 0
			pt1 = hull[t]
			if pt1[1] > pt0[1]:
				col = 'r'
			linex = [pt0[0], pt1[0]]
			liney = [pt0[1], pt1[1]]
			plt.plot(linex, liney, col)
		plt.show()

	@staticmethod
	def pplot_triangle(v0, v1, v2, col):
		linesx = [v0[0], v1[0]]
		linesy = [v0[1], v1[1]]
		plt.plot(linesx, linesy, col)
		linesx = [v1[0], v2[0]]
		linesy = [v1[1], v2[1]]
		plt.plot(linesx, linesy, col)
		linesx = [v0[0], v2[0]]
		linesy = [v0[1], v2[1]]
		plt.plot(linesx, linesy, col)

	@staticmethod
	def plot_triangle(triangle):
		TGenerator.pplot_triangle(triangle.p0, triangle.p1, triangle.p2, 'r')

	@staticmethod
	def pop_min(points):
		minv = 9999
		idx = -1
		point = None
		for i in range(0, len(points)):
			p = points[i]
			if minv > p[0]:
				point = p
				idx = i
				minv = p[0]

		del points[idx]
		return point

	@staticmethod
	def bubble_sort(points):
		for i in range(0, len(points)):
			changed = False
			for j in range(i, len(points)):
				if points[i][0] > points[j][0]:
					aux = points[i]
					points[i] = points[j]
					points[j] = aux
					changed = True
			if not changed:
				break
		return points

	@staticmethod
	def turn(p, q, r):
		return cmp((q[0] - p[0])*(r[1] - p[1]) - (r[0] - p[0])*(q[1] - p[1]), 0)

	@staticmethod
	def _dist(p, q):
		dx, dy = q[0] - p[0], q[1] - p[1]
		return dx*dx + dy*dy

	@staticmethod
	def _next_hull_pt(points, p):
		TURN_LEFT, TURN_RIGHT, TURN_NONE = (1, -1, 0)
		q = p
		for r in points:
			t = TGenerator.turn(p, q, r)
			if t == TURN_RIGHT or t == TURN_NONE and TGenerator._dist(p, r) > TGenerator._dist(p, q):
				q = r
		return q

	@staticmethod
	def convex_hull(points):
		hull = [min(points)]
		for p in hull:
			q = TGenerator._next_hull_pt(points, p)
			if q != hull[0]:
				hull.append(q)
		return hull

	@staticmethod
	def generate(n_points):
		radius = 200
		rangeX = (0, 2500)
		rangeY = (0, 2500)
		qty = n_points  # or however many points you want
		TURN_LEFT, TURN_RIGHT, TURN_NONE = (1, -1, 0)

		# Generate a set of all points within 200 of the origin, to be used as offsets later
		# There's probably a more efficient way to do this.
		deltas = set()
		for x in range(-radius, radius+1):
		    for y in range(-radius, radius+1):
		        if x*x + y*y <= radius*radius:
		            deltas.add((x,y))

		randPoints = []
		excluded = set()
		i = 0
		while i<qty:
		    x = random.randrange(*rangeX)
		    y = random.randrange(*rangeY)
		    if (x,y) in excluded: continue
		    randPoints.append((x,y))
		    i += 1
		    excluded.update((x+dx, y+dy) for (dx,dy) in deltas)

		pointList = []
		for point in randPoints:
			pointList.append(list(point))

		sorted_points = TGenerator.bubble_sort(pointList)
		copied_points = copy.copy(sorted_points)

		pt0 = TGenerator.pop_min(sorted_points)
		pt1 = TGenerator.pop_min(sorted_points)
		pt2 = TGenerator.pop_min(sorted_points)
		points = [pt0, pt1, pt2]

		t = TGenerator.turn(pt0, pt1, pt2)
		first_tri = None
		if t == TURN_RIGHT or t == TURN_NONE and TGenerator._dist(pt0, pt2) > TGenerator._dist(pt0, pt1):
			first_tri = Triangle(pt0, pt2, pt1)
		else:
			first_tri = Triangle(pt0, pt1, pt2)
		triangles = [first_tri]
		# plot_triangle(pt0, pt1, pt2, 'r')
		for i in range(0, len(sorted_points)):
			pt = sorted_points[i]
			hull = TGenerator.convex_hull(points)
			points.append(pt)
			for j in range(0, len(hull)):
				pt0 = hull[j]
				t = j+1
				if t == len(hull):
					t = 0
				pt1 = hull[t]
				t = TGenerator.turn(pt0, pt1, pt)
				if t == TURN_RIGHT or t == TURN_NONE and TGenerator._dist(pt0, pt) > TGenerator._dist(pt0, pt1):
					triangles.append(Triangle(pt0, pt, pt1))

		TGenerator.plot_all_points(copied_points, 'bo')
		return Util.trianglesToDataStructure(triangles)