import os, sys
import numpy
import matplotlib.pyplot as plt
import math

class Triangle:
    def __init__(self, p0, p1, p2):
        self.p0 = p0
        self.p1 = p1
        self.p2 = p2

    def getCircumcircle(self):
        # translate to origin, calculation is easier
        ax = self.p0.x
        ay = self.p0.y
        bx = self.p1.x - ax
        by = self.p1.y - ay
        cx = self.p2.x - ax
        cy = self.p2.y - ay

        d = 2*(bx*cy - by*cx)
        if d != 0:
            ux = (1.0/d)*(cy*(bx**2 + by**2) - by*(cx**2 + cy**2))
            uy = (1.0/d)*(bx*(cx**2 + cy**2) - cx*(bx**2 + by**2))
            r = math.sqrt(ux**2 + uy**2)
            uux = ux + ax
            uuy = uy + ay
            return [uux, uuy, r]
        else:
            return [0, 0, 0]


class Util:

    @staticmethod
    def computeDet3x3(e):
        A = e[0]*(e[4]*e[8] - e[5]*e[7])
        B = e[1]*(e[3]*e[8] - e[5]*e[6])
        C = e[2]*(e[3]*e[7] - e[4]*e[6])
        return A - B + C

    @staticmethod
    def computeDet4x4(e):
        a0 = [e[4], e[6], e[7], e[8], e[10], e[11], e[12], e[14], e[15]]
        A = -(e[1]*Util.computeDet3x3(a0))

        b0 = [e[0], e[2], e[3], e[8], e[10], e[11], e[12], e[14], e[15]]
        B = (e[5]*Util.computeDet3x3(b0))
        
        c0 = [e[0], e[2], e[3], e[4], e[6], e[7], e[12], e[14], e[15]]
        C = -(e[9]*Util.computeDet3x3(c0))
        
        d0 = [e[0], e[2], e[3], e[4], e[6], e[7], e[8], e[10], e[11]]
        D = (e[13]*Util.computeDet3x3(d0))
        return A+B+C+D


    @staticmethod
    def parseTriangularVTK(filename):
        print "Opening file ", filename
        content = []
        try:
            with open(filename, "r") as fd:
                content = fd.readlines()
            content = [x.strip() for x in content]
            pointParse = False
            pointsFinished = False
            faceParse = False
            faceFinished = False
            data_x = []
            data_y = []
            data_z = []
            face_x = []
            face_y = []
            face_z = []
            for line in content:
                splitted = line.split(' ')
                if len(splitted) == 0:
                    continue
                else:
                    if splitted[0] == "POINTS":
                        pointParse = True
                        faceParse = False
                        continue
                    elif splitted[0] == "CELLS":
                        faceParse = True
                        pointParse = False
                        continue
                    else:
                        if pointParse:
                            if len(splitted) == 3:
                                data_x.append(float(splitted[0]))
                                data_y.append(float(splitted[1]))
                                data_z.append(float(splitted[2]))
                        elif faceParse:
                            if len(splitted) == 4 and splitted[0] == "3":
                                face_x.append(int(splitted[1]))
                                face_y.append(int(splitted[2]))
                                face_z.append(int(splitted[3]))
                            else:
                                print "Unknown line: ", line
            return [data_x, data_y, data_z, face_x, face_y, face_z]
        except:
            return [None]


    @staticmethod
    def mapTo(x, A, B, a, b):
        return ((x - A)*(b - a)/(B - A) + a)

    @staticmethod
    def plotPoints(X, Y):
        count = len(X)
        for i in range(0, count):
            plt.plot(X[i], Y[i], 'bo')
        plt.show()

    @staticmethod
    def display():
        plt.show()

    @staticmethod
    def plotPoint(v0, col):
        r = col + 'o'
        plt.plot(v0.x, v0.y, r)

    @staticmethod
    def plotTriCircle(v0, v1, v2, col):
        triangle = Triangle(v0, v1, v2)
        circle_data = triangle.getCircumcircle()
        center = (circle_data[0], circle_data[1])
        circle = plt.Circle(center, circle_data[2], color=col, fill=False)
        plt.gcf().gca().add_artist(circle)

    @staticmethod
    def plotTriangle(v0, v1, v2, col):
        linesx = [v0.x, v1.x]
        linesy = [v0.y, v1.y]
        plt.plot(linesx, linesy, col)
        linesx = [v1.x, v2.x]
        linesy = [v1.y, v2.y]
        plt.plot(linesx, linesy, col)
        linesx = [v0.x, v2.x]
        linesy = [v0.y, v2.y]
        plt.plot(linesx, linesy, col)

    @staticmethod
    def plotTriangularData(X, Y, faces_x, faces_y, faces_z):
        triangles = len(faces_x)
        beg = 0
        end = triangles
        for i in range(beg, end):
            ix = faces_x[i]
            iy = faces_y[i]
            iz = faces_z[i]
            v0 = [X[ix], Y[ix]]
            v1 = [X[iy], Y[iy]]
            v2 = [X[iz], Y[iz]]
            linex = [v0[0], v1[0]]
            liney = [v0[1], v1[1]]
            plt.plot(linex, liney, 'r')
            linex = [v1[0], v2[0]]
            liney = [v1[1], v2[1]]
            plt.plot(linex, liney, 'r')
            linex = [v0[0], v2[0]]
            liney = [v0[1], v2[1]]
            plt.plot(linex, liney, 'r')
    

    @staticmethod
    def trianglesToDataStructure(triangles):
        pointList = []
        pointIdx = []
        X = []
        Y = []
        Z = []
        facex = []
        facey = []
        facez = []
        idxx = 0
        idxy = 0
        idxz = 0
        idx_atual = 0
        for triangle in triangles:
            p0 = triangle.p0
            p1 = triangle.p1
            p2 = triangle.p2
            if not (p0 in pointList):
                X.append(p0[0])
                Y.append(p0[1])
                Z.append(0.0)
                pointList.append(p0)
                pointIdx.append(idx_atual)
                idxx = idx_atual
                idx_atual += 1
            else:
                idxx = pointList.index(p0)

            if not (p1 in pointList):
                pointList.append(p1)
                X.append(p1[0])
                Y.append(p1[1])
                Z.append(0.0)
                pointIdx.append(idx_atual)
                idxy = idx_atual
                idx_atual += 1 
            else:
                idxy = pointList.index(p1)

            if not (p2 in pointList):
                pointList.append(p2)
                X.append(p2[0])
                Y.append(p2[1])
                Z.append(0.0)
                pointIdx.append(idx_atual)
                idxz = idx_atual
                idx_atual += 1
            else:
                idxz = pointList.index(p2)

            facex.append(idxx)
            facey.append(idxy)
            facez.append(idxz)
        return [X, Y, Z, facex, facey, facez]
    
    @staticmethod
    # Construct vtk file from matrixes X and Y
    # they are supposed to be constructed in a col-major first manner
    def dataToVTK(X, Y, filename):
        print "Writing VTK file: ", filename
        try:
            with open(filename, "w") as fd:
                fd.write("# vtk DataFile Version 3.0\n")
                fd.write("Auto generated file\n")
                fd.write("ASCII\n")
                fd.write("DATASET POLYDATA\n")
                pointCount = len(X) * len(Y)
                cellCount = (len(X) - 1) * (len(Y) - 1)
                dataCount = cellCount * 5
                fd.write("POINTS " + str(pointCount) + " float\n")
                for j in range(0, len(Y)):
                    for i in range(0, len(X)):
                        fd.write(str(X[i, j]) +  " " + str(Y[i, j]) + " 0.0\n")
                fd.write("POLYGONS " + str(cellCount) + " " + str(dataCount) + "\n")
                position = 0
                line = 0
                for i in range(0, cellCount):
                    limit = (line + 1)*len(X) - 1
                    if position == limit:
                        line += 1
                        position = line * len(X)
                    nextline = position + len(X)
                    fd.write("4 " + str(position) + " " + str(position+1) \
                             + " " + str(nextline+1) + " " + str(nextline) + "\n")
                    position += 1
                fd.close()
                print "Finished generating VTK file"
        except:
            print "Error writing VTK file"

    @staticmethod
    def parseConfFile(filename):
        try:
            with open(filename, "r") as fd:
                content = fd.read()
                data = content.split('\n')
                pos = 0
                X = []
                Y = []
                reverse = False
                pos = 0
                if data[0] == "blocked":
                    reverse = True
                    pos = 1
                for i in range(pos, len(data)):
                    floats = data[pos].split()
                    if len(floats) == 2:
                        x = float(floats[0])
                        y = float(floats[1])
                        X.append(x)
                        Y.append(y)
                    elif reverse:
                        vals = data[pos:]
                        X = list(reversed(X))
                        Y = list(reversed(Y))
                        data = vals
                        pos = 0
                    pos += 1
                fd.close()
                if reverse:
                    return [list(reversed(X)),\
                            list(reversed(Y))]
                return [X, Y]
        except:
            print "Error parsing ", filename
            return None
