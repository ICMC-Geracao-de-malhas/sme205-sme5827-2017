# -*- coding: utf-8 -*-
import os, sys
import numpy
import matplotlib.pyplot as plt
import math

#                       .-'`'-.
#              ,-'`'.   '._     \     ______
#            /    .'  ___ `-._  |    \ .-'`
#           |   .' ,-' __ `'/.`.'  ___\\
#   ______  \ .' \',-' 12 '-.  '.  `-._ \
#   '`-. /   ` / / 11    7 1 `.  `.    '.\
#      //___  . '10     /    2 \  ;
#     / _.-'  | |      O      3|  |  ______
#    /.'      | |9      \      '  '  '`-. /
#      ______ '  \ 8     \   4/  /      //___
#      \ .-'`  '. `'.7  6  5.'  '      / _.-'
#    ___\\       `. _ `'''` _.'\\-.   /.'
#    `-._ \       .//`''--''   (   )
#        '.\     (   )          '-`
#                 `-'
# trim, trim trim: Well not the cleannest code in production
#                  but this was more difficult than I pictured
#                  I'm not quite sure I undertand the problem
#                  and not sure I implemented correctly but here
#                  goes nothing

# Author: Felipe Orlandi de Oliveira
# nº USP: 7546930

CONF_FILE = "AIRFOIL.conf"

# parses the file containing Airfoil data
def parseFile(filename):
    print "Parsing ", filename
    try:
        with open(filename, "r") as fd:
            content = fd.read()
            splitted = content.split('\n')
            data = splitted[0:]
            X = []
            Y = []
            for i in range(0, len(data)):
                floats = data[i].split()
                if(len(floats) == 2):
                    x = float(floats[0])
                    y = float(floats[1])
                    X.append(x)
                    Y.append(y)
            fd.close()
            return [X, Y]
    except:
        return None

# Apply bilinear grid generation on the domain
# defined by gridx and gridy, based on points
# A, B, C, D
def gen_bilinear(gridx, gridy, A, B, C, D):
    X = numpy.zeros((len(gridx), len(gridy))) # X matrix
    Y = numpy.zeros((len(gridx), len(gridy))) # Y matrix
    # for every cell
    for i in range(0, len(gridx)):
        for j in range(0, len(gridy)):
            # basic computation
            x_ = gridx[i]
            y_ = gridy[j]
            a = 1.0 - x_
            b = 1.0 - y_
            x = a*b*A[0] + a*y_*B[0] + b*x_*C[0] + x_*y_*D[0]
            y = a*b*A[1] + a*y_*B[1] + b*x_*C[1] + x_*y_*D[1]
            X[i, j] = x
            Y[i, j] = y
    return [X, Y]

# insert the current matrixes X and Y
# to the plot image
def plotGrid(sizex, sizey, X, Y):
    for i in range(0, sizex):
        plt.plot(X[i,:], Y[i, :], 'b')

    for i in range(0, sizey):
        plt.plot(X[:, i], Y[:, i], 'b')

# TODO: Use me to determinate the actual size
# of the Airfoil
def distance(point0, point1):
    return math.sqrt((point0[0]-point1[0])**2 + \
                     (point0[1]-point1[1]**2))

# clears a file, to make sure we do not append to a
# pre-existent file
def removeFile(filename):
    try:
        with open(filename, "w") as fd:
            fd.close()
    except:
        pass

# write the point 'point' to the file given
# by 'filename'
def writePoint(point, filename):
    try:
        with open(filename, "a+") as fd:
            msg = str(point[0]) + " " + str(point[1]) + "\n"
            fd.write(msg)
            fd.close()
    except:
        print "Error writing to file, this is not going to work"

def printUsage():
    print "Usage:"
    print "python generate.py <output-file>"
    quit()

if __name__ == '__main__':
    args = sys.argv
    if len(args) != 2:
        printUsage()

    filename = sys.argv[1]
    data = parseFile(CONF_FILE)
    if data is None:
        print "Could not parse file ", CONF_FILE
        print "Please make sure you have an ",CONF_FILE, " file"
    else:
        print "Parsed successfully"
        removeFile(filename)    
        X, Y = data
        p = 6
        s = 1
        arch = 1 # hard-coded length of the airfoil
        size = len(X)
        dk = (arch + 2*s)/(2.0*p) # horizontal spacing
        ds = 0.5/p # vertical spacing

        print "Generating grid..."
        # mount the first arc
        ptB = [X[0]+s, Y[0]]
        ptA = [X[0], Y[0]]
        ptC = [X[1], Y[1]]
        ptD = [X[0]+s, Y[0]+ds]
        gridx = numpy.linspace(0.0, 1.0, p)
        gridy = numpy.linspace(0.0, 1.0, p)
        Xg, Yg = gen_bilinear(gridx, gridy, ptA, ptB, ptC, ptD)
        plotGrid(len(gridx), len(gridy), Xg, Yg)
        counter = 1
        writePoint(ptA, filename)
        writePoint(ptB, filename)
        # generates half-right-up part of the grid
        print "Generating right-up part"
        for i in range(0, p):
            ptA = ptC
            ptB = ptD
            ptC = [X[counter], Y[counter]]
            ptD = [ptD[0], ptD[1]+ds]
            Xg, Yg = gen_bilinear(gridx, gridy, ptA, ptB, ptC, ptD)
            plotGrid(len(gridx), len(gridy), Xg, Yg)
            counter += 1
            writePoint(ptD, filename)

        # estimates the amount of points we are going to discard
        # in order to make this 'kinda' of regular
        lin = int((len(X)/2.0 - counter - 1)/(2.0*p))
        print "Generating top part"
        # generates the top part of the grid
        for i in range(0, 2*p):
            ptA = ptC
            ptB = ptD
            ptC = [X[counter], Y[counter]]
            ptD = [ptD[0]-dk, ptD[1]]
            Xg, Yg = gen_bilinear(gridx, gridy, ptA, ptB, ptC, ptD)
            plotGrid(len(gridx), len(gridy), Xg, Yg)
            counter += lin
            writePoint(ptD, filename)

        # generates the right side of the grid
        print "Generating right part"
        for i in range(0, 2*p):
            ptA = ptC
            ptB = ptD
            ptC = [X[counter], Y[counter]]
            ptD = [ptD[0], ptD[1]-ds]
            Xg, Yg = gen_bilinear(gridx, gridy, ptA, ptB, ptC, ptD)
            plotGrid(len(gridx), len(gridy), Xg, Yg)
            counter += 1
            writePoint(ptD, filename)

        # generates the bottom side of the grid
        print "Generating bottom part"
        for i in range(0, 2*p):
            ptA = ptC
            ptB = ptD
            ptC = [X[counter], Y[counter]]
            ptD = [ptD[0]+dk, ptD[1]]
            Xg, Yg = gen_bilinear(gridx, gridy, ptA, ptB, ptC, ptD)
            plotGrid(len(gridx), len(gridy), Xg, Yg)
            counter += lin
            writePoint(ptD, filename)

        # generates the half-left-down side of the grid
        print "Generating right-down part"
        for i in range(0, p):
            ptA = ptC
            ptB = ptD
            ptC = [X[counter], Y[counter]]
            ptD = [ptD[0], ptD[1]+ds]
            Xg, Yg = gen_bilinear(gridx, gridy, ptA, ptB, ptC, ptD)
            plotGrid(len(gridx), len(gridy), Xg, Yg)
            counter += 1
            writePoint(ptD, filename)

        writePoint(ptC, filename)
        print "Finished!"
        plt.show() # displays the grid
