# -*- coding: utf-8 -*-
import os
import numpy, sys
import matplotlib.pyplot as plt
import math

#                       .-'`'-.
#              ,-'`'.   '._     \     ______
#            /    .'  ___ `-._  |    \ .-'`
#           |   .' ,-' __ `'/.`.'  ___\\
#   ______  \ .' \',-' 12 '-.  '.  `-._ \
#   '`-. /   ` / / 11    7 1 `.  `.    '.\
#      //___  . '10     /    2 \  ;
#     / _.-'  | |      O      3|  |  ______
#    /.'      | |9      \      '  '  '`-. /
#      ______ '  \ 8     \   4/  /      //___
#      \ .-'`  '. `'.7  6  5.'  '      / _.-'
#    ___\\       `. _ `'''` _.'\\-.   /.'
#    `-._ \       .//`''--''   (   )
#        '.\     (   )          '-`
#                 `-'
# trim, trim trim: Oh well this was difficult, but i think it works!


CONF_FILE = "AIRFOIL.conf"
# VTK_OUTPUT = "../VtkOutput/airfoil_eliptic.vtk"
VTK_OUTPUT = "airfoil_eliptic.vtk"
# Construct vtk file from matrixes X and Y
# they are supposed to be constructed in a col-major first manner
def dataToVTK(X, Y, filename):
    print "Writing VTK file: ", filename
    try:
        with open(filename, "w") as fd:
            fd.write("# vtk DataFile Version 3.0\n")
            fd.write("Auto generated file\n")
            fd.write("ASCII\n")
            fd.write("DATASET POLYDATA\n")
            pointCount = len(X) * len(Y)
            cellCount = (len(X) - 1) * (len(Y) - 1)
            dataCount = cellCount * 5
            fd.write("POINTS " + str(pointCount) + " float\n")
            for j in range(0, len(Y)):
                for i in range(0, len(X)):
                    fd.write(str(X[i, j]) +  " " + str(Y[i, j]) + " 0.0\n")
            fd.write("POLYGONS " + str(cellCount) + " " + str(dataCount) + "\n")
            position = 0
            line = 0
            for i in range(0, cellCount):
                limit = (line + 1)*len(X) - 1
                if position == limit:
                    line += 1
                    position = line * len(X)
                nextline = position + len(X)
                fd.write("4 " + str(position) + " " + str(position+1) \
                         + " " + str(nextline+1) + " " + str(nextline) + "\n")
                position += 1
            fd.close()
            print "Finished generating VTK file"
    except:
        print "Error writing VTK file"

# this so does not look right
def writeOutputDomain(filename):
    global size, airfoilX, airfoilY
    print "Writing output domain as 8 point bounding box"
    print "The points are in lexigrophaic order"
    try:
        with open(filename, "w") as fd:
            point = [airfoilX[0], airfoilY[0]]
            fd.write(str(point[0]) + " " + str(point[1]) + "\n") # point A

            point = [airfoilX[0]+size, airfoilY[0]]
            fd.write(str(point[0]) + " " + str(point[1]) + "\n") # point B

            point = [size+airfoilX[0], airfoilY[0]+1.0]
            fd.write(str(point[0]) + " " + str(point[1]) + "\n") # point H

            point = [size+airfoilX[0] - 2.0, airfoilY[0] + 1.0]
            fd.write(str(point[0]) + " " + str(point[1]) + "\n") # point G

            point = [size+airfoilX[0]-2.0, airfoilY[0]-1.0]
            fd.write(str(point[0]) + " " + str(point[1]) + "\n") # point F

            point = [size+airfoilX[0], airfoilY[0]-1.0]
            fd.write(str(point[0]) + " " + str(point[1]) + "\n") # point E

            point = [size+airfoilX[len(airfoilX)-1], airfoilY[len(airfoilY)-1]]
            fd.write(str(point[0]) + " " + str(point[1]) + "\n") # point D

            point = [airfoilX[len(airfoilX)-1], airfoilY[len(airfoilY)-1]]
            fd.write(str(point[0]) + " " + str(point[1]) + "\n") # point C

            fd.close()
            print "Finished writing domain to ", filename
    except:
        print "Unnable to write output file: ", filename

#define parametric curves
def r1(s): #left
    global airfoilX, airfoilY, size
    return [airfoilX[0]+(1.0-s)*size, airfoilY[0]]

def r2(s): #bottom
    global size, airfoilX, airfoilY
    t = mapTo(s, 0.0, 1.0, 0.0, 8.0)
    if t < 1:
        point = [size+airfoilX[0], airfoilY[0]+t]
        return point
    elif t < 3:
        point = [size+airfoilX[0] - (t-1.0), airfoilY[0] + 1.0]
        return point
    elif t < 5:
        point = [size+airfoilX[0]-2.0, airfoilY[0]+1.0-(t-3.0)]
        return point
    elif t < 7:
        point = [size+airfoilX[0]-2.0+(t-5.0), airfoilY[0]-1.0]
        return point
    else:
        point = [size+airfoilX[len(airfoilX)-1],\
                 airfoilY[len(airfoilY)-1]-1.0+(t-7.0)]
        return point

def r3(s): #right
    global airfoilX, airfoilY, size
    point = [(1.0-s)*size+airfoilX[0],\
            airfoilY[len(airfoilY)-1]]
    return point

def r4(s): #top
    global airfoilX, airfoilY
    i = int(s*(len(airfoilX)-1.0))
    return [airfoilX[i], airfoilY[i]]
# insert the current matrixes X and Y
# to the plot image
def plotGrid(sizex, sizey, X, Y):
    for i in range(0, sizex):
        plt.plot(X[i,:], Y[i, :], 'b')

    for i in range(0, sizey):
        plt.plot(X[:, i], Y[:, i], 'b')

def mapTo(x, A, B, a, b):
    return ((x - A)*(b - a)/(B - A) + a)

# parses the file containing Airfoil data
def parseFile(filename):
    print "Parsing ", filename
    try:
        with open(filename, "r") as fd:
            content = fd.read()
            splitted = content.split('\n')
            data = splitted[0:]
            X = []
            Y = []
            for i in range(0, len(data)):
                floats = data[i].split()
                if(len(floats) == 2):
                    x = float(floats[0])
                    y = float(floats[1])
                    X.append(x)
                    Y.append(y)
            fd.close()
            return [X, Y]
    except:
        return None


args = sys.argv
if len(args) != 2:
    print "Invalid call, please use: python generate_eliptic.py <output-file>"
    quit()

filename = args[1]
size = 0.25
data = parseFile(CONF_FILE)

if data is None:
    print "Unnable to parse ",CONF_FILE, ", check your file"
    quit()

airfoilX, airfoilY = data

resolutionx = 25
resolutiony = 25
# resolutionx = 17
# resolutiony = 17
gridx = numpy.linspace(0.0, 1.0, resolutionx)
gridy = numpy.linspace(0.0, 1.0, resolutiony)

X = numpy.zeros((resolutionx, resolutiony))
Y = numpy.zeros((resolutionx, resolutiony))

r20 = r2(0)
r40 = r4(0)
r21 = r2(1)
r41 = r4(1)

for i in range(0, len(gridx)):
    for j in range(0, len(gridy)):
        x_ = gridx[i]
        y_ = gridy[j]
        a = 1.0 - x_
        b = 1.0 - y_
        r1y = r1(y_)
        r3y = r3(y_)
        r2x = r2(x_)
        r4x = r4(x_)
        x = a*r1y[0] + x_*r3y[0] + b*r2x[0] + y_*r4x[0] - \
            a*b*r20[0] - a*y_*r40[0] - x_*b*r21[0] - x_*y_*r41[0]
        y = a*r1y[1] + x_*r3y[1] + b*r2x[1] + y_*r4x[1] - \
            a*b*r20[1] - a*y_*r40[1] - x_*b*r21[1] - x_*y_*r41[1]
        X[i, j] = x
        Y[i, j] = y

err = 9999999
tol = 1e-4
it = 0
while err > tol:
    it = it + 1
    err = 0
    for j in range(2, resolutiony-1):
        for i in range(2, resolutionx-1):
            g11 = (X[i+1, j]-X[i-1, j])**2 + (Y[i+1, j]-Y[i-1, j])**2
            g22 = (X[i, j+1]-X[i, j-1])**2 + (Y[i, j+1]-Y[i, j-1])**2
            g12 = (X[i+1, j]-X[i-1, j])*(X[i, j+1]-X[i, j-1]) + \
                  (Y[i+1, j]-Y[i-1, j])*(Y[i, j+1]-Y[i, j-1])

            xtemp = 1/(2*(g22 + g11))*(\
                    g22*(X[i+1, j] + X[i-1, j]) + g11*(X[i, j+1] + X[i, j-1]) -\
                    0.5*g12*(X[i+1, j+1] - X[i-1, j+1] - X[i+1, j-1] + X[i-1, j-1]))

            ytemp = 1/(2*(g22 + g11))*(\
                    g22*(Y[i+1, j] + Y[i-1, j]) + g11*(Y[i, j+1] + Y[i, j-1]) -\
                    0.5*g12*(Y[i+1, j+1] - Y[i-1, j+1] - Y[i+1, j-1] + Y[i-1, j-1]))

            err = err + (X[i, j] - xtemp)**2 + (Y[i, j] - ytemp)**2
            X[i, j] = xtemp
            Y[i, j] = ytemp

    err = math.sqrt(err)

dataToVTK(X, Y, VTK_OUTPUT)
writeOutputDomain(filename)
plotGrid(len(gridx), len(gridy), X, Y)
plt.show()
