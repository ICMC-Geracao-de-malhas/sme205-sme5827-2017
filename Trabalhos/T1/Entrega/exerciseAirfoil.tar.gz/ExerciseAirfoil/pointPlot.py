import os
import numpy, sys
import matplotlib.pyplot as plt

CON_FILE = "output.txt"
with open(CON_FILE, "r") as fd:
    content = fd.read()
    splitted = content.split('\n')
    X = []
    Y = []
    for i in range(0, len(splitted)):
        floats = splitted[i].split()
        if len(floats) == 2:
            x = float(floats[0])
            y = float(floats[1])
            X.append(x)
            Y.append(y)

for i in range(0, len(X)):
    plt.plot(X[i], Y[i], 'bo')

plt.show()
