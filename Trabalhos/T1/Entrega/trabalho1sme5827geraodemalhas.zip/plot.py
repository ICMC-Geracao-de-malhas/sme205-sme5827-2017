import sys
import numpy as np
import matplotlib.pyplot as plt

#lendo o bordo gerado pelo programa em fortran:
f = open('bordo.txt','rt')

nah=int(f.readline())
ah = np.zeros((nah,2))
for i in range(nah):
    l=f.readline()
    ah[i,0]=l.split(' ')[0]
    ah[i,1]=l.split(' ')[1]


nab=int(f.readline())
hg = np.zeros((nab,2))
for i in range(nab):
    l=f.readline()
    hg[i,0]=l.split(' ')[0]
    hg[i,1]=l.split(' ')[1]


nbc=int(f.readline())
gf = np.zeros((nbc,2))
for i in range(nbc):
    l=f.readline()
    gf[i,0]=l.split(' ')[0]
    gf[i,1]=l.split(' ')[1]


ncd=int(f.readline())
ef = np.zeros((ncd,2))
for i in range(ncd):
    l=f.readline()
    ef[i,0]=l.split(' ')[0]
    ef[i,1]=l.split(' ')[1]



nde=int(f.readline())
de = np.zeros((nde,2))
for i in range(nde):
    l=f.readline()
    de[i,0]=l.split(' ')[0]
    de[i,1]=l.split(' ')[1]


ncd=int(f.readline())
cd = np.zeros((ncd,2))
for i in range(ncd):
    l=f.readline()
    cd[i,0]=l.split(' ')[0]
    cd[i,1]=l.split(' ')[1]



nbc=int(f.readline())
bc = np.zeros((nbc,2))
for i in range(nbc):
    l=f.readline()
    bc[i,0]=l.split(' ')[0]
    bc[i,1]=l.split(' ')[1]


nab=int(f.readline())
ab = np.zeros((nab,2))
for i in range(nab):
    l=f.readline()
    ab[i,0]=l.split(' ')[0]
    ab[i,1]=l.split(' ')[1]


f.close()

# comandos para plotar o bordo
plt.plot(ah[:,0],ah[:,1])
plt.plot(hg[:,0],hg[:,1])
plt.plot(gf[:,0],gf[:,1])
plt.plot(ef[:,0],ef[:,1])
plt.plot(de[:,0],de[:,1])
plt.plot(cd[:,0],cd[:,1])
plt.plot(bc[:,0],bc[:,1])
plt.plot(ab[:,0],ab[:,1])

plt.show()









