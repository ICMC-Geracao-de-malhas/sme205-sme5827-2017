# -*- coding: utf-8 -*-
"""
Created on Fri Aug 18 17:29:35 2017

@author: vinicius
"""

import numpy as np
import matplotlib.pyplot as plt

#Leitura do perfil
f = open('naca0012','rt')
nx = len(f.readlines())

a = np.zeros((nx,2))
f = open('naca0012','rt')
for i in range(nx):
    l=f.readline()
    a[i,0]=float(l.split(' ')[0])
    a[i,1]=float(l.split(' ')[-1])

#Dimenções:
neta = len(a)
nxi = 100#len(a)

b = [0]*(nxi)
d = [0]*(nxi)
c = [0]*(neta)


"""Esfera"""

#raio da circunferencia, centro no bordo de ataque
#l2 = 6 # tem que coincidir com o comp

#for i in range(neta):
#    c[i] = [l2*np.cos(2*i*np.pi/(neta-1)) +1 ,l2*np.sin(2*i*np.pi/(neta-1))]
#Tanh
#c[0]=[l2+1, 0]
#c[-1]= [l2+1, 0]
#for i in range(1,neta-1):
#    A = (np.tanh(i*2*np.pi/(neta) -np.pi)/2 + 0.5)
#    print(A)
#    c[i] = [l2*np.cos(2*A*np.pi) +1 ,l2*np.sin(2*A*np.pi)]
#    

"""Retangular"""
#entrada, dimençao do retangulo
l1 = 25
l2 = 25

perimetro = 2*l1 + l2*2
dp = perimetro/(neta-1)
peri = 0
for i in range(neta):
    if peri < l2/2:
        c[i]=[l1/2, peri]
        peri+= dp
    elif peri < l2/2 + l1:
        c[i]=[l1/2 -(peri-l2/2), l2/2]
        peri+= dp
    elif peri < 3*l2/2 + l1:
        c[i]=[-l1/2,l2/2 - (peri - l2/2 -l1)]
        peri+= dp
    elif peri < 3*l2/2 + 2*l1:
        c[i]=[-l1/2 + (peri - 3*l2/2 - l1), -l2/2 ]
        peri+= dp
    else:
        c[i]=[l1/2, -l2/2 +(peri - 3*l2/2 - 2*l1) ]
        peri+= dp

#quadrático ou cúbico
#l1 = 25
#l2 = 25
#
#perimetro = 2*l1 + l2*2
#dp = perimetro/(neta-1)
#peri = 0
##A = perimetro/(perimetro**3)
#c[0]=[l1/2, 0]
#c[-1]= [l1/2, 0]
#for i in range(1, neta-1):
#    #peri = A*(i*dp)**3 + (  )
#    peri = perimetro*(np.tanh(i*2*np.pi/(neta) -np.pi)/2 + 0.5)
#    print(peri)
#    if peri < l2/2:
#        c[i]=[l1/2, peri]
#    elif peri < l2/2 + l1:
#        c[i]=[l1/2 -(peri-l2/2), l2/2]
#    elif peri < 3*l2/2 + l1:
#        c[i]=[-l1/2,l2/2 - (peri - l2/2 -l1)]
#    elif peri < 3*l2/2 + 2*l1:
#        c[i]=[-l1/2 + (peri - 3*l2/2 - l1), -l2/2 ]
#    else:
#        c[i]=[l1/2, -l2/2 +(peri - 3*l2/2 - 2*l1) ]


#Comprimento dos bordos b e d
comp = l1/2 - np.amax(a)

for i in range(nxi):
    b[i] = [np.amax(a) + i*comp/(nxi-1),0]
    d[i] = [np.amax(a) + i*comp/(nxi-1) ,0]

#quadratico ou cúbico
#A = comp/(comp**2)
#for i in range(nxi):
#    b[i] = [np.amax(a) + A*(i*comp/(nxi-1))**2,0  ]
#    d[i] = [np.amax(a) + A*(i*comp/(nxi-1))**2,0  ]
    
# plota os bordos    
plt.plot([x[0] for x in a],[x[1] for x in a])
plt.plot([x[0] for x in b],[x[1] for x in b])
plt.plot([x[0] for x in c],[x[1] for x in c])
plt.plot([x[0] for x in d],[x[1] for x in d])
plt.show()

#Salva os bordos
f = open('perfil.txt','wt')

#top
f.write(str(len(a)))
f.write('\n')
for i in range(neta):
    f.write("{:.7f}".format(c[i][0]))
    f.write(' ')
    f.write("{:.7f}".format(c[i][1]))
    f.write('\n')

#b
f.write(str(neta))
f.write('\n')
for i in range(neta):
    f.write("{:.7f}".format(a[i][0]))
    f.write(' ')
    f.write("{:.7f}".format(a[i][1]))
    f.write('\n')

#l
f.write(str(nxi))
f.write('\n')
for i in range(nxi):
    f.write("{:.7f}".format(b[i][0]))
    f.write(' ')
    f.write("{:.7f}".format(b[i][1]))
    f.write('\n')

#r
f.write(str(nxi))
f.write('\n')
for i in range(nxi):
    f.write("{:.7f}".format(d[i][0]))
    f.write(' ')
    f.write("{:.7f}".format(d[i][1]))
    f.write('\n')

f.close()
