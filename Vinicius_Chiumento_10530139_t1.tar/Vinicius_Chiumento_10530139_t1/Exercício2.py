# -*- coding: utf-8 -*-
"""
Created on Wed Sep 13 11:15:57 2017

@author: vinicius
"""

"""leitura do arquivo"""

import sys
import numpy as np
import matplotlib.pyplot as plt
import grid as grid

f = open('perfil3.txt','rt')

nx = int(f.readline())
rt = np.zeros((nx,2))
for i in range(nx):
    l=f.readline()
    rt[i,0]=l.split(' ')[0]
    rt[i,1]=l.split(' ')[1]

n2 = int(f.readline())

if (n2 != nx):
    print("top and botton discretization should match")
    sys.exit(0)

rb = np.zeros((nx,2))
for i in range(nx):
    l=f.readline()
    rb[i,0]=l.split(' ')[0]
    rb[i,1]=l.split(' ')[1]

ny = int(f.readline())
rl = np.zeros((ny,2))
for i in range(ny):
    l=f.readline()
    rl[i,0]=l.split(' ')[0]
    rl[i,1]=l.split(' ')[1]

n2 = int(f.readline())

if (n2 != ny):
    print("left and right discretization should match")
    sys.exit(0)

rr = np.zeros((ny,2))
for i in range(ny):
    l=f.readline()
    rr[i,0]=l.split(' ')[0]
    rr[i,1]=l.split(' ')[1]

f.close()

gx = np.zeros((nx,ny))
gy = np.zeros((nx,ny))

gx[:,0] = rb[:,0]
gx[:,-1] = rt[:,0]
gx[0,:] = rl[:,0]
gx[-1,:] = rr[:,0]
 
gy[:,0]  = rb[:,1]
gy[:,-1] = rt[:,1]
gy[0,:]  = rl[:,1]
gy[-1,:] = rr[:,1]

"""Transfinita"""
dx = 1.0/nx
dy = 1.0/ny
#
for j in range(1,ny-1):
    jdy = j*dy
    for i in range(1,nx-1):
        idx = i*dx
        gx[i,j] = (1.0-idx)*rl[j,0] + idx*rr[j,0] + (1.0 - jdy)*rb[i,0] + jdy*rt[i,0] - (1.0-idx)*(1.0-jdy)*rb[0,0] - (1.0 - idx)*jdy*rt[0,0] - idx*(1.0-jdy)*rb[nx-1,0] - idx*jdy*rt[nx-1,0]
        gy[i,j] = (1.0-idx)*rl[j,1] + idx*rr[j,1] + (1.0 - jdy)*rb[i,1] + jdy*rt[i,1] - (1.0-idx)*(1.0-jdy)*rb[0,1] - (1.0 - idx)*jdy*rt[0,1] - idx*(1.0-jdy)*rb[nx-1,1] - idx*jdy*rt[nx-1,1]

"""Elipitico"""
gx2 = np.empty_like(gx)
gy2 = np.empty_like(gx)
gx2[:,:]=gx[:,:]
gy2[:,:]=gy[:,:]
erro = 1
tol = 0.0001
nmax = 1000
cont=0
w = 1.0 # Fator de sobre relaxamento

Ax = [0.05,0.1,0.1]
Bx = [4,0,0]
Cx = [90,90,90]
Dx = [15,0,0]
Ay = [0.05,0,2]
By = [5.6,0,0]
Cy = [50,40,10]
Dy = [15,0,0]
eta = [0.0401,0.99999,0.001]
xi = [0.5001,0.99999,0.001]

while (erro > tol) and (cont < nmax):
    erro = 0
    for j in range(1,ny-1):
        for i in range(1,nx-1):
            dxdxi = (gx[i+1,j]-gx[i-1,j])/(2.0*dx)
            dydxi = (gy[i+1,j]-gy[i-1,j])/(2.0*dx)
            dxdeta = (gx[i,j+1]-gx[i,j-1])/(2.0*dy)
            dydeta = (gy[i,j+1]-gy[i,j-1])/(2.0*dy)       
            g11 = dxdxi**2 + dydxi**2
            g22 = dxdeta**2 + dydeta**2
            g12 = dxdxi*dxdeta + dydxi*dydeta
            a = g22/(dx**2)
            b = 2*g22/(dx**2) + 2*g11/(dy**2)
            d = (g11/(dy**2) )*(gx[i,j+1] + gx[i,j-1]) - 2*g12*(gx[i+1,j+1]+gx[i-1,j-1]-gx[i-1,j+1]-gx[i+1,j-1])/(4*dx*dy)
            e = (g11/(dy**2) )*(gy[i,j+1] + gy[i,j-1]) - 2*g12*(gy[i+1,j+1]+gy[i-1,j-1]-gy[i-1,j+1]-gy[i+1,j-1])/(4*dx*dy)

            g = g11*g22-g12**2
            p = 0
            q = 0
            for k in range(len(Ax)):
                p += - g*(Ax[k]*(i*dx- xi[k])/abs(i*dx-xi[k])*np.e**(-Cx[k]*abs(i*dx-xi[k])) + Bx[k]*(i*dx- xi[k])/abs(i*dx-xi[k])*np.e**(-Dx[k]*((i*dx-xi[k])**2 + (j*dy -eta[k])**2 )**0.5))
                q += - g*(Ay[k]*(j*dy - eta[k])/abs(j*dy - eta[k])*np.e**(-Cy[k]*abs(j*dy-eta[k])) + By[k]*(j*dy - eta[k])/abs(j*dy - eta[k])*np.e**(-Dy[k]*((i*dx-xi[k])**2 + (j*dy -eta[k])**2 )**0.5))
            
            gx2[i,j]= (a*(gx[i+1,j] + gx[i-1,j]) + d +p*dxdxi + q*dxdeta )/b
            gy2[i,j]= (a*(gy[i+1,j] + gy[i-1,j]) + e +p*dydxi + q*dydeta )/b
            if abs(gx2[i,j] - gx[i,j])>erro:
                erro = abs(gx2[i,j] - gx[i,j])
            if abs(gy2[i,j] - gy[i,j])>erro:
                erro = abs(gy2[i,j] - gy[i,j])

    gx[:,:]=w*gx2[:,:] +(1-w)*gx[:,:]
    gy[:,:]=w*gy2[:,:] +(1-w)*gy[:,:]
    print(cont, erro)
    cont+=1
    
"""Grafico"""
for i in range(nx):
    plt.plot(gx[i,:],gy[i,:],color='gray')
for i in range(ny):
    plt.plot(gx[:,i],gy[:,i],color='gray')

plt.plot(rt[:,0],rt[:,1])
plt.plot(rb[:,0],rb[:,1])
plt.plot(rl[:,0],rl[:,1])
plt.plot(rr[:,0],rr[:,1])
plt.show()

grid.grid2vtk(gx,gy,"m4")
